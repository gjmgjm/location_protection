#!/usr/bin/env python  
# encoding: utf-8

""" 
@version: v1.0 
@author: jaculamata 
@license: Apache Licence  
@contact: 819436557@qq.com 
@site: http://blog.csdn.net/hqzxsc2006 
@software: PyCharm 
@file: main.py 
@time: 2019/1/20 16:02 
"""



class Main():
    def __init__(self):
        pass


if __name__ == "__main__":
    import pandas as pd
    import itertools

    original_list = [[2, 4, 3], [1, 5, 6], [9], [7, 9, 0]]
    new_merged_list = list(itertools.chain(*original_list))
    print(new_merged_list)
    # df1 = pd.DataFrame({'id': [1, 2, 3], 'name': ['Andy1', 'Jacky1', 'Bruce1']})
    # df2 = pd.DataFrame({'id': [1, 2], 'name': ['Andy2', 'Jacky2']})
    #
    # s = df2.set_index('id')['name']
    # print(s)
    # df1['name'] = df1['id'].map(s).fillna(df1['name'])
    # print(df1)
