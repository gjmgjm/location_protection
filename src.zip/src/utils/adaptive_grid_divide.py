#!/usr/bin/env python
# encoding: utf-8

"""
@version: v1.0
@author: jaculamata
@license: Apache Licence
@contact: 819436557@qq.com
@site: http://blog.csdn.net/hqzxsc2006
@software: PyCharm
@file: 2_grid_divide.py
@time: 2019/1/20 15:38
"""
import decimal
import math
import multiprocessing
import pandas as pd
import time
import os
import numpy as np
import gc
abspath = os.path.abspath('..')


class adaptive_grid_divide():

    def __init__(self, city, N, M, ranges, delta_lat, delta_lon):
        self.checkins = pd.read_csv(abspath + "\\data\\city_data\\" + city + "_3.csv", delimiter="\t", index_col=None)
        # self.checkins = self.checkins[self.checkins.uid.isin([37, 180, 1576])]
        # locid_len = self.checkins.locids.unique()
        self.ranges = ranges  # 城市经纬度范围
        self.lat_len = len(self.checkins.latitude.unique())
        self.lon_len = len(self.checkins.longitude.unique())
        self.density_lat = delta_lat * self.lat_len / N
        self.density_lon = delta_lon * self.lon_len / M
        self.n = N
        self.m = M
        self.city = city
        self.latInterval = decimal.Decimal.from_float(math.fabs(self.ranges[0] - self.ranges[2]) / self.n) #纬度为n，经度为m
        self.lngIntetval = decimal.Decimal.from_float(math.fabs(self.ranges[3] - self.ranges[1]) / self.m)
        self.maxlat = decimal.Decimal(self.ranges[0])
        self.minlng = decimal.Decimal(self.ranges[1])
        self.first_gridnums = N * M-1
        self.grid = [i for i in range(N * M)]

    def cal_gridid(self, checkin):
        latitude = decimal.Decimal(checkin[2])
        longitude = decimal.Decimal(checkin[3])
        i = math.floor((self.maxlat - latitude) / self.latInterval)
        j = math.floor((longitude - self.minlng) / self.lngIntetval)
        gridlat = float(self.maxlat - i * self.latInterval - self.latInterval / 2)
        gridlon = float(self.minlng + j * self.lngIntetval + self.lngIntetval / 2)
        checkin.append(gridlat)
        checkin.append(gridlon)
        checkin.append(int(i * self.m + j))
        return checkin

    # 按照N*N网格进行划分
    def divide_area_by_NN(self):  # 顶层网格划分
        checkin_new = []
        # index = 0
        print("顶层网格划分中...")
        for row in self.checkins.itertuples(index=False, name=False):
            checkin = self.cal_gridid(list(row))
            checkin_new.append(checkin)
            # print(index)
            # index =index+1
        checkins = pd.DataFrame(checkin_new, columns=['uid', 'time', 'latitude', 'longitude', 'locid', 'gridlat', 'gridlon', 'grid_id'])
        checkins.to_csv(abspath + "\\data\\city_data_adaptive_grid" + "\\" + self.city+"_"+str(self.n)+"_"+str(self.m)+".csv", index=False, header=False)
        print("顶层网格划分完成，正在划分第二层网格...")

    def cal_second_gridid(self, checkin, ranges, n, m, start_grid):
        latInterval = decimal.Decimal.from_float(math.fabs(ranges[0] - ranges[2]) / n)  # 纬度为n，经度为m
        lngIntetval = decimal.Decimal.from_float(math.fabs(ranges[3] - ranges[1]) / m)
        maxlat = decimal.Decimal(ranges[0])
        minlng = decimal.Decimal(ranges[1])
        latitude = decimal.Decimal(checkin[2])
        longitude = decimal.Decimal(checkin[3])
        i = math.floor((maxlat - latitude) / latInterval)
        j = math.floor((longitude - minlng) / lngIntetval)
        gridlat = float(maxlat - i * latInterval - latInterval / 2)
        gridlon = float(minlng + j * lngIntetval + lngIntetval / 2)   # 计算的经纬度不一样，但是在同一个网格里面
        checkin.append(gridlat)
        checkin.append(gridlon)
        checkin.append(int(i * m + j + start_grid))
        return checkin

    def second_divide(self, deltac):
        checkins = pd.read_csv(abspath + "\\data\\city_data_adaptive_grid" + "\\" + self.city+"_"+str(self.n)+"_"+str(self.m)+".csv", delimiter=",", index_col=None,header=None)
        checkins.columns = ['uid', 'time', 'latitude', 'longitude', 'locid', 'gridlat', 'gridlon', 'grid_id']
        # print(len(checkins.grid_id.unique()))
        checkin_new = []
        checkins_lat_len = checkins.groupby(by=['grid_id', 'latitude']).size().reset_index(name="grid_lat_times")
        checkins_lon_len = checkins.groupby(by=['grid_id', 'longitude']).size().reset_index(name="grid_lon_times")
        checkins_lat_lon_len = checkins_lat_len.groupby(by=['grid_id']).size().reset_index(name="grid_lat_times")
        checkins_lon_len1 = checkins_lon_len.groupby(by=['grid_id']).size().reset_index(name="grid_lon_times")
        checkins_lat_lon_len.loc[:, 'grid_lon_times'] = checkins_lon_len1['grid_lon_times']
        checkins_lat_lon_len.loc[:, 'is_dense'] = 0
        checkins_lat_lon_len.loc[(checkins_lat_lon_len.grid_lat_times >= self.density_lat) & (checkins_lat_lon_len.grid_lon_times >= self.density_lon), 'is_dense'] = 1
        del checkins_lat_len, checkins_lon_len, checkins_lon_len1
        gc.collect()
        grid_checkins_len = checkins.groupby(by=['grid_id']).size().reset_index(name="grid_times")
        # print(len(checkins_lat_lon_len[checkins_lat_lon_len.is_dense == 1]))
        # print(grid_checkins_len.grid_times.sum())
        # index = 0
        second_divide_grid = checkins_lat_lon_len[checkins_lat_lon_len.is_dense == 1].grid_id.unique()
        second_divide_grid.sort()
        second_grid_range = []
        first_gridnums = self.first_gridnums
        total_grid = self.first_gridnums+1

        for gridid in second_divide_grid:
            j = gridid % self.m
            # j1 = checkins[checkins.grid_id==gridid].j.values[0]
            i = int((gridid-j) / self.m)
            # i1 = checkins[checkins.grid_id == gridid].i.values[0]
            ranges = [float(self.maxlat - i * self.latInterval), float(self.minlng + j * self.lngIntetval),
                     float(self.maxlat - (i + 1) * self.latInterval), float(self.minlng + (j + 1) * self.lngIntetval)]
            # n = int(math.ceil(math.sqrt(grid_checkins_len[grid_checkins_len.grid_id == gridid].grid_times.values[0] / deltac)))
            # m = int(math.ceil(math.sqrt(grid_checkins_len[grid_checkins_len.grid_id == gridid].grid_times.values[0] / deltac)))
            n = int(math.ceil(pow(grid_checkins_len[grid_checkins_len.grid_id == gridid].grid_times.values[0] / deltac, 1.0/1.5)))
            if n > 8:
                n = 8
            m = n
            second_grid_range.append([gridid, m, n, ranges, first_gridnums+1])
            #新加的
            self.grid.remove(gridid)
            self.grid.extend([k for k in range(first_gridnums+1, first_gridnums+1+n * m)])
            first_gridnums = first_gridnums + n * m  # 单次网格划分的终点
            total_grid += n * m-1

        second_grid_range = pd.DataFrame(second_grid_range, columns=['grid_id', 'm', 'n', 'range', 'start_grid'])
        for row in checkins.itertuples(index=False, name=False):
            # print(index)
            if checkins_lat_lon_len[checkins_lat_lon_len.grid_id == row[7]].is_dense.values[0] == 1:
                grid_range = second_grid_range[second_grid_range.grid_id == row[7]]
                ranges = grid_range.range.values[0]
                n = grid_range.n.values[0]
                m = grid_range.m.values[0]
                start_grid = grid_range.start_grid.values[0]
                checkin = self.cal_second_gridid(list(row), ranges, n, m, start_grid)
                checkin.append(n)
                checkin.append(m)
                checkin.append(start_grid)
            else:
                checkin = list(row)
                checkin.append(row[5])
                checkin.append(row[6])
                checkin.append(row[7])
                # checkin.append(row[8])
                # checkin.append(row[9])
                checkin.append(1)
                checkin.append(1)
                checkin.append(0)
            checkin_new.append(checkin)
            # index = index+1
        checkins = pd.DataFrame(checkin_new, columns=['uid', 'time', 'latitude', 'longitude', 'locid', 'gridlat', 'gridlon', 'grid_id', 'gridlat_second', 'gridlon_second', 'grid_id_second', 'n', 'm', 'start_grid'])
        checkins.to_csv(abspath + "\\data\\city_data_adaptive_grid" + "\\" + self.city + "_" + str(self.n) + "_" + str(self.m) + ".csv", index=False, header=False)
        # file = open(abspath + "\\data\\city_data_adaptive_grid\\locids.txt", 'w')
        # file.write(str(self.grid))
        # file.close()
        print("第二层网格划分完成")
        print("位置总数", total_grid, len(self.grid))
        return checkins, self.grid

    def read_data(self):
        checkins = pd.read_csv(abspath + "\\data\\city_data_adaptive_grid" + "\\" + self.city + "_" + str(self.n) + "_" + str(self.m) + ".csv", delimiter=",", index_col=None, header=None)
        checkins.columns =['uid', 'time', 'latitude', 'longitude', 'locid', 'gridlat', 'gridlon', 'grid_id','gridlat_second', 'gridlon_second', 'grid_id_second',  'n', 'm', 'start_grid']
        # checkins = checkins.ix[:, [0, 2, 3, 4, 7, 10, 11, 12, 13, 14]]
        print(len(checkins.locid.unique()))
        checkin1 = checkins.groupby(by=["grid_id", 'grid_id_second','m','n','start_grid', 'gridlat_second', 'gridlon_second']).size().reset_index(name="locid_time")
        locids = [row[0] for row in checkin1.itertuples(index=False, name=False)]
        checkins2 = checkins.groupby(by=['grid_id_second', 'gridlat_second', 'gridlon_second']).size().reset_index(name="locid_time")
        print(len(checkins2), len(set(checkins2.grid_id_second.unique())))


if __name__ == "__main__":
    # ny
    # start = time.time()
    # grid_divide = adaptive_grid_divide("GW_NY", 90, 90, [40.836357, -74.052914, 40.656702, -73.875168], 0.2, 0.2)
    # grid_divide.divide_area_by_NN()
    # grid_divide.second_divide(15)
    # # grid_divide.read_data()
    # end = time.time()
    # print("花费时间为：", str(end-start))
    # 7/309、16/1394、24/2335、29/3394、39/4734
    # 0.2,0.2,20, 三次方根 7/302 ；0.2,0.2,10, 二次方根 16/1394 ；0.2,0.2, 9, 1.5次方根 24/2322；
    # 0.2,0.2, 5, 1.5次方根 29/3409； 0.2,0.2, 3, 1.5次方根 39/4719 文件city_data_adaptive_grid
    start = time.time()
    grid_divide = adaptive_grid_divide("SNAP_SF", 39, 39, [37.809524, -122.520352, 37.708991, -122.358712], 0.2, 0.2)
    grid_divide.divide_area_by_NN()
    grid_divide.second_divide(9)
    grid_divide.read_data()
    end = time.time()
    print("花费时间为：", str(end - start))