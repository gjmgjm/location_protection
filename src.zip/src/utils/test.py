

#!/usr/bin/env python
# encoding: utf-8

from adaptive_grid_divide_by_dp import adaptive_grid_divide_by_dp
from cal_friends_similarity import cal_friends_similarity
import geatpy as ea                # import geatpy
from MyProblem1 import MyProblem1  # 导入自定义问题接口
from update_features import update_features


"""================================实例化问题对象==========================="""
problem = MyProblem1([0, 0, 0, 0, 0, 0.3], [[0.2, 0, 0, 0, 0, 0.8], [0.1, 0.8, 0.8, 0, 0, 0.1]], [0.5, 0.5], [0.5, 0.5],  [[0, 0], [0, 0],
                      [0, 0], [0, 0],
                      [0, 0], [0, 0]], "SNAP_SF")  # 生成问题对象
comloc_idx = problem.get_comidx()
uncomloc_indexs = problem.get_uncomidx()
stay_x = problem.get_stay_x()
"""==================================种群设置==============================="""
Encoding = 'BG'  # 编码方式
NIND = 50  # 种群规模
Field = ea.crtfld(Encoding, problem.varTypes, problem.ranges, problem.borders)  # 创建区域描述器
population = ea.Population(Encoding, Field, NIND)  # 实例化种群对象（此时种群还没被初始化，仅仅是完成种群对象的实例化）
"""================================算法参数设置============================="""
myAlgorithm = ea.moea_NSGA3_templet(problem, population)  # 实例化一个算法模板对象
myAlgorithm.MAXGEN = 200  # 最大进化代数
"""==========================调用算法模板进行种群进化========================"""
NDSet = myAlgorithm.run()  # 执行算法模板，得到帕累托最优解集NDSet
Phen = NDSet.Phen
print(Phen)
#  aimFunc(self, Phen, original_vector, friends_vectors, friends_delta, weight_delta, stay_x, uncomloc_indexs)