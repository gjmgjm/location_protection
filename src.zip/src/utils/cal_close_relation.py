#!/usr/bin/env python
# encoding: utf-8

import pandas as pd
import os
from joblib import Parallel, delayed
import multiprocessing as mp
import math
from itertools import repeat
import gc
import numpy as np
from copy import deepcopy
import time
from itertools import combinations
abspath = os.path.abspath('..')


class cal_close_relation:

    def __init__(self, city, distance):
        self.checkins = pd.read_csv(abspath+"\\data\\city_data\\"+city+"_1.csv", delimiter="\t", index_col=None)
        self.edges = pd.read_csv(abspath+"\\data\\city_data\\"+city+"_edgs.csv", delimiter="\t", index_col=None)
        self.edges.columns = ["u1", "u2"]
        self.city = city
        self.distance = distance  # km为单位
        checkin1 = self.checkins.groupby(by=['locid', 'latitude', 'longitude']).size().reset_index(name="locid_time")
        self.locids = [row[0] for row in checkin1.itertuples(index=False, name=False)]  # 记录locid对应的经纬度，以便在替换locid时将相应的位置数据也进行替换
        self.lat_lon = [[row[1], row[2]] for row in checkin1.itertuples(index=False, name=False)]
        del checkin1  # 释放checkin1的内存空间
        gc.collect()
        self.users = self.checkins.uid.unique()
        self.checkins.loc[:, "locid_after"] = self.checkins["locid"]
        self.checkins.loc[:, "lat_after"] = self.checkins["latitude"]
        self.checkins.loc[:, "lng_after"] = self.checkins["longitude"]
        self.lat_lon_df = pd.DataFrame(self.lat_lon, columns=['lat', 'lng'])
        if city == "GW_NY":
            self.lons_per_km = 0.0059352 * 2  # NY
            self.lats_per_km = 0.0044966 * 2  # delta latitudes per kilo meter
        elif city == "GW_NY":
            self.lons_per_km = 0.005681 * 2  # SF
            self.lats_per_km = 0.004492 * 2  # delta latitudes per kilo meter
        elif city == "GW_AS":
            self.lons_per_km = 0.005681 * 2  # AS
            self.lats_per_km = 0.004492 * 2  # delta latitudes per kilo meter
        self.lat_interval = self.distance * self.lats_per_km
        self.lng_interval = self.distance * self.lons_per_km

    def get_lat_lon(self):
        return self.lat_lon

    def getlocid(self):
        return self.locids

    def run(self, u, edges):
        u_friends = set(edges.u1.unique()).union(set(edges.u2.unique()))
        if len(u_friends) != 0:
            u_friends.remove(u)
        return [u, list(u_friends)]  # 用户u的好友

    # 计算好友间好友比例
    def cal_relation(self, pairs):
        # uids = list(set(self.edges.u1.unique()).union(set(self.edges.u2.unique())))
        core_num = mp.cpu_count()
        u_friends = Parallel(n_jobs=core_num)(delayed(self.run)(u, self.edges[(self.edges.u1 == u) | (self.edges.u2 == u)]) for u in self.users)
        u_friends = pd.DataFrame(u_friends, columns=['uid', 'friends'])
        print("好友计算完毕")
        fri_relation = []
        for row in pairs:  # 这里错了
            row1_friends = set(u_friends[u_friends.uid == row[0]].friends.values[0])
            row2_friends = set(u_friends[u_friends.uid == row[1]].friends.values[0])
            com_friends = row1_friends.intersection(row2_friends)
            union_friends = row1_friends.union(row2_friends)
            if len(union_friends) == 0:
                fri_relation.append([row[0], row[1], 0])
            else:
                fri_relation.append([row[0], row[1], len(com_friends)/len(union_friends)])
        fri_relation = pd.DataFrame(fri_relation, columns=['u1', 'u2', 'fri_rate'])
        fri_relation.to_csv(abspath+"\\data\\city_data\\"+self.city+"_pairs_fri_rate.csv", sep='\t', index=False, header=False)

    def cal_relation1(self, pairs):
        # uids = list(set(self.edges.u1.unique()).union(set(self.edges.u2.unique())))
        core_num = mp.cpu_count()
        u_friends = Parallel(n_jobs=core_num)(
            delayed(self.run)(u, self.edges[(self.edges.u1 == u) | (self.edges.u2 == u)]) for u in self.users)
        u_friends = pd.DataFrame(u_friends, columns=['uid', 'friends'])
        print("好友计算完毕")
        fri_relation = []
        for row in pairs:  # 这里错了
            row1_friends = set(u_friends[u_friends.uid == row[0]].friends.values[0])
            if row[1] in row1_friends:   # 这才是真实存在的用户对
                row2_friends = set(u_friends[u_friends.uid == row[1]].friends.values[0])
                com_friends = row1_friends.intersection(row2_friends)
                union_friends = row1_friends.union(row2_friends)
                if len(union_friends) == 0:
                    fri_relation.append([row[0], row[1], 0])
                else:
                    fri_relation.append([row[0], row[1], len(com_friends) / len(union_friends)])
            else:
                fri_relation.append([row[0], row[1], -1])
        fri_relation = pd.DataFrame(fri_relation, columns=['u1', 'u2', 'fri_rate'])
        fri_relation.to_csv(abspath + "\\data\\city_data\\" + self.city + "_pairs_fri_rate_new1.csv", sep='\t', index=False, header=False)

    # 两点之间的欧氏距离计算
    def euclidean_distance(self, loc1, loc2):
        return math.sqrt(((loc1[1] - loc2[1]) / float(self.lons_per_km)) ** 2 + ((loc1[0] - loc2[0]) / float(self.lats_per_km)) ** 2)

    # 判断共同访问位置
    def cal_distance(self, cdt_loc, cdt_loc1):
        dis_list = list(map(self.euclidean_distance, repeat(cdt_loc), cdt_loc1))
        loc = []
        for i in range(len(dis_list)):
            if dis_list[i] < self.distance:
                loc.append(self.locids[self.lat_lon.index(cdt_loc1[i])])
        return loc
        # 1016
        # if min(list(map(self.euclidean_distance, repeat(cdt_loc), cdt_loc1))) < self.distance:
        #     # return [cdt_loc, 1, self.locids[self.lat_lon.index(cdt_loc)]]
        # # return [cdt_loc, 1, self.locids[self.lat_lon.index(cdt_loc)]]

    def run1(self, u1, u2, u1_cdt_latlon, u2_cdt_latlon):
        print(u1)
        u1_comlocs, u2_comlocs = [], []
        for cdt in u1_cdt_latlon:
            loc = self.cal_distance(cdt, u2_cdt_latlon)   # u2共同访问位置
            if len(loc) != 0:
                u1_comlocs.append(self.locids[self.lat_lon.index(cdt)])  # u1共同访问位置
                u2_comlocs.extend(loc)
        u2_comlocs = list(set(u2_comlocs))
        if len(u1_comlocs) == 0:
            result = pd.DataFrame([[u1, u2, 0, [], []]], columns=['u1', 'u2', 'loc_rate', 'u1_comlocs', 'u2_comlocs'])
            # return [u1, u2, 0, [], []]
        else:
            min_comloc = min(len(u1_comlocs), len(u2_comlocs))
            result = pd.DataFrame([[u1, u2, min_comloc / (len(u1_cdt_latlon) + len(u2_cdt_latlon) - min_comloc), u1_comlocs, u2_comlocs]], columns=['u1', 'u2', 'loc_rate', 'u1_comlocs', 'u2_comlocs'])
            # return [u1, u2, min_comloc / (len(u1_cdt_latlon) + len(u2_cdt_latlon) - min_comloc), u1_comlocs, u2_comlocs]
        result.to_csv(abspath + "\\data\\city_data\\" + self.city + "_pairs_loc_rate.csv", sep='\t', index=False, header=False, mode='a')

    # 1016_17这种方式很慢，不建议采用
    def run2(self, u1, u2, u1_cdt, u2_cdt):
        print(u1)
        locids = list(set(u1_cdt).union(set(u2_cdt)))
        locids = sorted(locids)
        pair_dis = self.pairs_distance(locids)
        pair_dis.set_index(['loc1', 'loc2'], inplace=True)
        u1_comlocs, u2_comlocs = [], []
        for cdt in u1_cdt:
            loc = []
            for cdt1 in u2_cdt:
                if cdt > cdt1:
                    if pair_dis.xs(cdt1).xs(cdt)[0] < self.distance:
                        loc.append(cdt1)
                elif cdt < cdt1:
                    if pair_dis.xs(cdt).xs(cdt1)[0] < self.distance:
                        loc.append(cdt1)
                else:
                    loc.append(cdt1)
            if len(loc) != 0:
                u1_comlocs.append(cdt)
                u2_comlocs.extend(loc)
        u2_comlocs = list(set(u2_comlocs))
        if len(u1_comlocs) == 0:
            return [u1, u2, 0, [], []]
        else:
            min_comloc = min(len(u1_comlocs), len(u2_comlocs))
            return [u1, u2, min_comloc / (len(u1_cdt) + len(u2_cdt) - min_comloc), u1_comlocs, u2_comlocs]

    def run3(self, u1_cdt_latlon, u2_cdt_latlon):
        u1_comlocs, u2_comlocs = [], []
        for cdt in u1_cdt_latlon:
            loc = self.cal_distance(cdt, u2_cdt_latlon)
            if len(loc) != 0:
                u1_comlocs.append(self.locids[self.lat_lon.index(cdt)])
                u2_comlocs.extend(loc)
        u2_comlocs = list(set(u2_comlocs))
        if len(u1_comlocs) == 0:
            return 0
        else:
            min_comloc = min(len(u1_comlocs), len(u2_comlocs))
            return min_comloc / (len(u1_cdt_latlon) + len(u2_cdt_latlon) - min_comloc)

    # 计算好友之间共同访问位置个数，distance表示位置之间的距离，暂时没用
    def cal_comlocs(self, pairs):
        core_num = mp.cpu_count()
        edges = Parallel(n_jobs=core_num)(delayed(self.run1)(row[0], row[1],
                [self.lat_lon[self.locids.index(cdt)] for cdt in list(self.checkins[self.checkins.uid == row[0]].locid.unique())],
                [self.lat_lon[self.locids.index(cdt)] for cdt in list(self.checkins[self.checkins.uid == row[1]].locid.unique())])
                for row in pairs.itertuples(index=False, name=False))
        edges = pd.DataFrame(edges, columns=['u1', 'u2', 'loc_rate', 'u1_comlocs', 'u2_comlocs'])
        edges.to_csv(abspath+"\\data\\city_data\\"+self.city+"_edges_loc_rate.csv", sep='\t', index=False, header=False)
        return edges

        # 计算好友间好友比例
    def cal_pairs_relation(self):
        pairs = list(combinations(self.users, 2))
        self.cal_relation1(pairs)

    def weight_distance(self, pre_loc, cur_loc, next_loc, cdt_locs, locid_list, u_checkins):
        pre_dis_list = list(map(self.euclidean_distance, cdt_locs, repeat(pre_loc)))
        cur_dis_list = list(map(self.euclidean_distance, cdt_locs, repeat(cur_loc)))
        next_dis_list = list(map(self.euclidean_distance, cdt_locs, repeat(next_loc)))
        weight_dis_list = np.sum([pre_dis_list, cur_dis_list, next_dis_list], axis=0).tolist()
        circle_locids = []
        for loc in locid_list:
            # 1013修改
            circle_locids.append(self.cir_2_1_loc[loc])
            # circle_locids.append(self.circle_locids1(self.lat_lon[self.locids.index(loc)], 2, 1))
        u_locids = u_checkins.locid.unique()
        area_pro = []
        for cir_loc in circle_locids:
            visited_loc = list(set(cir_loc).intersection(set(u_locids)))
            area_pro.append(len(u_checkins[u_checkins.locid.isin(visited_loc)]) / len(u_checkins))
        return [locid_list, weight_dis_list, area_pro]

    def choose_replace_locid(self, pre_locid, cur_locid, next_locid, locid_list, u_checkins, delta, u):  # u_checkins是改变后的距离
        cdt_locs = [self.lat_lon[self.locids.index(locid)] for locid in locid_list]
        pre_loc, cur_loc = self.lat_lon[self.locids.index(pre_locid)], self.lat_lon[self.locids.index(cur_locid)]
        next_loc = self.lat_lon[self.locids.index(next_locid)]
        pre_dis_list = list(map(self.euclidean_distance, cdt_locs, repeat(pre_loc)))
        cur_dis_list = list(map(self.euclidean_distance, cdt_locs, repeat(cur_loc)))
        next_dis_list = list(map(self.euclidean_distance, cdt_locs, repeat(next_loc)))
        weight_dis_list = np.sum([pre_dis_list, cur_dis_list, next_dis_list], axis=0).tolist()
        # weight_dis_list = cur_dis_list
        circle_locids = [self.cir_2_1_loc[loc] for loc in locid_list]  # 可以提前计算
        u_locids = u_checkins.locid.unique()
        area_pro = [len(u_checkins[u_checkins.locid.isin(list(set(cir_loc).intersection(set(u_locids))))]) / len(u_checkins) for cir_loc in circle_locids]
        loc_dis = [locid_list, weight_dis_list, area_pro]
        loc_dis = list(map(list, zip(*loc_dis)))
        for i in range(len(loc_dis)):
            # loc_dis[i][1] = 10**(-loc_dis[i][1])
            loc_dis[i][1] = math.exp(-loc_dis[i][1])
        loc_dis = pd.DataFrame(loc_dis, columns=['locid', 'dis', 'area_pro'])
        loc_dis.loc[:, 'dis'] = loc_dis.loc[:, 'dis'] / loc_dis.dis.sum()
        loc_dis.loc[:, 'weight_pro'] = loc_dis.apply(lambda x: x['dis'] * delta + x['area_pro']*(1-delta), axis=1)
        loc_dis.loc[:, 'weight_pro'] = loc_dis.loc[:, 'weight_pro'] / loc_dis.weight_pro.sum()
        loc_dis.loc[:, 'weight_pro'] = loc_dis.apply(lambda x: math.exp(u * x['weight_pro'] / 2), axis=1)
        loc_dis.loc[:, 'weight_pro'] = loc_dis.loc[:, 'weight_pro'] / loc_dis.weight_pro.sum()
        loc_dis = loc_dis.sort_values(by=['weight_pro'], ascending=False).reset_index(drop=True)  # 按照距离降序排列
        weight_pro = [row[3] for row in loc_dis.itertuples(index=False, name=False)]
        candidate_loc = [row[0] for row in loc_dis.itertuples(index=False, name=False)]
        property = np.random.random()
        i = 0
        property_candidate = 0
        if property == 0:
            i = 0
        else:
            while property_candidate < property:  # 轮盘赌过程
                property_candidate += weight_pro[i]
                i += 1
            if property_candidate > property:
                i -= 1
        return candidate_loc[i]

    # [37.809524, -122.520352, 37.708991, -122.358712] 求区域内的点
    def circle_locids(self, lat_lon, locid, circle, circle1):
        # 将距离转化成经纬度
        lat_interval = self.distance*self.lats_per_km
        lng_interval = self.distance*self.lons_per_km
        point_leftup_outer = [lat_lon[0] + circle * lat_interval, lat_lon[1] - circle * lng_interval]
        point_rightdown_outer = [lat_lon[0] - circle * lat_interval, lat_lon[1] + circle * lng_interval]
        point_leftup_inner = [lat_lon[0] + circle1 * lat_interval, lat_lon[1] - circle1 * lng_interval]
        point_rightdown_inner = [lat_lon[0] - circle1 * lat_interval, lat_lon[1] + circle1 * lng_interval]
        satisfy_locid_outer = deepcopy(self.lat_lon_df[(self.lat_lon_df.lat >= point_rightdown_outer[0]) &
                                                       (self.lat_lon_df.lat <= point_leftup_outer[0]) &
                                                       (self.lat_lon_df.lng >= point_leftup_outer[1]) &
                                                       (self.lat_lon_df.lng <= point_rightdown_outer[1])])
        satisfy_locid_inner = deepcopy(self.lat_lon_df[(self.lat_lon_df.lat >= point_rightdown_inner[0]) &
                                                       (self.lat_lon_df.lat <= point_leftup_inner[0]) &
                                                       (self.lat_lon_df.lng >= point_leftup_inner[1]) &
                                                       (self.lat_lon_df.lng <= point_rightdown_inner[1])])
        satisfy_locid_outer = satisfy_locid_outer[~satisfy_locid_outer.index.isin(satisfy_locid_inner.index.values.tolist())]
        dis_list = list(map(self.euclidean_distance, [list(row) for row in satisfy_locid_outer.itertuples(index=False, name=False)],repeat(lat_lon)))
        index = 0
        locids = []
        for row in satisfy_locid_outer.itertuples(index=False, name=False):
            dis = dis_list[index]
            if (dis <= circle * self.distance) & (dis > circle1 * self.distance):
                locids.append(self.locids[self.lat_lon.index(list(row))])
        return [locid, locids]

    def get_circle_locid(self, circle, circle1):   #
        locid_circle = []
        for locid in self.locids:
            locid_circle.append(self.circle_locids(self.lat_lon[self.locids.index(locid)], locid, circle, circle1))
        locid_circle = pd.DataFrame(locid_circle, columns=['locid', 'locid_circle'])
        locid_circle.to_csv(abspath + "\\data\\city_data\\" + self.city + "_" + str(self.distance*1000) + "_" + str(circle)+"_"+str(circle1)+".csv", sep='\t', index=False, header=False)

    def read_rate(self, filename):  # 读取similarity的文件
        dict = []
        file = open(filename, "r")
        a = file.readline()
        while a:
            temp = a.strip().split("\t")
            temp[3] = temp[3].replace("[", "")
            temp[3] = temp[3].replace("]", "")
            u1_comlocs = temp[3].strip().split(",")
            if u1_comlocs[0] != '':
                u1_comlocs = list(map(lambda x: int(x.replace("'", "")), u1_comlocs))
            else:
                u1_comlocs = []
            temp[4] = temp[4].replace("[", "")
            temp[4] = temp[4].replace("]", "")
            u2_comlocs = temp[4].strip().split(",")
            if u2_comlocs[0] != '':
                u2_comlocs = list(map(lambda x: int(x.replace("'", "")), u2_comlocs))
            else:
                u2_comlocs = []
            dict.append([int(temp[0]), int(temp[1]), float(temp[2]), u1_comlocs, u2_comlocs])
            a = file.readline()
        file.close()
        friends = pd.read_csv(abspath + "\\data\\city_data\\" + self.city + "_pairs_fri_rate_new1.csv", delimiter="\t", index_col=None)
        friends.columns = ['u1', 'u2', 'fri_rate']
        checkins = pd.DataFrame(dict, columns=['u1', 'u2', 'loc_rate', 'u1_comlocs', 'u2_comlocs'])
        checkins.loc[:, "fri_rate"] = friends['fri_rate']
        return checkins

    def read_circle_locids(self, filename):  # 将区域内的点读出
        dict = {}
        file = open(filename, "r")
        a = file.readline()
        while a:
            temp = a.strip().split("\t")
            temp[1] = temp[1].replace("[", "")
            temp[1] = temp[1].replace("]", "")
            circle_locid = temp[1].strip().split(",")
            if circle_locid[0] != '':
                circle_locid = list(map(lambda x: int(x.replace("'", "")), circle_locid))
            else:
                circle_locid = []
            dict[int(temp[0])] = circle_locid
            a = file.readline()
        file.close()
        return dict

    def get_friend_locids(self, pairs, u):
        friends = set(pairs.u1.unique()).union(set(pairs.u2.unique()))
        if len(friends) != 0:
            friends.remove(u)
        friends_locids = []  # 与用户u1具有社交关系的所有用户
        list(map(lambda x: friends_locids.extend(list(self.checkins[self.checkins.uid == x].locid_after.unique())), friends))
        friends_locids = list(set(friends_locids))
        # print("好友位置数：", len(friends_locids), "好友数：", len(friends))
        return friends_locids

    def get_cdt(self, init_cdts, u):
        # print(init_cdts)
        init_cdts.loc[:, 'dis'] = init_cdts.apply(lambda x: math.exp(u*x['dis']/2), axis=1)
        init_cdts.loc[:, 'dis'] = init_cdts.loc[:, 'dis']/init_cdts.dis.sum()
        init_cdts = init_cdts.sort_values(by=['dis'], ascending=False).reset_index(drop=True)
        weight_pro = [row[1] for row in init_cdts.itertuples(index=False, name=False)]
        candidate_loc = [row[0] for row in init_cdts.itertuples(index=False, name=False)]
        property = np.random.random()
        i = 0
        property_candidate = 0
        if property == 0:
            i = 0
        else:
            while property_candidate < property:  # 轮盘赌过程
                property_candidate += weight_pro[i]
                i += 1
            if property_candidate > property:
                i -= 1
        return candidate_loc[i]

    # 1013修改
    def cal_similarity1(self, delta1, delta2, delta3, delta4, k, pri_delta, times, rate):  # delta1为地理位置，delta2为社交关系
        sim = self.read_rate(abspath + "\\data\\city_data\\" + self.city + "_pairs_loc_rate.txt")
        sim.loc[:, 'similarity'] = 0
        sim.loc[sim.fri_rate >= 0, 'similarity'] = sim[sim.fri_rate >= 0].apply(lambda x: x['loc_rate']*delta1 + x['fri_rate']*delta2, axis=1)  # 具有社交关系的用户对
        sim_over = deepcopy(sim[(sim.similarity >= delta3) & (sim.fri_rate >= 0)])  # 需要进行扰动的用户对
        num = 0
        self.cir_1_0_loc = self.read_circle_locids(abspath + "\\data\\city_data\\" + self.city + "_1_0.txt")   # 这一步需要添加噪声
        self.cir_2_1_loc = self.read_circle_locids(abspath + "\\data\\city_data\\" + self.city + "_2_1.txt")
        for u in self.users:
            u_comlocs1 = sim_over[(sim_over.u1 == u)].u1_comlocs
            u_comlocs2 = sim_over[(sim_over.u2 == u)].u2_comlocs
            u_comloc = []  # 用户的共同访问位置
            if (len(u_comlocs1) != 0) | (len(u_comlocs2) != 0):
                list(map(lambda x: u_comloc.extend(x), u_comlocs1))
                list(map(lambda x: u_comloc.extend(x), u_comlocs2))
                u_comloc = list(set(u_comloc))
            del u_comlocs1, u_comlocs2  # 释放u_comlocs1, u_comlocs2的内存空间
            gc.collect()
            sim.loc[sim.u1 == u, 'u1_comlocs'] = sim[sim.u1 == u].apply(lambda x: 0, axis=1)
            sim.loc[sim.u2 == u, 'u2_comlocs'] = sim[sim.u2 == u].apply(lambda x: 0, axis=1)
            sim_over.loc[sim_over.u1 == u, 'u1_comlocs'] = sim_over[sim_over.u1 == u].apply(lambda x: 0, axis=1)
            sim_over.loc[sim_over.u2 == u, 'u2_comlocs'] = sim_over[sim_over.u2 == u].apply(lambda x: 0, axis=1)
            print(num, "获得所有共同访问位置")
            u_checkins = np.array(deepcopy(self.checkins[self.checkins.uid == u])).tolist()
            if len(u_comloc) != 0:
                # 用户好友的位置
                u1_friends_locids = self.get_friend_locids(self.edges[(self.edges.u1 == u) | (self.edges.u2 == u)], u)
                # 用户好友以及好友的共同访问位置
                all_fri_locids = u1_friends_locids
                for loc in u1_friends_locids:
                    all_fri_locids.extend(self.cir_1_0_loc[loc])
                    all_fri_locids = list(set(all_fri_locids))
                del u1_friends_locids
                gc.collect()
                u1_choose_locids = set(self.locids) - set(all_fri_locids) - set(u_comloc)
                del all_fri_locids
                gc.collect()
                u_uncomlocs = set(self.checkins[self.checkins.uid == u].locid.unique()) - set(u_comloc)  # 用户u的非共同访问位置
                choose_locids = list(u_uncomlocs)
                temp_delta3 = delta3 * rate
                for i in range(len(u_checkins)):  # 单个用户的记录数
                    checkin = u_checkins[i]  # 单条签到记录
                    if checkin[4] in u_comloc:
                        # 1017_15 获得与用户U没有社交关系的用户的位置
                        # u1_pairs_locids = self.get_friend_locids(sim[((sim.u1 == u) | (sim.u2 == u)) & (sim.loc_rate < delta3) & (sim.fri_rate == 0)], u)
                        if temp_delta3 != 0:
                            u1_pairs_locids = self.get_friend_locids(sim[((sim.u1 == u) | (sim.u2 == u)) & (sim.loc_rate < temp_delta3) & (sim.fri_rate == -1)], u)
                        else:
                            u1_pairs_locids = self.get_friend_locids(sim[((sim.u1 == u) | (sim.u2 == u)) & (sim.loc_rate <= temp_delta3) & (sim.fri_rate == -1)], u)
                        u1_choose_locids = set(u1_pairs_locids).intersection(u1_choose_locids).union(u_uncomlocs)
                        # 11_1，只有一步
                        cdt_locs = [self.lat_lon[self.locids.index(locid)] for locid in u1_choose_locids]
                        pre_dis_list = list(map(self.euclidean_distance, cdt_locs, repeat(self.lat_lon[self.locids.index(checkin[4])])))
                        loc_dis = [u1_choose_locids, pre_dis_list]
                        loc_dis = list(map(list, zip(*loc_dis)))
                        # 新增1025
                        # for j in range(len(loc_dis)):
                        #     # loc_dis[j][1] = math.exp(-loc_dis[j][1])
                        #     loc_dis[j][1] = 10**(-loc_dis[j][1])
                        # # 这个集合的选择不能是确定的，如果用差分隐私的话
                        # u1_choose_locids_select = []
                        # if len(u1_choose_locids) > 100:
                        #     num1 = 100
                        # else:
                        #     num1 = int(k*len(u1_choose_locids))
                        # if num1 != 0:
                        #     for m in range(num1):
                        #         # print(m)
                        #         loc_dis_df = pd.DataFrame(loc_dis, columns=['locid', 'dis'])
                        #         loc_dis_df.loc[:, 'dis'] = loc_dis_df.loc[:, 'dis'] / loc_dis_df.dis.sum()  # 1025
                        #         if len(loc_dis_df) != 0:
                        #             choose_loc = self.get_cdt(deepcopy(loc_dis_df), pri_delta*0.5/num1)
                        #             u1_choose_locids_select.append(choose_loc)
                        #             index = loc_dis_df[loc_dis_df.locid == choose_loc].index.values[0]
                        #             del loc_dis[index]
                        # u1_choose_locids = u1_choose_locids_select
                        # 1025删除
                        loc_dis = pd.DataFrame(loc_dis, columns=['locid', 'dis'])
                        loc_dis = loc_dis.sort_values(by=['dis'], ascending=True).reset_index(drop=True)
                        if (int(len(loc_dis)*0.15)+1) > 20:
                            loc_dis = loc_dis[0:20]       # 初步的位置筛选
                        else:
                            loc_dis = loc_dis[0:(int(len(loc_dis)*0.15)+1)]
                        u1_choose_locids = list(loc_dis.locid.values)
                        del u1_pairs_locids, cdt_locs, pre_dis_list, loc_dis
                        gc.collect()
                        pre_locid, next_locid = checkin[4], checkin[4]
                        if i > 0:
                            pre_locid = u_checkins[i - 1][5]
                        if i < len(u_checkins) - 1:
                            next_locid = u_checkins[i + 1][5]
                        if len(u1_choose_locids) != 0:
                            replace_locid = self.choose_replace_locid(pre_locid, checkin[4], next_locid, u1_choose_locids, self.checkins[self.checkins.uid == u], delta4, pri_delta)
                            # replace_locid = self.choose_replace_locid(pre_locid, checkin[4], next_locid,
                            #                                           u1_choose_locids,
                            #                                           self.checkins[self.checkins.uid == u], delta4,
                            #                                           pri_delta)
                            # print("得到候选位置", replace_locid)
                            lat_lon = self.lat_lon[self.locids.index(replace_locid)]
                            u_checkins[i][5] = replace_locid
                            u_checkins[i][6] = lat_lon[0]
                            u_checkins[i][7] = lat_lon[1]
                            if replace_locid in choose_locids:
                                pass
                            else:
                                choose_locids.append(replace_locid)
                                users = self.checkins[self.checkins.locid_after == replace_locid].uid.unique()  # 访问过新生成位置的所有用户
                                # Parallel(n_jobs=mp.cpu_count())(delayed(self.update_loc_rate)(u, user, len(u_checkins), len(self.checkins[self.checkins.uid == user])) for user in users)
                                for user in users:
                                    if u > user:
                                        old_loc_rate = sim.loc[(sim.u1 == user) & (sim.u2 == u), 'loc_rate'].values[0]
                                        loc_new_rate = (old_loc_rate*(len(u_checkins)+len(self.checkins[self.checkins.uid == user])+1)+1)/(len(u_checkins)+len(self.checkins[self.checkins.uid == user]) - (1+old_loc_rate))
                                        sim.loc[(sim.u1 == user) & (sim.u2 == u), 'loc_rate'] = loc_new_rate
                                    else:
                                        old_loc_rate = sim.loc[(sim.u1 == u) & (sim.u2 == user), 'loc_rate'].values[0]
                                        loc_new_rate = (old_loc_rate * (len(u_checkins) + len(self.checkins[self.checkins.uid == user]) + 1) + 1) / (len(u_checkins) + len(self.checkins[self.checkins.uid == user]) - (1 + old_loc_rate))
                                        sim.loc[(sim.u1 == u) & (sim.u2 == user), 'loc_rate'] = loc_new_rate
                sim.loc[(sim.fri_rate >= 0) & (sim.u1 == u) & (sim.similarity >= delta3), 'loc_rate'] = 0
                sim.loc[(sim.fri_rate >= 0) & (sim.u1 == u) & (sim.similarity >= delta3), 'similarity'] = sim[(sim.fri_rate >= 0) & (sim.u1 == u) & (sim.similarity >= delta3)].apply(lambda x: x['loc_rate'] * delta1 + x['fri_rate'] * delta2, axis=1)  # 具有社交关系的用户对
                sim.loc[(sim.fri_rate >= 0) & (sim.u2 == u) & (sim.similarity >= delta3), 'loc_rate'] = 0
                sim.loc[(sim.fri_rate >= 0) & (sim.u2 == u) & (sim.similarity >= delta3), 'similarity'] = sim[(sim.fri_rate >= 0) & (sim.u2 == u) & (sim.similarity >= delta3)].apply(lambda x: x['loc_rate'] * delta1 + x['fri_rate'] * delta2, axis=1)  # 具有社交关系的用户对
            num = num + 1
            u_checkins = pd.DataFrame(u_checkins, columns=['uid', 'time', 'latitude', 'longitude', 'locid', 'locid_after','lat_after', 'lng_after'])
            u_checkins.to_csv(abspath + "\\data\\result_data_dp_11-15\\" + self.city + str(delta1) + str(delta2) + str(delta3) + str(delta4) + str(pri_delta) + str(rate) + str(times)+".csv", sep='\t', index=False, header=False, mode='a')
            self.checkins = self.checkins.drop(self.checkins[self.checkins.uid == u].index)
            self.checkins = pd.concat([self.checkins, u_checkins], ignore_index=True)
            self.checkins = self.checkins.sort_values(by='uid', ascending=True).reset_index(drop=True)
            # temp_checkins = pd.read_csv(abspath + "\\data\\result_data\\" + self.city + str(delta1) + str(delta2) + str(delta3) + str(delta4) + ".csv",delimiter="\t", index_col=None)
            # temp_checkins.columns = ['uid', 'time', 'latitude', 'longitude', 'locid', 'locid_after', 'lat_after', 'lng_after']
            # dealed_uids = list(temp_checkins.uid.unique())
            # undeal_checkins = self.checkins[~self.checkins.uid.isin(dealed_uids)]
            # temp_checkins = pd.concat([temp_checkins, undeal_checkins], ignore_index=True)
        sim.to_csv(abspath + "\\data\\result_data_dp_11-15\\" + self.city + str(delta1) + str(delta2) + str(delta3) + str(delta4) + str(pri_delta) + str(rate) + "_pairs_rate_after"+str(times)+".txt", index=False, header=False)


if __name__ == "__main__":

     # cal = cal_close_relation("GW_NY", 0.2)
     # cal.cal_pairs_relation()
     # sim = cal.read_rate(abspath + "\\data\\city_data\\" + cal.city + "_pairs_loc_rate.txt")
     #
     # sim.loc[:, 'similarity'] = 0
     # for i in [0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9, 1]:
     #     sim.loc[sim.fri_rate > 0, 'similarity'] = sim[sim.fri_rate > 0].apply(lambda x: x['loc_rate'] * i + x['fri_rate'] * (1-i), axis=1)  # 具有社交关系的用户对
     #     sim_over = deepcopy(sim[(sim.similarity >= 0.2) & (sim.fri_rate > 0)])  # 需要进行扰动的用户对
     #     sim_over1 = deepcopy(sim[(sim.similarity >= 0.2)])  # 需要进行扰动的用户对
     #     print(len(sim_over), len(sim_over1))
     # 40.74952375	-73.97490325555556	3909	8951	40.75576177083333	-73.98551864166667
     l = [40.75870611666667, -73.98517302444445]
     n = [40.75830688333333, -73.98398805111111]
     for i in [0.1, 1]:
           start = time.time()
           cal = cal_close_relation("GW_NY", 0.2)
           print(cal.euclidean_distance(l, n))
           # cal.cal_similarity1(0.6, 0.4, 0.06, 0.5, 0.8,i, 1, 1)
           print("时间：", (time.time() - start) / 60)