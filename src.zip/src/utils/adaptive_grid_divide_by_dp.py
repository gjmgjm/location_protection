#!/usr/bin/env python
# encoding: utf-8

import decimal
import math
import pandas as pd
import time
import os
import numpy as np
import random
import cmath
abspath = os.path.abspath('..')


class adaptive_grid_divide_by_dp():

    def __init__(self, city, ranges, delta_lat, delta_lon, delta_privacy, rate, delta_c1):  # 2是将时间分开的
        self.checkins = pd.read_csv(abspath + "\\data\\city_data\\" + city + "_2.csv", delimiter="\t", index_col=None)
        checkin1 = self.checkins.groupby(by=['locid', 'latitude', 'longitude']).size().reset_index(name="locid_time")
        self.locids = [row[0] for row in checkin1.itertuples(index=False, name=False)]   # 记录locid对应的经纬度，以便在替换locid时将相应的位置数据也进行替换
        self.lat_lon = [[row[1], row[2]] for row in checkin1.itertuples(index=False, name=False)]
        self.ranges = ranges  # 城市经纬度范围
        self.lat_len = len(self.checkins.latitude.unique())
        self.lon_len = len(self.checkins.longitude.unique())
        # 添加laplace噪声
        noise = np.random.laplace(0, 1/(rate * delta_privacy))
        noise_total_checkin_len = int(len(self.checkins)+noise)
        self.rate = rate   # 一层网格划分阶段分配隐私预算的比例
        self.delta_pri = delta_privacy
        # 开三次方根
        self.n = int(math.ceil(pow(rate*delta_privacy*noise_total_checkin_len/delta_c1, 1/2.5)))  # rate表示隐私预算分配的比例、delta_privacy表示隐私预算、delta_c1表示一层网格划分的参数
        print(self.n)
        self.m = self.n
        self.density_lat = delta_lat * self.lat_len / self.n  # 判断敏感区域的两个阈值，分别对应经度和纬度
        self.density_lon = delta_lon * self.lon_len / self.m
        self.city = city
        self.latInterval = decimal.Decimal.from_float(math.fabs(self.ranges[0] - self.ranges[2]) / self.n)  # 纬度为n，经度为m
        self.lngIntetval = decimal.Decimal.from_float(math.fabs(self.ranges[3] - self.ranges[1]) / self.m)  # 每个网格的间隔
        self.maxlat = decimal.Decimal(self.ranges[0])
        self.minlng = decimal.Decimal(self.ranges[1])
        self.first_gridnums = self.n * self.m-1
        self.grid = [i for i in range(self.n * self.m)]
        self.grid_range=[]
        self.cal_grid_ranges()

    def set_path(self, path, result_path):
        self.path = path
        self.result_path = result_path

    def cal_grid_ranges(self):    # 第一层网格的每个网格的范围
        for grid in self.grid:
            j = grid % self.m
            i = int((grid-j) / self.m)
            ranges = [float(self.maxlat - i * self.latInterval), float(self.minlng + j * self.lngIntetval),
                      float(self.maxlat - (i + 1) * self.latInterval), float(self.minlng + (j + 1) * self.lngIntetval)]
            self.grid_range.append(ranges)

    def cal_second_grid_range(self, grids, ranges, n, m, start_gridid):
        maxlat = decimal.Decimal(ranges[0])
        minlng = decimal.Decimal(ranges[1])
        latInterval = decimal.Decimal.from_float(math.fabs(ranges[0] - ranges[2]) / n)  # 纬度为n，经度为m
        lngIntetval = decimal.Decimal.from_float(math.fabs(ranges[3] - ranges[1]) / m)  # 二层网格的边长
        for grid in grids:
            self.grid.append(grid)
            j = (grid - start_gridid) % m
            i = int((grid - start_gridid - j) / self.m)
            second_ranges = [float(maxlat - i * latInterval), float(minlng + j * lngIntetval),
                      float(maxlat - (i + 1) * latInterval), float(minlng + (j + 1) * lngIntetval)]
            self.grid_range.append(second_ranges)

    def cal_gridid(self, checkin):
        i = math.floor((self.maxlat - decimal.Decimal(checkin[3])) / self.latInterval)
        j = math.floor((decimal.Decimal(checkin[4]) - self.minlng) / self.lngIntetval)
        checkin.append(int(i * self.m + j))
        return checkin

    # 按照N*N网格进行划分
    def divide_area_by_NN(self):  # 顶层网格划分
        checkin_new = []
        print("顶层网格划分中...")
        for row in self.checkins.itertuples(index=False, name=False):
            checkin = self.cal_gridid(list(row))
            checkin_new.append(checkin)
        checkins = pd.DataFrame(checkin_new, columns=['uid', 'date', 'time', 'latitude', 'longitude', 'locid', 'grid_id'])
        checkins.to_csv(abspath + "\\data\\"+ self.result_path + "\\" + self.city+"_"+str(self.n)+"_"+ str(self.m) + "_" +str(self.delta_pri)+".csv", index=False, header=False)
        print("顶层网格划分完成，正在划分第二层网格...")

    def cal_second_gridid(self, checkin, ranges, n, m, start_grid):
        latInterval = decimal.Decimal.from_float(math.fabs(ranges[0] - ranges[2]) / n)  # 纬度为n，经度为m
        lngIntetval = decimal.Decimal.from_float(math.fabs(ranges[3] - ranges[1]) / m)  # 二层网格的边长
        latitude = decimal.Decimal(checkin[3])
        longitude = decimal.Decimal(checkin[4])
        i = math.floor((decimal.Decimal(ranges[0]) - latitude) / latInterval)
        j = math.floor((longitude - decimal.Decimal(ranges[1])) / lngIntetval)
        checkin.append(int(i * m + j + start_grid))
        return checkin

    def second_divide(self, deltac):
        checkins = pd.read_csv(abspath + "\\data\\" + self.result_path + "\\" + self.city+"_"+str(self.n)+"_"+str(self.m)+ "_" +str(self.delta_pri)+".csv", delimiter=",", index_col=None,header=None)
        checkins.columns = ['uid', 'date', 'time', 'latitude', 'longitude', 'locid', 'grid_id']
        checkins_lat_len = checkins.groupby(by=['grid_id', 'latitude']).size().reset_index(name="grid_lat_times")
        checkins_lon_len = checkins.groupby(by=['grid_id', 'longitude']).size().reset_index(name="grid_lon_times")
        checkins_lat_lon_len = checkins_lat_len.groupby(by=['grid_id']).size().reset_index(name="grid_lat_times")
        checkins_lon_len1 = checkins_lon_len.groupby(by=['grid_id']).size().reset_index(name="grid_lon_times")
        checkins_lat_lon_len.loc[:, 'grid_lon_times'] = checkins_lon_len1['grid_lon_times']
        checkins_lat_lon_len.loc[:, 'is_dense'] = 0
        checkins_lat_lon_len.loc[(checkins_lat_lon_len.grid_lat_times >= self.density_lat) & (checkins_lat_lon_len.grid_lon_times >= self.density_lon), 'is_dense'] = 1
        # del checkins_lat_len, checkins_lon_len, checkins_lon_len1
        # gc.collect()
        grid_checkins_len = checkins.groupby(by=['grid_id']).size().reset_index(name="grid_times")
        second_divide_grid = checkins_lat_lon_len[checkins_lat_lon_len.is_dense == 1].grid_id.unique()
        second_divide_grid.sort()
        second_grid_range = []
        first_gridnums = self.first_gridnums
        total_grid = self.first_gridnums+1
        for gridid in second_divide_grid:
            j = gridid % self.m
            i = int((gridid-j) / self.m)
            ranges = [float(self.maxlat - i * self.latInterval), float(self.minlng + j * self.lngIntetval),
                     float(self.maxlat - (i + 1) * self.latInterval), float(self.minlng + (j + 1) * self.lngIntetval)]
            grid_visit_times = grid_checkins_len[grid_checkins_len.grid_id == gridid].grid_times.values[0]
            grid_visit_times += np.random.laplace(0, 1/((1-self.rate)*self.delta_pri))   # 添加噪声后的网格签到个数
            if grid_visit_times <= 0:
                grid_visit_times = grid_checkins_len[grid_checkins_len.grid_id == gridid].grid_times.values[0]
            n = int(math.ceil(pow((1-self.rate) * self.delta_pri * grid_visit_times / deltac, 1/2)))   # 重新计算的二层网格的个数,开三次方
            # n = int(math.ceil(math.sqrt((1-self.rate) * self.delta_pri * grid_visit_times / deltac)))  # 重新计算的二层网格的个数
            if n > 8:  # 控制范围
                n = 8
            m = n
            # print(m)
            second_grid_range.append([gridid, m, n, ranges, first_gridnums+1])
            # 新加的
            del self.grid_range[self.grid.index(gridid)]  # 删除二层网格的范围
            self.grid.remove(gridid)
            new_grid = [k for k in range(first_gridnums+1, first_gridnums+1+n * m)]
            self.cal_second_grid_range(new_grid, ranges, n, m, first_gridnums+1)
            first_gridnums = first_gridnums + n * m  # 单次网格划分的终点
            total_grid += n * m-1
        second_grid_range = pd.DataFrame(second_grid_range, columns=['grid_id', 'm', 'n', 'range', 'start_grid'])
        checkin_new = []
        for row in checkins.itertuples(index=False, name=False):
            if checkins_lat_lon_len[checkins_lat_lon_len.grid_id == row[6]].is_dense.values[0] == 1:
                grid_range = second_grid_range[second_grid_range.grid_id == row[6]]
                ranges = grid_range.range.values[0]
                n = grid_range.n.values[0]
                m = grid_range.m.values[0]
                start_grid = grid_range.start_grid.values[0]
                checkin = self.cal_second_gridid(list(row), ranges, n, m, start_grid)
                checkin.append(n)
                checkin.append(m)
                checkin.append(start_grid)
            else:
                checkin = list(row)
                checkin.append(row[6])
                checkin.append(1)
                checkin.append(1)
                checkin.append(0)
            checkin_new.append(checkin)
        checkins = pd.DataFrame(checkin_new, columns=['uid', 'date', 'time', 'latitude', 'longitude', 'locid', 'grid_id', 'grid_id_second', 'n', 'm', 'start_grid'])
        checkins.to_csv(abspath + "\\data\\" + self.result_path + "\\" + self.city + "_" + str(self.n) + "_" + str(self.m) + "_" +str(self.delta_pri)+ ".csv", index=False, header=False)
        lat_lon = self.get_loc_latlon()
        grid_lat_lon = [self.grid, lat_lon]
        grid_lat_lon = list(map(list, zip(*grid_lat_lon)))
        df = pd.DataFrame(grid_lat_lon, columns=['grid', "lat_lon"])
        df.to_csv(abspath + "\\data\\" + self.result_path+"\\" + str(self.delta_pri) + "locids.txt", index=False,header=False)
        print("第二层网格划分完成")
        print("位置总数", total_grid, len(self.grid))
        return checkins, self.grid, lat_lon

    def get_loc_latlon(self):
        # 在里面随机选择一点作为替代点
        lat_lon = []
        index = 0
        for grid in self.grid:
            grid_range = self.grid_range[self.grid.index(grid)]
            lat_max = grid_range[0]
            lon_mim = grid_range[1]
            lat_min = grid_range[2]
            lon_max = grid_range[3]
            random = np.random.RandomState(index)  # RandomState生成随机数种子
            lat = random.uniform(lat_min, lat_max)  # 随机数范围
            lon = random.uniform(lon_mim, lon_max)  # 随机数范围
            lat_lon.append([lat, lon])
            index = index +1
        return lat_lon

    @staticmethod
    def read_grid_latlon(filename):
        dict = []
        file = open(filename, "r")
        a = file.readline()
        while a:
            temp = a.strip().split(",")
            temp[1] = temp[1].replace("\"[", "")
            temp[2] = temp[2].replace("]\"", "")
            dict.append([int(temp[0]), [float(temp[1]), float(temp[2])]])
            a = file.readline()
        return dict

    def read_data(self):
        checkins = pd.read_csv(abspath + "\\data\\"+self.result_path + "\\" + self.city + "_" + str(self.n) + "_" + str(self.m) + ".csv", delimiter=",", index_col=None, header=None)
        checkins.columns = ['uid', 'date', 'time', 'latitude', 'longitude', 'locid', 'grid_id', 'grid_id_second',  'n', 'm', 'start_grid']
        # checkins = checkins.ix[:, [0, 2, 3, 4, 7, 10, 11, 12, 13, 14]]
        print(len(checkins.locid.unique()))
        checkin1 = checkins.groupby(by=["grid_id", 'grid_id_second', 'm', 'n', 'start_grid', 'gridlat_second', 'gridlon_second']).size().reset_index(name="locid_time")
        locids = [row[0] for row in checkin1.itertuples(index=False, name=False)]
        checkins2 = checkins.groupby(by=['grid_id_second', 'gridlat_second', 'gridlon_second']).size().reset_index(name="locid_time")
        print(len(checkins2), len(set(checkins2.grid_id_second.unique())))
        # print()


if __name__ == "__main__":
    # ny
    # start = time.time()
    # grid_divide = adaptive_grid_divide("GW_NY", 90, 90, [40.836357, -74.052914, 40.656702, -73.875168], 0.2, 0.2)
    # grid_divide.divide_area_by_NN()
    # grid_divide.second_divide(15)
    # # grid_divide.read_data()
    # end = time.time()
    # print("花费时间为：", str(end-start))
    # (self, city, ranges, delta_lat, delta_lon, delta_privacy, rate, delta_c1)
    # 0.2,0.2,0.5,20,5 #0.1 1 3 5   451 1300左右、2915 6007 8758
    # 0.2,0.2,0.5,25,5 #10  13582  451 1300左右、2384、3530、4501
    # 0.2,0.2,0.5,10,5 #0.1,1,3,5,10  7/309、16/1403、24/2335、29/3394、39/4734  文件city_data_adaptive_grid_dp_1
    #                                 7/302、16/1394、24/2322、29/3409、39/4719
    for privacy in [1, 3, 5, 10]:
    # for privacy in [10]:
        start = time.time()
        grid_divide = adaptive_grid_divide_by_dp("SNAP_SF", [37.809524, -122.520352, 37.708991, -122.358712], 0.2, 0.2, privacy, 0.5, 15)
        grid_divide.set_path("city_data", "city_data_adaptive_grid_dp_2")
        grid_divide.divide_area_by_NN()
        grid_divide.second_divide(5)
        end = time.time()
        print("花费时间为：", str(end - start))