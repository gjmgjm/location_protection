#!/usr/bin/env python
# encoding: utf-8

"""
@version: v1.0
@author: jaculamata
@license: Apache Licence
@contact: 819436557@qq.com
@site: http://blog.csdn.net/hqzxsc2006
@software: PyCharm
@file: 5_security.py
@time: 2019/1/20 15:44
"""
import pandas as pd
from numpy.linalg import norm
from scipy.stats import entropy
import numpy as np
import math
import os
from adaptive_grid_divide_by_dp import adaptive_grid_divide_by_dp
from cal_close_relation import cal_close_relation
import matplotlib.pylab as plt
import time
abspath = os.path.abspath('..')


def JSD(P, Q):
    _P = P / norm(P, ord=1)
    _Q = Q / norm(Q, ord=1)
    _M = 0.5 * (_P + _Q)
    return 0.5 * (entropy(_P, _M, base=2) + entropy(_Q, _M, base=2))


class security_unility():

    def __init__(self, city, pri_detla, times):

        self.checkins = pd.read_csv(abspath + "\\data\\result_data_dp_divide_lsc_01_09\\" + str(pri_detla)+"_"+str(times) + ".csv", delimiter=",", index_col=None, header=None)
        self.checkins.columns = ["uid", "date","time", "locid", "locid_after"]
        if city == "GW_NY":
            self.lons_per_km = 0.0059352 * 2  # NY
            self.lats_per_km = 0.0044966 * 2  # delta latitudes per kilo meter
        elif city == "GW_SF" or city == "SNAP_SF":
            self.lons_per_km = 0.005681 * 2  # SF
            self.lats_per_km = 0.004492 * 2  # delta latitudes per kilo meter
        elif city == "GW_AS":
            self.lons_per_km = 0.005681 * 2  # AS
            self.lats_per_km = 0.004492 * 2  # delta latitudes per kilo meter
        self.pri_delta = pri_detla
        self.city = city

    # 两点之间的欧氏距离计算
    def euclidean_distance(self, loc1, loc2):
        return math.sqrt(((loc1[1] - loc2[1]) / self.lons_per_km) ** 2 + ((loc1[0] - loc2[0]) / self.lats_per_km) ** 2)

    def d_security(self):
        print()
        print("全局位置访问频率分布改变情况")   # 全局位置访问频率分布改变情况，保护前后访问频率分布分别为Ta,Tb
        # start = time.time()
        checkin = self.checkins
        checkin_len = len(checkin)
        union_grid_id = list(set(checkin.locid_after.unique()).union(set(checkin.locid.unique())))
        checkin_vec = list(map((lambda x: len(checkin[checkin.locid_after == x]) * 1.0 / checkin_len), union_grid_id))
        checkin_obf_vec = list(map((lambda x: len(checkin[checkin.locid == x]) * 1.0 / checkin_len), union_grid_id))
        checkin_vec = np.array(list(checkin_vec))
        checkin_obf_vec = np.array(list(checkin_obf_vec))
        globle_security = JSD(checkin_vec, checkin_obf_vec)
        print("d:", globle_security)
        return globle_security

    def f_security(self):
        print()
        print("位置改变个数统计")
        nums = 0
        for row in self.checkins.itertuples(index=False, name=False):
            if row[4] != row[3]:
                nums += 1
        print("f:", nums)
        return nums

    def g_security(self):
        print()
        print("位置距离改变")
        locids_latlon = adaptive_grid_divide_by_dp.read_grid_latlon(abspath + "\\data\\city_data_adaptive_grid_dp_2\\" + str(self.pri_delta) + "locids.txt")
        locids = [row[0] for row in locids_latlon]
        lat_lon = [row[1] for row in locids_latlon]
        distance = 0
        count = 0
        for row in self.checkins.itertuples(index=False, name=False):
            if row[4] != row[3]:
                distance += self.euclidean_distance(lat_lon[locids.index(row[3])], lat_lon[locids.index(row[4])])
                count = count+1
        print("g:", distance/count)
        return distance/count

    def cellBasedKendallCoefficientOfVisitProb(self):
        # 位置访问频率的肯德尔系数K
        # 保序的定义为：对于两个位置a和b，若隐私保护前后a、b的访问频率相对大小不发生变化，则称位置a和b的访问频率是保序的。
        # 该指标数值越大说明地理位置可用性保持得越好
        orderedPairs = 0
        unorderedPairs = 0
        locids = self.checkins.locid_after.unique()
        locids_obf = self.checkins.locid.unique()
        union_grid_id = set(locids).union(set(locids_obf))
        checkin_vec = list(map((lambda x: len(self.checkins[self.checkins.locid_after == x])), union_grid_id))
        checkin_obf_vec = list(map((lambda x: len(self.checkins[self.checkins.locid == x])), union_grid_id))  # 真实位置访问频率分布
        for i in range(len(checkin_vec)-1):
            for j in range(i+1, len(checkin_vec)):
                real_ = checkin_obf_vec[i] - checkin_obf_vec[j]
                false_ = checkin_vec[i] - checkin_vec[j]
                if real_*false_ > 0:
                    orderedPairs = orderedPairs+1
                elif real_*false_ < 0:
                    unorderedPairs = unorderedPairs+1
                else:
                    if real_ == 0 and false_ == 0:
                        orderedPairs =orderedPairs+1
                    else:
                        unorderedPairs = unorderedPairs + 1
        kendall = (orderedPairs - unorderedPairs) / (len(union_grid_id) * (len(union_grid_id) - 1) * 0.5)
        return kendall

    def cal_security(self):
        d = self.d_security()
        g = self.g_security()
        kendall = self.cellBasedKendallCoefficientOfVisitProb()
        f = self.f_security()
        file = open(abspath + "\\data\\result_data\\" + self.city + "result.txt",  'a', encoding='UTF-8')
        file.write('扰动比例参数:' + str(self.pri_delta) + '\n')
        file.write('d:' + str(d) + ' ' + 'g:' + str(g) + ' f:' + str(f) +' kendall:' + str(kendall)+'\n')
        file.close()


if __name__ == "__main__":
    for pri in [0.1, 1, 3]:
        for i in [3]:
           print(i)
           cal = security_unility("SNAP_SF", pri, i)
           cal.cal_security()
