#!/usr/bin/env python
# encoding: utf-8

import numpy as np
from numpy.linalg import norm
from scipy.stats import entropy
from cal_friends_similarity import cal_friends_similarity


def JSD(P, Q):
    _P = P / norm(P, ord=1)
    _Q = Q / norm(Q, ord=1)
    _M = 0.5 * (_P + _Q)
    return 0.5 * (entropy(_P, _M, base=2) + entropy(_Q, _M, base=2))


class ccs_unility():

    def __init__(self):
        pass

    def set_checkins(self, checkins, checkins_obf):
        self.checkins = checkins
        self.checkins_obf = checkins_obf

    def d_security(self):

        print()
        print("全局位置访问频率分布改变情况")  # 全局位置访问频率分布改变情况，保护前后访问频率分布分别为Ta,Tb
        # start = time.time()
        checkin = self.checkins
        checkin_obf = self.checkins_obf
        checkin_len = len(checkin)
        checkin_obf_len = len(checkin_obf)
        union_grid_id = list(set(checkin.locid.unique()).union(set(checkin_obf.locid.unique())))
        checkin_vec = list(map((lambda x: len(checkin[checkin.locid == x]) * 1.0 / checkin_len), union_grid_id))
        checkin_obf_vec = list(map((lambda x: len(checkin_obf[checkin_obf.locid == x]) * 1.0 / checkin_obf_len), union_grid_id))
        checkin_vec = np.array(list(checkin_vec))
        checkin_obf_vec = np.array(list(checkin_obf_vec))
        globle_security = JSD(checkin_vec, checkin_obf_vec)
        print("d:", globle_security)
        return globle_security
