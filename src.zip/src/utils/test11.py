#!/usr/bin/env python
# encoding: utf-8  \
# from HMM1 import hmm_test1
#
# class test11():
#
#     def __init__(self):
#         pass
#
# if __name__ == "__main__":
#     for i in [3, 4, 5]:
#         hmm_test = hmm_test1("SNAP_SF", 1, 21, i)
#         # train_ABPI(self, delta1, delta2, delta3, delta4):# 地理，社交、亲密度阈值、
#         hmm_test.train_ABPI(0.6, 0.4, 0.12, 0.5)
import numpy as np
from sklearn.metrics.pairwise import cosine_similarity
import pandas as pd
x = np.array([[1, 2, 3], [4, 5, 6], [7, 8, 9]])
print(x)
b = np.array([[1, 1, 1]])
c = np.array([[1, 1, 1]])
print(b)
# x = np.array([np.insert(i, 0, 1) for i in x])  # 插入一整列
# x=np.c_[x, b] #添加整行元素，axis=1添加整列元素
# 求余弦相似度
c = np.array([[1, 2, 3], [4, 5, 6], [7, 8, 9]])
# y = cosine_similarity(x, c)  #
# print(y)
# y = y* np.array([[1, 2, 3]])
# print(y)
# y = np.array([[np.sum(x) for x in y]])
# print(y)
# y = y.sum(axis=1).reshape(1,-1)
# print(y)
# y = 2*b+ 1*y
# print(y)
# y = 1-y
# print(y)
dict1 = {"a":[1, 2, 3, 4],
        "b":[1, 1, 2, 2],
         "c":[1, 2, 3, 4]}
df = pd.DataFrame(dict1)
# print(df)
# data = df.groupby(by=["a", "b"])
# for group in data:
#     print(group[0][0])
#     print(group[1])

# df = pd.DataFrame(c)
# print(df)
stay_index, stay_values = [1, 2], [0, 0]
matrix = [[0] * 5] * (len(c))         # 原始 有5列
df = pd.DataFrame(matrix)
# [df.insert(stay_index[idx], stay_index[idx], stay_values[idx], allow_duplicates=True) for idx in range(len(stay_index))]
seek_index = list(set(range(5))-set(stay_index))   # [0, 3, 4] 需要求解
seek_index.sort()
i = 0
print(df)
for j in range(len(c[0])):  # 将需要求解的值，插入原始矩阵中
    loc_idx = seek_index[i]
    # print(df.loc[:, loc_idx])
    # print(c[:, [j]])
    df.loc[:, loc_idx] = c[:, [j]]
    i += 1

c = df.values
print(c)
# print(df)
# print(c)