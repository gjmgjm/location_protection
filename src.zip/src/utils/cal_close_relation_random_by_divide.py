#!/usr/bin/env python
# encoding: utf-8

import pandas as pd
import os
from joblib import Parallel, delayed
import multiprocessing as mp
import math
from itertools import repeat
import gc
import numpy as np
from copy import deepcopy
import time
from itertools import combinations
abspath = os.path.abspath('..')


class cal_close_relation_random_by_divide:

    def __init__(self, city, distance, N, M):
        self.checkins = pd.read_csv(abspath + "\\data\\city_data\\" + city + "_" + str(N) + "_" + str(M) + ".csv", delimiter=",", index_col=None)
        self.checkins.columns = ['uid', 'time', 'latitude', 'longitude', 'locid', 'gridlat', 'gridlon', 'grid_id']
        self.checkins = self.checkins.ix[:, [0, 1, 5, 6, 7]]
        self.checkins.rename(columns={"grid_id": "locid", "gridlat": "latitude", "gridlon":"longitude"}, inplace=True)  # 在原表上修改
        # print(self.checkins.columns)
        self.edges = pd.read_csv(abspath+"\\data\\city_data\\"+city+"_edgs.csv", delimiter="\t", index_col=None)
        self.edges.columns = ["u1", "u2"]
        self.city = city
        self.distance = distance  # km为单位
        checkin1 = self.checkins.groupby(by=['locid', 'latitude', 'longitude']).size().reset_index(name="locid_time")
        self.locids = [row[0] for row in checkin1.itertuples(index=False, name=False)]  # 记录locid对应的经纬度，以便在替换locid时将相应的位置数据也进行替换
        self.lat_lon = [[row[1], row[2]] for row in checkin1.itertuples(index=False, name=False)]
        del checkin1  # 释放checkin1的内存空间
        gc.collect()
        self.users = self.checkins.uid.unique()
        self.checkins.loc[:, "locid_after"] = self.checkins["locid"]
        self.checkins.loc[:, "lat_after"] = self.checkins["latitude"]
        self.checkins.loc[:, "lng_after"] = self.checkins["longitude"]
        self.lat_lon_df = pd.DataFrame(self.lat_lon, columns=['lat', 'lng'])
        if city == "GW_NY":
            self.lons_per_km = 0.0059352 * 2  # NY
            self.lats_per_km = 0.0044966 * 2  # delta latitudes per kilo meter
        elif city == "GW_NY":
            self.lons_per_km = 0.005681 * 2  # SF
            self.lats_per_km = 0.004492 * 2  # delta latitudes per kilo meter
        elif city == "GW_AS":
            self.lons_per_km = 0.005681 * 2  # AS
            self.lats_per_km = 0.004492 * 2  # delta latitudes per kilo meter
        self.n = N
        self.m = M

    def run(self, u, edges):
        u_friends = set(edges.u1.unique()).union(set(edges.u2.unique()))
        if len(u_friends) != 0:
            u_friends.remove(u)
        return [u, list(u_friends)]  # 用户u的好友

    def cal_relation1(self, pairs):
        core_num = mp.cpu_count()
        u_friends = Parallel(n_jobs=core_num)(delayed(self.run)(u, self.edges[(self.edges.u1 == u) | (self.edges.u2 == u)]) for u in self.users)
        u_friends = pd.DataFrame(u_friends, columns=['uid', 'friends'])
        print("好友计算完毕")
        fri_relation = []
        for row in pairs:  # 这里错了
            row1_friends = set(u_friends[u_friends.uid == row[0]].friends.values[0])
            if row[1] in row1_friends:   # 这才是真实存在的用户对
                row2_friends = set(u_friends[u_friends.uid == row[1]].friends.values[0])
                com_friends = row1_friends.intersection(row2_friends)
                union_friends = row1_friends.union(row2_friends)
                if len(union_friends) == 0:
                    fri_relation.append([row[0], row[1], 0])
                else:
                    fri_relation.append([row[0], row[1], len(com_friends) / len(union_friends)])
            else:
                fri_relation.append([row[0], row[1], -1])
        fri_relation = pd.DataFrame(fri_relation, columns=['u1', 'u2', 'fri_rate'])
        fri_relation.to_csv(abspath + "\\data\\city_data\\" + self.city + "_pairs_fri_rate_new1.csv", sep='\t', index=False, header=False)

    # 两点之间的欧氏距离计算
    def euclidean_distance(self, loc1, loc2):
        return math.sqrt(((loc1[1] - loc2[1]) / float(self.lons_per_km)) ** 2 + ((loc1[0] - loc2[0]) / float(self.lats_per_km)) ** 2)

    def run1(self, u1,u2, u1_locs, u2_locs):
        comlocs = list(u1_locs.intersection(u2_locs))
        return [u1, u2, len(comlocs) / len(set(u1_locs.union(u2_locs))), comlocs]  # 用户u的好友

    # 计算好友之间共同访问位置个数
    def cal_comlocs(self, pairs):
        index = 0
        for row in pairs:
            print(index)
            u1_locs = set(self.checkins[self.checkins.uid == row[0]].locid.unique())
            u2_locs = set(self.checkins[self.checkins.uid == row[1]].locid.unique())
            comlocs = list(u1_locs.intersection(u2_locs))
            index = index+1
            result = pd.DataFrame([[row[0], row[1], len(comlocs) / len(set(u1_locs.union(u2_locs))), comlocs]], columns=['u1', 'u2', 'loc_rate', 'comlocs'])
            result.to_csv(abspath + "\\data\\city_data\\" + self.city + "_pairs_loc_rate_new1.txt", sep='\t', index=False, header=False,mode='a')

        # 计算好友间好友比例
    def cal_pairs_relation(self):
        pairs = list(combinations(self.users, 2))
        # self.cal_relation1(pairs)
        self.cal_comlocs(pairs)

    def get_linju_locids(self, locid):
        left = locid - 1
        right = locid + 1
        top = locid - self.m
        below = locid + self.m
        reach_locids = []
        if (left != -1) & (left % self.m != self.m - 1):  # 判断当前位置的上下左右是否可以访问
            reach_locids.append(left)
        if (right != self.m * self.n) & (right % self.m != 0):
            reach_locids.append(right)
        if top > 0:
            reach_locids.append(top)
        if below < self.m * self.n:
            reach_locids.append(below)
        return reach_locids

    def choose_replace_locid(self, pre_locid, cur_locid, next_locid, locid_list, u_checkins, delta):  # u_checkins是改变后的距离
        cdt_locs = [self.lat_lon[self.locids.index(locid)] for locid in locid_list]
        pre_loc, cur_loc = self.lat_lon[self.locids.index(pre_locid)], self.lat_lon[self.locids.index(cur_locid)]
        next_loc = self.lat_lon[self.locids.index(next_locid)]
        pre_dis_list = list(map(self.euclidean_distance, cdt_locs, repeat(pre_loc)))
        cur_dis_list = list(map(self.euclidean_distance, cdt_locs, repeat(cur_loc)))
        next_dis_list = list(map(self.euclidean_distance, cdt_locs, repeat(next_loc)))
        weight_dis_list = np.sum([pre_dis_list, cur_dis_list, next_dis_list], axis=0).tolist()
        # 1114
        circle_locids = [self.get_linju_locids(loc) for loc in locid_list]
        # 1114
        u_locids = u_checkins.locid.unique()
        area_pro = [len(u_checkins[u_checkins.locid.isin(list(set(cir_loc).intersection(set(u_locids))))]) / len(u_checkins) for cir_loc in circle_locids]
        loc_dis = [locid_list, weight_dis_list, area_pro]
        loc_dis = list(map(list, zip(*loc_dis)))
        for i in range(len(loc_dis)):
            loc_dis[i][1] = math.exp(-loc_dis[i][1])
        loc_dis = pd.DataFrame(loc_dis, columns=['locid', 'dis', 'area_pro'])
        loc_dis.loc[:, 'dis'] = loc_dis.loc[:, 'dis'] / loc_dis.dis.sum()
        loc_dis.loc[:, 'weight_pro'] = loc_dis.apply(lambda x: x['dis'] * delta + x['area_pro']*(1-delta), axis=1)
        loc_dis.loc[:, 'weight_pro'] = loc_dis.loc[:, 'weight_pro'] / loc_dis.weight_pro.sum()
        loc_dis = loc_dis.sort_values(by=['weight_pro'], ascending=False).reset_index(drop=True)  # 按照距离降序排列
        weight_pro = [row[3] for row in loc_dis.itertuples(index=False, name=False)]
        candidate_loc = [row[0] for row in loc_dis.itertuples(index=False, name=False)]
        property = np.random.random()
        i = 0
        property_candidate = 0
        if property == 0:
            i = 0
        else:
            while property_candidate < property:  # 轮盘赌过程
                property_candidate += weight_pro[i]
                i += 1
            if property_candidate > property:
                i -= 1
        return candidate_loc[i]

    def read_rate(self, filename):  # 读取similarity的文件
        dict = []
        file = open(filename, "r")
        a = file.readline()
        while a:
            temp = a.strip().split("\t")
            temp[3] = temp[3].replace("[", "")
            temp[3] = temp[3].replace("]", "")
            u1_comlocs = temp[3].strip().split(",")
            if u1_comlocs[0] != '':
                u1_comlocs = list(map(lambda x: int(x.replace("'", "")), u1_comlocs))
            else:
                u1_comlocs = []
            dict.append([int(temp[0]), int(temp[1]), float(temp[2]), u1_comlocs])
            a = file.readline()
        file.close()
        friends = pd.read_csv(abspath + "\\data\\city_data\\" + self.city + "_pairs_fri_rate_new1.csv", delimiter="\t", index_col=None,header=None)
        friends.columns = ['u1', 'u2', 'fri_rate']
        checkins = pd.DataFrame(dict, columns=['u1', 'u2', 'loc_rate', 'comlocs'])
        checkins.loc[:, "fri_rate"] = friends['fri_rate']
        return checkins

    def get_friend_locids(self, pairs, u):
        friends = set(pairs.u1.unique()).union(set(pairs.u2.unique()))
        if len(friends) != 0:
            friends.remove(u)
        friends_locids = []  # 与用户u1具有社交关系的所有用户
        list(map(lambda x: friends_locids.extend(list(self.checkins[self.checkins.uid == x].locid_after.unique())), friends))
        friends_locids = list(set(friends_locids))
        return friends_locids

    def get_cdt(self, init_cdts, u):
        init_cdts.loc[:, 'dis'] = init_cdts.apply(lambda x: math.exp(u*x['dis']/2), axis=1)
        init_cdts.loc[:, 'dis'] = init_cdts.loc[:, 'dis']/init_cdts.dis.sum()
        init_cdts = init_cdts.sort_values(by=['dis'], ascending=False).reset_index(drop=True)
        weight_pro = [row[1] for row in init_cdts.itertuples(index=False, name=False)]
        candidate_loc = [row[0] for row in init_cdts.itertuples(index=False, name=False)]
        property = np.random.random()
        i = 0
        property_candidate = 0
        if property == 0:
            i = 0
        else:
            while property_candidate < property:  # 轮盘赌过程
                property_candidate += weight_pro[i]
                i += 1
            if property_candidate > property:
                i -= 1
        return candidate_loc[i]

    # 1114修改
    def cal_similarity1(self, delta1, delta2, delta3, delta4, k, times, rate):  # delta1为地理位置，delta2为社交关系
        sim = self.read_rate(abspath + "\\data\\city_data\\" + self.city + "_pairs_loc_rate_new" + str(self.n) + "_" + str(self.m) + ".txt")
        sim.loc[:, 'similarity'] = 0
        sim.loc[sim.fri_rate >= 0, 'similarity'] = sim[sim.fri_rate >= 0].apply(lambda x: x['loc_rate']*delta1 + x['fri_rate']*delta2, axis=1)  # 具有社交关系的用户对
        sim_over = deepcopy(sim[(sim.similarity >= delta3) & (sim.fri_rate >= 0)])  # 需要进行扰动的用户对
        num = 0
        for u in self.users:
            comlocs_list = sim_over[(sim_over.u1 == u) | (sim_over.u2 == u)].comlocs
            u_comloc = []  # 用户的共同访问位置
            if len(comlocs_list) != 0:
                list(map(lambda x: u_comloc.extend(x), comlocs_list))
                u_comloc = list(set(u_comloc))
            del comlocs_list  # 释放u_comlocs1, u_comlocs2的内存空间
            gc.collect()
            print(num, "获得所有共同访问位置")
            u_checkins = np.array(deepcopy(self.checkins[self.checkins.uid == u])).tolist()
            if len(u_comloc) != 0:
                # 用户好友的位置
                u1_friends_locids = self.get_friend_locids(self.edges[(self.edges.u1 == u) | (self.edges.u2 == u)], u)
                u1_choose_locids = set(self.locids) - set(u1_friends_locids) - set(u_comloc)
                del u1_friends_locids
                gc.collect()
                u_uncomlocs = set(self.checkins[self.checkins.uid == u].locid.unique()) - set(u_comloc)  # 用户u的非共同访问位置
                choose_locids = list(u_uncomlocs)
                temp_delta3 = delta3 * rate
                for i in range(len(u_checkins)):  # 单个用户的记录数
                    checkin = u_checkins[i]  # 单条签到记录
                    if checkin[4] in u_comloc:
                        # 1017_15 获得与用户U没有社交关系的用户的位置
                        if temp_delta3 != 0:
                            u1_pairs_locids = self.get_friend_locids(sim[((sim.u1 == u) | (sim.u2 == u)) & (sim.loc_rate < temp_delta3) & (sim.fri_rate == -1)], u)
                        else:
                            u1_pairs_locids = self.get_friend_locids(sim[((sim.u1 == u) | (sim.u2 == u)) & (sim.loc_rate <= temp_delta3) & (sim.fri_rate == -1)], u)
                        u1_choose_locids = set(u1_pairs_locids).intersection(u1_choose_locids).union(u_uncomlocs)
                        cdt_locs = [self.lat_lon[self.locids.index(locid)] for locid in u1_choose_locids]
                        pre_dis_list = list(map(self.euclidean_distance, cdt_locs, repeat(self.lat_lon[self.locids.index(checkin[4])])))
                        loc_dis = [u1_choose_locids, pre_dis_list]
                        loc_dis = list(map(list, zip(*loc_dis)))
                        # 1025删除
                        loc_dis = pd.DataFrame(loc_dis, columns=['locid', 'dis'])
                        loc_dis = loc_dis.sort_values(by=['dis'], ascending=True).reset_index(drop=True)
                        if (int(len(loc_dis)*k)+1) > 20:
                            loc_dis = loc_dis[0:20]       # 初步的位置筛选
                        else:
                            loc_dis = loc_dis[0:(int(len(loc_dis)*k)+1)]
                        u1_choose_locids = list(loc_dis.locid.values)
                        del u1_pairs_locids, cdt_locs, pre_dis_list, loc_dis
                        gc.collect()
                        pre_locid, next_locid = checkin[4], checkin[4]
                        if i > 0:
                            pre_locid = u_checkins[i - 1][5]
                        if i < len(u_checkins) - 1:
                            next_locid = u_checkins[i + 1][5]
                        if len(u1_choose_locids) != 0:
                            replace_locid = self.choose_replace_locid(pre_locid, checkin[4], next_locid, u1_choose_locids, self.checkins[self.checkins.uid == u], delta4)
                            lat_lon = self.lat_lon[self.locids.index(replace_locid)]
                            u_checkins[i][5] = replace_locid
                            u_checkins[i][6] = lat_lon[0]
                            u_checkins[i][7] = lat_lon[1]
                            if replace_locid in choose_locids:
                                pass
                            else:
                                choose_locids.append(replace_locid)
                                users = self.checkins[self.checkins.locid_after == replace_locid].uid.unique()  # 访问过新生成位置的所有用户
                                temp_u_checkins = pd.DataFrame(u_checkins, columns=['uid', 'time', 'latitude', 'longitude', 'locid','locid_after', 'lat_after', 'lng_after'])
                                for user in users:
                                    u_locs = set(temp_u_checkins.locid_after.unique())
                                    user_locs = set(self.checkins[self.checkins.uid == user].locid_after.unique())
                                    comlocs = list(u_locs.intersection(user_locs))
                                    loc_new_rate = len(comlocs) / len(u_locs.union(user_locs))
                                    if u > user:
                                        sim.loc[(sim.u1 == user) & (sim.u2 == u), 'loc_rate'] = loc_new_rate
                                    else:
                                        sim.loc[(sim.u1 == u) & (sim.u2 == user), 'loc_rate'] = loc_new_rate
                sim.loc[(sim.fri_rate >= 0) & (sim.u1 == u) & (sim.similarity >= delta3), 'loc_rate'] = 0
                sim.loc[(sim.fri_rate >= 0) & (sim.u1 == u) & (sim.similarity >= delta3), 'similarity'] = sim[(sim.fri_rate >= 0) & (sim.u1 == u) & (sim.similarity >= delta3)].apply(lambda x: x['loc_rate'] * delta1 + x['fri_rate'] * delta2, axis=1)  # 具有社交关系的用户对
                sim.loc[(sim.fri_rate >= 0) & (sim.u2 == u) & (sim.similarity >= delta3), 'loc_rate'] = 0
                sim.loc[(sim.fri_rate >= 0) & (sim.u2 == u) & (sim.similarity >= delta3), 'similarity'] = sim[(sim.fri_rate >= 0) & (sim.u2 == u) & (sim.similarity >= delta3)].apply(lambda x: x['loc_rate'] * delta1 + x['fri_rate'] * delta2, axis=1)  # 具有社交关系的用户对
            sim.loc[(sim.u2 == u) & (sim.u1 < u), 'comlocs'] = sim.loc[(sim.u2 == u) & (sim.u1 < u)].apply(lambda x: 0, axis=1)
            sim_over.loc[(sim.u2 == u) & (sim.u1 < u), 'comlocs'] = sim_over.loc[(sim.u1 == u) & (sim.u2 < u)].apply(lambda x: 0, axis=1)
            num = num + 1
            u_checkins = pd.DataFrame(u_checkins, columns=['uid', 'time', 'latitude', 'longitude', 'locid', 'locid_after','lat_after', 'lng_after'])
            u_checkins.to_csv(abspath + "\\data\\result_data_random_divide_11-17\\" + self.city + str(delta1) + str(delta2) + str(delta3) + str(delta4) + str(rate) + str(times)+str(self.n)+str(self.m)+".csv", sep='\t', index=False, header=False, mode='a')
            self.checkins = self.checkins.drop(self.checkins[self.checkins.uid == u].index)
            self.checkins = pd.concat([self.checkins, u_checkins], ignore_index=True)
            self.checkins = self.checkins.sort_values(by='uid', ascending=True).reset_index(drop=True)
        sim.to_csv(abspath + "\\data\\result_data_random_divide_11-17\\" + self.city + str(delta1) + str(delta2) + str(delta3) + str(delta4) + str(rate) + "_pairs_rate_after"+str(times)+str(self.n)+str(self.m)+".txt", index=False, header=False)


if __name__ == "__main__":

     # cal = cal_close_relation("GW_NY", 0.2, 50, 50)
     # cal.cal_pairs_relation()
     # for i in [0, 0.1, 0.2]:
           start = time.time()
           cal = cal_close_relation_random_by_divide("GW_NY", 0.2, 90, 90)
           cal.cal_similarity1(0.6, 0.4, 0.094, 0.5, 0.8, 1, 1)
           print("时间：", (time.time() - start) / 60)