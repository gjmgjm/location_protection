#!/usr/bin/env python  
# encoding: utf-8  

""" 
@version: v1.0 
@author: jaculamata 
@license: Apache Licence  
@contact: 819436557@qq.com 
@site: http://blog.csdn.net/hqzxsc2006 
@software: PyCharm 
@file: 2_grid_divide.py 
@time: 2019/1/20 15:38 
"""
import decimal
import math
import multiprocessing
import pandas as pd
import time
import os
abspath = os.path.abspath('..')


class grid_divide():

    def __init__(self, city, N, M, ranges):
        self.checkins = pd.read_csv(abspath + "\\data\\city_data\\" + city + "_1.csv", delimiter="\t", index_col=None)  # 一个城市的数据
        self.ranges = ranges    # 城市经纬度范围
        self.n = N              # 划分网格数
        self.m = M              #
        self.latInterval = decimal.Decimal.from_float(math.fabs(self.ranges[0] - self.ranges[2]) / self.n)  #纬度为n，经度为m
        self.lngIntetval = decimal.Decimal.from_float(math.fabs(self.ranges[3] - self.ranges[1]) / self.m)
        self.maxlat = decimal.Decimal(self.ranges[0])
        self.minlng = decimal.Decimal(self.ranges[1])
        self.city = city
        # maxlat, minlng, minlat, maxlng = self.ranges[0], self.ranges[1], self.ranges[2], self.ranges[3]

    def get_grid(self, latitude, longitude):
        i = math.floor((self.maxlat - latitude) / self.latInterval)
        j = math.floor((longitude - self.minlng) / self.lngIntetval)
        return int(i * self.m + j)

    def cal_gridid(self, checkin):
        latitude = decimal.Decimal(checkin[2])
        longitude = decimal.Decimal(checkin[3])
        i = math.floor((self.maxlat - latitude) / self.latInterval)
        j = math.floor((longitude - self.minlng) / self.lngIntetval)
        gridlat = float(self.maxlat - i * self.latInterval - self.latInterval / 2)
        gridlon = float(self.minlng + j * self.lngIntetval + self.lngIntetval / 2)
        checkin.append(gridlat)
        checkin.append(gridlon)
        checkin.append(int(i * self.m + j))
        return checkin

    # 按照N*N网格进行划分
    def divide_area_by_NN(self):
        checkin_new = []
        index = 0
        for row in self.checkins.itertuples(index=False, name=False):
            checkin = self.cal_gridid(list(row))
            checkin_new.append(checkin)
            print(index)
            index =index+1
        checkins = pd.DataFrame(checkin_new, columns=['uid', 'time', 'latitude', 'longitude', 'locid', 'gridlat', 'gridlon', 'grid_id'])
        checkins.to_csv(abspath + "\\data\\city_data" + "\\" + self.city+"_"+str(self.n)+"_"+str(self.m)+".csv", index=False, header=False)
        print("该城市网格划分完成")


if __name__ == "__main__":
    start = time.time()
    grid_divide = grid_divide("GW_NY", 100, 100, [40.836357, -74.052914, 40.656702, -73.875168])
    grid_divide.divide_area_by_NN()
    end = time.time()
    print("花费时间为：", str(end-start))