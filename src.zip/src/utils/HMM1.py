#!/usr/bin/env python
# encoding: utf-8
"""
@version: v1.0
@author: jimi
@license: Apache Licence
@contact: 977510628@qq.com
@software: PyCharm
@file: hmm.py
@time: 2019/12/27
"""
from hmmlearn import hmm
from copy import deepcopy
import numpy as np
import pandas as pd
import os
import re
from adaptive_grid_divide_by_dp import adaptive_grid_divide_by_dp
from cal_friends_similarity import cal_friends_similarity
import geatpy as ea                # import geatpy
from MyProblem2 import MyProblem2  # 导入自定义问题接口
from update_features import update_features
from sklearn.metrics.pairwise import cosine_similarity


abspath = os.path.abspath('..')
time_piecies = [['00:00:00', '03:00:00'], ['03:00:00', '06:00:00'], ['06:00:00', '09:00:00'],
                ['09:00:00', '12:00:00'], ['12:00:00', '15:00:00'], ['15:00:00', '18:00:00'],
                ['18:00:00', '21:00:00'], ['21:00:00', '23:59:59']]


class hmm_test1():

    def __init__(self, city, privacy, n,times):
        self.city = city
        self.privacy = privacy
        self.n = n
        self.times__ = times

    def read_data_by_day(self):   # 以天划分轨迹
        checkins = pd.read_csv(abspath + "\\data\\city_data_adaptive_grid_dp" + "\\" + "SNAP_SF" + "_" + str(self.n) + "_" + str(self.n) + "_" + str(self.privacy) + ".csv", delimiter=",", index_col=None, header=None)
        checkins.columns = ['uid', 'time', 'latitude', 'longitude', 'locid', 'grid_id', 'grid_id_second', 'n', 'm', 'start_grid']
        checkins = checkins.ix[:, [0, 1, 6]]
        checkins.rename(columns={"grid_id_second": "locid"}, inplace=True)
        checkins.sort_values(by=['uid', "time"], ascending=True, inplace=True)  # 按照时间先后进行排序
        checkins.loc[:, "time"] = checkins['time'].apply(lambda x: re.search(r'\d+:\d+:\d+', x).group())  # 时间不看日期，只看时分秒
        checkins = self.__changetime_topeices(checkins)   # 将时间转换成时间段
        checkins.drop(['time'], axis=1, inplace=True)  # 删除多余的列
        checkins.rename(columns={"new_time": "time"}, inplace=True)
        # locid需要所有的位置以及对应的经纬度
        locids_latlon = adaptive_grid_divide_by_dp.read_grid_latlon(abspath + "\\data\\city_data_adaptive_grid_dp\\" + str(self.privacy) + "locids.txt")
        locids = [row[0] for row in locids_latlon]
        self.lat_lon = [row[1] for row in locids_latlon]
        self.freq_vector = [len(checkins[checkins.locid == locid])/len(checkins) for locid in locids]
        similarity = cal_friends_similarity.read_rate(abspath + "\\data\\city_data_adaptive_grid_dp\\" + self.city + "_pairs_loc_rate_new_lsc"+str(self.privacy)+".txt", self.city, self.privacy)
        return checkins, locids, similarity

    def __changetime_topeices(self, checkins):
        checkins.loc[:, "new_time"] = -1
        for i in range(len(time_piecies)):
            checkins.loc[(pd.to_datetime(checkins.time, format='%H:%M:%S') >= pd.to_datetime(time_piecies[i][0], format='%H:%M:%S'))& (pd.to_datetime(checkins.time, format='%H:%M:%S') < pd.to_datetime(time_piecies[i][1], format='%H:%M:%S')), "new_time"] = i
        checkins.loc[checkins.new_time == -1, "new_time"] = len(time_piecies)-1
        return checkins

    def __build_model(self, start_pro, trans_pro, emi_pro, n_states):
        model = hmm.MultinomialHMM(n_components=n_states)
        model.startprob_ = start_pro
        model.transmat_ = trans_pro
        model.emissionprob_ = emi_pro
        return model

    def aimFunc(self, pop, original_vector, friends_vectors, friends_delta, weight_delta, uncomloc_indexs, stay_x):   # 目标函数
        Vars = pop.Phen       # 得到决策变量矩阵
        for idx in range(len(uncomloc_indexs)):       # 将保留值插入向量中,是不可能为0的
            Vars = np.array([np.insert(i, uncomloc_indexs[idx], stay_x[idx]) for i in Vars])
        sim_orignal = 1 - cosine_similarity(Vars, original_vector)
        sim_friends = cosine_similarity(Vars, friends_vectors) * friends_delta
        sim_friends = sim_friends.sum(axis=0).reshape(1, -1)      # 矩阵每行求和之后变成二维数组
        sim_weight = weight_delta[0] * sim_orignal + weight_delta[1] * sim_friends
        stay_x_values = 1 - np.sum(np.array(stay_x))  # 剩余的值
        for i in range(len(Vars[0])):
            stay_x_values = stay_x_values - pop.Phen[:, [i]]
        pop.CV = np.hstack([np.abs(stay_x_values)])  # 利用可行性法则处理约束条件
        pop.ObjV = sim_weight        # 把求得的目标函数值赋值给种群pop的ObjV

    # def aimFunc(self, Phen, original_vector, friends_vectors, friends_delta, weight_delta):  # 目标函数
    #     Vars = Phen  # 得到决策变量矩阵
    #     f = []
    #     for index in range(len(Vars)):
    #         x = Vars[index]  # 一个解
    #         sim_orignal = cosine_similarity([x.tolist()], [original_vector])[0][0]
    #         sim_orignal = 1 - sim_orignal
    #         if len(friends_vectors) != 0:
    #             sim_friends = []  # 与好友的相似度
    #             for friend_index in range(len(friends_vectors)):
    #                 fri_sim = cosine_similarity([x.tolist()], [friends_vectors[friend_index]])[0][0]
    #                 sim_friends.append(friends_delta[friend_index] * fri_sim)  # 好友亲密度权重以及皮尔森相似度
    #             sim_friends = np.sum(np.array(sim_friends))
    #             sim_weight = np.sum(np.multiply(np.array(weight_delta), np.array([sim_orignal, sim_friends])))
    #         else:
    #             sim_weight = sim_orignal * weight_delta[0]
    #         f.append([sim_weight])
    #     return f.index(min(f))

    def mutiobject_update(self, original_vector, friends_vectors, friends_delta, weight_delta):

        """================================实例化问题对象==========================="""
        problem = MyProblem2(original_vector, friends_vectors, friends_delta, weight_delta)  # 生成问题对象
        """==================================种群设置==============================="""
        Encoding = 'BG'  # 编码方式
        NIND = 50  # 种群规模
        Field = ea.crtfld(Encoding, problem.varTypes, problem.ranges, problem.borders)  # 创建区域描述器
        population = ea.Population(Encoding, Field, NIND)  # 实例化种群对象（此时种群还没被初始化，仅仅是完成种群对象的实例化）
        """================================算法参数设置============================="""
        myAlgorithm = ea.moea_NSGA3_templet(problem, population)  # 实例化一个算法模板对象
        myAlgorithm.MAXGEN = 50  # 最大进化代数
        """==========================调用算法模板进行种群进化========================"""
        NDSet = myAlgorithm.run()  # 执行算法模板，得到帕累托最优解集NDSet
        Phen = NDSet.Phen
        print(Phen)
        if len(Phen) != 0:   # 有解
            #  aimFunc(self, Phen, original_vector, friends_vectors, friends_delta, weight_delta, stay_x, uncomloc_indexs)
            min = self.aimFunc(Phen, original_vector, friends_vectors, friends_delta, [0.5, 0.5])
            return Phen[min]
        return Phen

    def mutiobject_update1(self, original_vector, friends_vectors, friends_delta, weight_delta):
        """================================实例化问题对象==========================="""
        problem = MyProblem2(original_vector, friends_vectors, friends_delta, weight_delta)  # 生成问题对象
        """==================================种群设置==============================="""
        Encoding = 'RI'  # 编码方式
        NIND = 50  # 种群规模
        Field = ea.crtfld(Encoding, problem.varTypes, problem.ranges, problem.borders)  # 创建区域描述器
        population = ea.Population(Encoding, Field, NIND)  # 实例化种群对象（此时种群还没被初始化，仅仅是完成种群对象的实例化）
        """================================算法参数设置============================="""
        myAlgorithm = ea.soea_DE_rand_1_L_templet(problem, population)  # 实例化一个算法模板对象
        myAlgorithm.MAXGEN = 200  # 最大进化代数
        myAlgorithm.mutOper.F = 0.5  # 差分进化中的参数F
        myAlgorithm.recOper.XOVR = 0.7  # 重组概率
        """===========================调用算法模板进行种群进化======================="""
        [population, obj_trace, var_trace] = myAlgorithm.run()  # 执行算法模板
        # population.save()  # 把最后一代种群的信息保存到文件中
        # 输出结果
        best_gen = np.argmin(problem.maxormins * obj_trace[:, 1])  # 记录最优种群个体是在哪一代
        best_ObjV = obj_trace[best_gen, 1]
        print('最优的目标函数值为：%s' % (best_ObjV))
        print('最优的决策变量值为：')
        for i in range(var_trace.shape[1]):
            print(var_trace[best_gen, i])
        print('有效进化代数：%s' % (obj_trace.shape[0]))
        print('最优的一代是第 %s 代' % (best_gen + 1))
        print('评价次数：%s' % (myAlgorithm.evalsNum))
        print('时间已过 %s 秒' % (myAlgorithm.passTime))
        return var_trace[best_gen]

    def train_ABPI(self, delta1, delta2, delta3, delta4):
        checkins, locids, similarity = self.read_data_by_day()
        similarity.loc[:, 'sim'] = 0
        similarity.loc[similarity.fri_rate >= 0, 'sim'] = similarity[similarity.sim >= 0].apply(lambda x: x['loc_rate'] * delta1 + x['fri_rate'] * delta2, axis=1)  # 具有社交关系的用户对
        sim_over = deepcopy(similarity[(similarity.sim >= delta3) & (similarity.fri_rate >= 0)])
        # 获得好友的相似度
        n_states = len(locids)
        user_checkins = checkins.groupby(["uid"])  # 按照用户id对数据进行分组,从小到大排序
        # 首先获取所有用户的位置访问频率分部向量
        data = []
        for group in user_checkins:
            # print("用户"+str(group[0])+"模型参数更新中...")
            u_locids = list(group[1].locid.values)
            u_locids_len = len(u_locids)
            start_pro = [u_locids.count(x) / u_locids_len for x in locids]  # 地点的初始概率
            # print("初始状态矩阵A参数获取完成")
            data.append([group[0], start_pro])
        data = pd.DataFrame(data, columns=["uid", "start_pro"])

        disturb_checkins = pd.DataFrame()
        for row in data.itertuples(index=False, name=False):
            print("用户"+str(row[0])+"模型参数更新中...")
            friends = sim_over[(sim_over.u1 == row[0]) | (sim_over.u2 == row[0])]
            friends = list(set(friends.u1.unique()).union(set(friends.u2.unique())))
            friends.sort()
            if len(friends) != 0:      # 得到用户的好友
                friends.remove(row[0])
            friends_vectors = list(data[data.uid.isin(friends)].start_pro.values)
            # print(sim_over[(sim_over.u1 == row[0]) | (sim_over.u2 == row[0])])
            original_vector = row[1]
            friends_delta = []
            for fri in friends:
                if fri > row[0]:
                    friends_delta.append(similarity[(similarity.u1 == row[0])&(similarity.u2 == fri)].sim.values[0])
                else:
                    friends_delta.append(similarity[(similarity.u1 == fri) & (similarity.u2 == row[0])].sim.values[0])
            comloc_indexs = []  # 共同访问位置
            for f_vector in friends_vectors:  # 好友的位置访问频率向量
                new_list = np.multiply(np.array(original_vector), np.array(f_vector))  # 两个向量对应相乘
                common_loc_index = np.flatnonzero(new_list).tolist()  # 不为0的地方就是共同访问位置的索引
                comloc_indexs.extend(common_loc_index)
            comloc_indexs = list(set(comloc_indexs))  # 去重
            # print(original_vector)
            # print(friends_vectors)
            # updated_vector = list(self.mutiobject_update1(original_vector, friends_vectors, friends_delta, [0.5, 0.5]))
            updated_vector = []
            print("    状态矩阵A参数更新完成")
            # 获取当前用户的转移矩阵
            tras_pro = np.zeros((n_states, n_states))  # 转移矩阵
            u_locids = list(checkins[checkins.uid == row[0]].locid.values)
            u_locids_len = len(u_locids)
            for index in range(u_locids_len):
                if (index + 1) != u_locids_len:
                    next = index + 1
                    cur_locid = u_locids[index]
                    next_locid = u_locids[next]
                    tras_pro[locids.index(cur_locid)][locids.index(next_locid)] += 1  # 更新转移矩阵
            # 将转移矩阵每一行的概率和转换成1
            col_len = tras_pro.shape[1]
            for k, line in enumerate(tras_pro):
                sum1 = np.sum(line)
                if sum1 != 0:  # 一行的和不为0
                    for i in range(col_len):
                        if tras_pro[k][i] != 0:
                            tras_pro[k][i] = tras_pro[k][i] / sum1
            # print("初始转移矩阵B参数获取完成")

            # 得到发射矩阵
            emi_pro = np.zeros((n_states, 8))  # 发射矩阵
            u_locid_times = checkins[checkins.uid == row[0]].groupby(by=['locid', 'time']).size().reset_index(name="u_times")
            for _ in u_locid_times.itertuples(index=False, name=False):
                emi_pro[locids.index(_[0])][int(_[1])] = _[2]
            col_len = emi_pro.shape[1]
            for k, line in enumerate(emi_pro):
                sum1 = np.sum(line)
                if np.sum(line) != 0:
                    for i in range(col_len):
                        if emi_pro[k][i] != 0:
                            emi_pro[k][i] = emi_pro[k][i] / sum1

            # 如果访问向量没有更新，则不用更新转移矩阵和发射矩阵
            if len(updated_vector) != 0:
                update_feature = update_features(original_vector, updated_vector, tras_pro, emi_pro, self.lat_lon, self.freq_vector, comloc_indexs, self.city)
                updated_tras = update_feature.update_transmat(delta4)
                updated_emi =update_feature.update_emi()
                updated_vector = np.array(updated_vector)
                tras_pro = np.array(updated_tras)
                emi_pro = np.array(updated_emi)
            else:
                updated_vector = np.array(original_vector)

            # 归一化
            col_len = tras_pro.shape[1]
            for k, line in enumerate(tras_pro):
                sum1 = np.sum(line)
                if sum1 != 0:  # 一行的和不为0
                    for i in range(col_len):
                        if tras_pro[k][i] != 0:
                            tras_pro[k][i] = tras_pro[k][i] / sum1
                else:  # 一行的和为0,则给它一个均匀分布
                    for i in range(col_len):
                        tras_pro[k][i] = 1/col_len
            print("    转移矩阵B参数更新完成")
            col_len = emi_pro.shape[1]
            for k, line in enumerate(emi_pro):
                sum1 = np.sum(line)
                if np.sum(line) != 0:
                    for i in range(col_len):
                        if emi_pro[k][i] != 0:
                            emi_pro[k][i] = emi_pro[k][i] / sum1
                else:
                    for i in range(col_len):
                        emi_pro[k][i] = 1 / col_len
            print("   发射矩阵π参数更新完成")

            # print(updated_vector)
            times_ = list(checkins[checkins.uid == row[0]].time.values)  # 每个时刻都作为一个观测序列
            list_new = [[t] for t in times_]
            observations = np.array(list_new)
            results = self.predict(updated_vector, tras_pro, emi_pro, observations)
            u_checkins = deepcopy(checkins[checkins.uid == row[0]])  # 复制原始的数据
            disturb_locids = [locids[index] for index in results]
            u_checkins.loc[:, 'locid_after'] = disturb_locids
            disturb_checkins = pd.concat([disturb_checkins, u_checkins], ignore_index=True)
            disturb_checkins.to_csv(abspath + "\\data\\result_data_dp_divide_lsc_12_27\\"+str(self.privacy) + "_" + str(self.times__) + ".csv", index=False, header=False, mode='a')

    def predict(self, A, B, PI, observations):
        hidden_states = self.__build_model(A, B, PI, len(A)).predict(observations)
        return hidden_states


if __name__ == "__main__":
    for i in [1, 2, 3, 4, 5]:
        hmm_test = hmm_test1("SNAP_SF", 0.1, 11, i)
        # train_ABPI(self, delta1, delta2, delta3, delta4):# 地理，社交、亲密度阈值、
        hmm_test.train_ABPI(0.6, 0.4, 0.12, 0.5)
