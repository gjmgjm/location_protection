# -*- coding: utf-8 -*-
import numpy as np
import geatpy as ea
import cmath
from sklearn.metrics.pairwise import cosine_similarity

"""
该案例展示了一个离散决策变量的最小化目标的双目标优化问题。
min f1 = -25 * (x1 - 2)**2 - (x2 - 2)**2 - (x3 - 1)**2 - (x4 - 4)**2 - (x5 - 1)**2
min f2 = (x1 - 1)**2 + (x2 - 1)**2 + (x3 - 1)**2 + (x4 - 1)**2 + (x5 - 1)**2
s.t.
x1 + x2 >= 2
x1 + x2 <= 6
x1 - x2 >= -2
x1 - 3*x2 <= 2
4 - (x3 - 3)**2 - x4 >= 0
(x5 - 3)**2 + x4 - 4 >= 0
x1,x2,x3,x4,x5 ∈ {0,1,2,3,4,5,6,7,8,9,10}
"""


class MyProblem1(ea.Problem):  # 继承Problem父类

    def __init__(self, original_vector, friends_vectors, friends_delta, weight_delta, lat_lon, city):
        comloc_indexs = []   # 共同访问位置
        for f_vector in friends_vectors:   # 好友的位置访问频率向量
            new_list = np.multiply(np.array(original_vector), np.array(f_vector))   # 两个向量对应相乘
            common_loc_index = np.flatnonzero(new_list).tolist()                   # 不为0的地方就是共同访问位置的索引
            comloc_indexs.extend(common_loc_index)
        comloc_indexs = set(comloc_indexs)                                         # 去重
        unvisited_locidx = set([index for index in range(len(original_vector)) if original_vector[index] == 0])  # 用户未访问的位置
        self.comloc_indexs = comloc_indexs
        # 用户保留的非共同访问位置
        self.uncomloc_indexs = list(set([i for i in range(len(original_vector))])-unvisited_locidx-comloc_indexs)
        self.uncomloc_indexs.sort()
        self.stay_x = [original_vector[index] for index in self.uncomloc_indexs]    # 用户保留的向量的一部分值
        self.original_vector = original_vector                                      # 用户原始的访问频率向量
        self.friends_vectors = friends_vectors                                      # 用户好友的访问向量
        self.friends_delta = friends_delta                                          # 用户好友的亲密度权重
        self.original_flatnonzero = np.flatnonzero(original_vector).tolist()        # 用户访问过的位置索引
        self.lat_lon = lat_lon                                                      # 所有位置的经纬度
        self.weight_delta = weight_delta                                            # 相似度和距离的权重函数
        print("好友的向量长度为：", len(self.friends_vectors))
        print(self.friends_vectors)
        if city == "GW_NY":
            self.lons_per_km = 0.0059352 * 2  # NY
            self.lats_per_km = 0.0044966 * 2  # delta latitudes per kilo meter
        elif city == "GW_SF" or city == "SNAP_SF":
            self.lons_per_km = 0.005681 * 2  # SF
            self.lats_per_km = 0.004492 * 2  # delta latitudes per kilo meter
        elif city == "GW_AS":
            self.lons_per_km = 0.005681 * 2  # AS
            self.lats_per_km = 0.004492 * 2  # delta latitudes per kilo meter
        name = 'MyProblem'                                                          # 初始化name（函数名称，可以随意设置）
        Dim = len(original_vector) - len(self.uncomloc_indexs)                      # 初始化Dim（决策变量维数）
        self.Dim = Dim
        M = 1
        maxormins = [1] * M   # 初始化maxormins（目标最小最大化标记列表，1：最小化该目标；-1：最大化该目标）
        varTypes = [0] * Dim  # 初始化varTypes（决策变量的类型，0：实数；1：整数）
        lb = [0] * Dim        # 决策变量下界
        ub = [1 - np.sum(np.array(self.stay_x))] * Dim       # 决策变量上界
        lbin = [1] * Dim      # 决策变量下边界
        ubin = [1] * Dim      # 决策变量上边界  “上下边界”是俗称的决策变量范围的“开闭区间”。例如如果上边界设为1，表示变量区间范围是“右闭”的，如果上边界设为0，表示变量区间范围是“右开”的。
        # 调用父类构造方法完成实例化
        ea.Problem.__init__(self, name, M, maxormins, Dim, varTypes, lb, ub, lbin, ubin)

    def get_comidx(self):
        return self.comloc_indexs

    def get_uncomidx(self):
        return self.uncomloc_indexs

    def get_stay_x(self):
        return self.stay_x

    def PersonCorrelation(self, x, y):
        x_ = x - np.mean(x)
        y_ = y - np.mean(y)
        d1 = np.dot(x_, y_) / (np.linalg.norm(x_) * np.linalg.norm(y_))
        return d1

    # 两点之间的欧氏距离计算
    def euclidean_distance(self, loc1, loc2):
        return cmath.sqrt(((loc1[1] - loc2[1]) / float(self.lons_per_km)) ** 2 + ((loc1[0] - loc2[0]) / float(self.lats_per_km)) ** 2)

    def aimFunc(self, pop):   # 目标函数
        Vars = pop.Phen       # 得到决策变量矩阵
        stay_x_values = [1 - np.sum(np.array(self.stay_x))] * self.Dim  # 剩余的值
        f = []
        for index in range(len(Vars)):
            x = Vars[index]                                                    # 一个解
            for idx in range(len(self.uncomloc_indexs)):
                x = np.insert(x, self.uncomloc_indexs[idx], self.stay_x[idx])  # 将保留值插入向量中,是不可能为0的
            # temp = np.flatnonzero(x).tolist()
            # if len(temp) == 0:
            #     print(x)
            sim_orignal = cosine_similarity([x.tolist()], [self.original_vector])[0][0]
            sim_orignal = 1 - sim_orignal                                       # 与用户原始向量的相似度的倒数，越小越好
            if len(self.friends_vectors) != 0:
                sim_friends = []                                                   # 与好友的相似度
                for friend_index in range(len(self.friends_vectors)):
                    fri_sim = cosine_similarity([x.tolist()], [self.friends_vectors[friend_index]])[0][0]
                    sim_friends.append(self.friends_delta[friend_index] * fri_sim)  # 好友亲密度权重以及皮尔森相似度
                sim_friends = np.sum(np.array(sim_friends))
                sim_weight = np.sum(np.multiply(np.array(self.weight_delta), np.array([sim_orignal, sim_friends])))
            else:
                sim_weight = sim_orignal*self.weight_delta[0]
            # sim_dis = []
            # x_nozero = np.flatnonzero(x).tolist()
            # for loc_index in self.original_flatnonzero:
            #     for loc_index1 in x_nozero:
            #         sim_dis.append(self.euclidean_distance(self.lat_lon[loc_index], self.lat_lon[loc_index1]))
            # sim_dis = np.sum(np.array(sim_dis))
            f.append([sim_weight])
        for i in range(len(Vars[0])):
            stay_x_values -= Vars[:, [i]]
        pop.CV = np.hstack([np.abs(stay_x_values)])  # 利用可行性法则处理约束条件
        pop.ObjV = np.array(f)        # 把求得的目标函数值赋值给种群pop的ObjV
