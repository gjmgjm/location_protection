#!/usr/bin/env python
# encoding: utf-8
"""
@version: v1.0
@author: jimi
@license: Apache Licence
@contact: 977510628@qq.com
@software: PyCharm
@file: hmm.py
@time: 2019/12/27
"""
from hmmlearn import hmm
from copy import deepcopy
import numpy as np
import pandas as pd
import os
import re
from itertools import combinations
from joblib import Parallel, delayed
import multiprocessing as mp
import cmath
import time
from adaptive_grid_divide_by_dp import adaptive_grid_divide_by_dp
from cal_friends_similarity import cal_friends_similarity
import geatpy as ea                # import geatpy
from MyProblem1 import MyProblem1  # 导入自定义问题接口
from update_features import update_features


abspath = os.path.abspath('..')
time_piecies = [['00:00:00', '03:00:00'], ['03:00:00', '06:00:00'], ['06:00:00', '09:00:00'],
                ['09:00:00', '12:00:00'], ['12:00:00', '15:00:00'], ['15:00:00', '18:00:00'],
                ['18:00:00', '21:00:00'], ['21:00:00', '23:59:59']]


class hmm_test():

    def __init__(self, city, privacy, n):
        self.city = city
        self.privacy = privacy
        self.n = n

    def read_data(self, n, privacy):   # 读取一个用户所有的轨迹当做一条轨迹
        # grid_divide = adaptive_grid_divide_by_dp("SNAP_SF", 20, 20, [37.809524, -122.520352, 37.708991, -122.358712], 0.2, 0.2)  # 网格划分
        # grid_divide.divide_area_by_NN()   # 第一层网格划分
        # checkins, locids = grid_divide.second_divide(15)  # 第二层网格划分
        checkins = pd.read_csv(abspath + "\\data\\city_data_adaptive_grid_dp" + "\\" + "SNAP_SF" + "_" + str(n) + "_" + str(n) + "_" +str(privacy)+ ".csv", delimiter=",", index_col=None, header=None)
        checkins.columns = ['uid', 'time', 'latitude', 'longitude', 'locid', 'grid_id', 'grid_id_second', 'n', 'm', 'start_grid']
        checkins = checkins.ix[:, [0, 1, 6]]
        checkins.rename(columns={"grid_id_second": "locid"}, inplace=True)
        checkins.sort_values(by=['uid', "time"], ascending=True, inplace=True)  # 按照时间先后进行排序
        checkins.loc[:, "time"] = checkins['time'].apply(lambda x: re.search(r'\d+:\d+:\d+', x).group())  # 时间不看日期，只看时分秒
        checkins = self.__changetime_topeices(checkins)   # 将时间转换成时间段
        checkins.drop(['time'], axis=1, inplace=True)  # 删除多于的列
        checkins.rename(columns={"new_time": "time"}, inplace=True)
        return checkins

    def read_data_by_day(self):   # 以天划分轨迹
        # grid_divide = adaptive_grid_divide("SNAP_SF", 20, 20, [37.809524, -122.520352, 37.708991, -122.358712], 0.2, 0.2)  # 网格划分
        # grid_divide.divide_area_by_NN()   # 第一层网格划分
        # checkins, locids = grid_divide.second_divide(15)  # 第二层网格划分
        checkins = pd.read_csv(abspath + "\\data\\city_data_adaptive_grid_dp" + "\\" + "SNAP_SF" + "_" + str(self.n) + "_" + str(self.n) + "_" + str(self.privacy) + ".csv", delimiter=",", index_col=None, header=None)
        checkins.columns = ['uid', 'time', 'latitude', 'longitude', 'locid', 'grid_id', 'grid_id_second', 'n', 'm', 'start_grid']
        checkins = checkins.ix[:, [0, 1, 6]]
        checkins.rename(columns={"grid_id_second": "locid"}, inplace=True)
        checkins.sort_values(by=['uid', "time"], ascending=True, inplace=True)  # 按照时间先后进行排序
        checkins.loc[:, "time"] = checkins['time'].apply(lambda x: re.search(r'\d+:\d+:\d+', x).group())  # 时间不看日期，只看时分秒
        checkins = self.__changetime_topeices(checkins)   # 将时间转换成时间段
        checkins.drop(['time'], axis=1, inplace=True)  # 删除多余的列
        checkins.rename(columns={"new_time": "time"}, inplace=True)
        # locid需要所有的位置以及对应的经纬度
        locids_latlon = adaptive_grid_divide_by_dp.read_grid_latlon(abspath + "\\data\\city_data_adaptive_grid_dp\\" + str(self.privacy) + "locids.txt")
        self.locids = [row[0] for row in locids_latlon]
        self.lat_lon = [row[1] for row in locids_latlon]
        # print(self.lat_lon)
        # print(len(self.lat_lon), len(self.locids))
        self.freq_vector = [len(checkins[checkins.locid == locid])/len(checkins) for locid in self.locids]
        similarity = cal_friends_similarity.read_rate(abspath + "\\data\\city_data_adaptive_grid_dp\\" + self.city + "_pairs_loc_rate_new_lsc"+str(self.privacy)+".txt", self.city, self.privacy)
        return checkins, self.locids, similarity

    def __changetime_topeices(self, checkins):
        """
        :param checkins: 将原始数据的时间转换成时段，例如['00:00:00', '03:00:00']表示时段0、['03:00:00', '06:00:00']表示时段1.
        :return: 将时间转换后的数据返回
        """
        checkins.loc[:, "new_time"] = -1
        for i in range(len(time_piecies)):
            checkins.loc[(pd.to_datetime(checkins.time, format='%H:%M:%S') >= pd.to_datetime(time_piecies[i][0], format='%H:%M:%S'))& (pd.to_datetime(checkins.time, format='%H:%M:%S') < pd.to_datetime(time_piecies[i][1], format='%H:%M:%S')), "new_time"] = i
        checkins.loc[checkins.new_time == -1, "new_time"] = len(time_piecies)-1
        return checkins

    def __build_model(self, start_pro, trans_pro, emi_pro, n_states):
        """
         :param start_pro:  隐藏状态分布矩阵
         :param trans_pro:  隐藏状态转移矩阵
         :param emi_pro:    发射矩阵：各隐藏状态下个观测值出现的结果
         :param n_states:   隐藏状态的个数
         :return:           构建好的HMM模型
        """
        model = hmm.MultinomialHMM(n_components=n_states)
        model.startprob_ = start_pro
        model.transmat_ = trans_pro
        model.emissionprob_ = emi_pro
        return model

    def PersonCorrelation(self, x, y):
        """
        :param x: 两个向量x,y
        :param y:
        :return:  皮尔森相关系数
        """
        x_ = x - np.mean(x)
        y_ = y - np.mean(y)
        d1 = np.dot(x_, y_) / (np.linalg.norm(x_) * np.linalg.norm(y_))
        return d1

    def aimFunc(self, Phen, stay_x, uncomloc_indexs, original_vector, friends_vectors, friends_delta, weight_delta):  # 目标函数
        Vars = Phen  # 得到决策变量矩阵
        f = []
        for index in range(len(Vars)):
            x = Vars[index]  # 一个解
            for idx in range(len(uncomloc_indexs)):
                x = np.insert(x, uncomloc_indexs[idx], stay_x[idx])  # 将保留值插入向量中
            sim_orignal = 1 / self.PersonCorrelation(x, original_vector)  # 与用户原始向量的相似度的倒数，越小越好
            sim_friends = []  # 与好友的相似度
            for friend_index in range(len(friends_vectors)):
                sim_friends.append(friends_delta[friend_index] * self.PersonCorrelation(x, friends_vectors[friend_index]))  # 好友亲密度权重以及皮尔森相似度
            sim_friends = np.sum(np.array(sim_friends))
            sim_weight = np.sum(np.multiply(np.array(weight_delta), np.array([sim_orignal, sim_friends])))
            f.append(sim_weight)
        return f.index(min(f))

    def mutiobject_update(self, original_vector, friends_vectors, friends_delta, weight_delta):

        """================================实例化问题对象==========================="""
        problem = MyProblem1(original_vector, friends_vectors, friends_delta, weight_delta, self.lat_lon, self.city)  # 生成问题对象
        comloc_idx = problem.get_comidx()
        uncomloc_indexs = problem.get_uncomidx()
        stay_x = problem.get_stay_x()
        """==================================种群设置==============================="""
        Encoding = 'RI'  # 编码方式
        NIND = 50  # 种群规模
        Field = ea.crtfld(Encoding, problem.varTypes, problem.ranges, problem.borders)  # 创建区域描述器
        population = ea.Population(Encoding, Field, NIND)  # 实例化种群对象（此时种群还没被初始化，仅仅是完成种群对象的实例化）
        """================================算法参数设置============================="""
        myAlgorithm = ea.moea_NSGA3_templet(problem, population)  # 实例化一个算法模板对象
        myAlgorithm.MAXGEN = 200  # 最大进化代数
        """==========================调用算法模板进行种群进化========================"""
        NDSet = myAlgorithm.run()  # 执行算法模板，得到帕累托最优解集NDSet
        Phen = NDSet.Phen
        print(Phen)
        if len(Phen) != 0:   # 有解
            #  aimFunc(self, Phen, original_vector, friends_vectors, friends_delta, weight_delta, stay_x, uncomloc_indexs)
            min = self.aimFunc(Phen, original_vector, friends_vectors, friends_delta, [0.5, 0.5], stay_x, uncomloc_indexs)
            return Phen[min], comloc_idx, uncomloc_indexs, stay_x
        return Phen, comloc_idx, uncomloc_indexs, stay_x

    def train_ABPI(self, delta1, delta2, delta3, delta4):
        checkins, locids, similarity = self.read_data_by_day()
        similarity.loc[:, 'sim'] = 0
        similarity.loc[similarity.fri_rate >= 0, 'sim'] = similarity[similarity.sim >= 0].apply(lambda x: x['loc_rate'] * delta1 + x['fri_rate'] * delta2, axis=1)  # 具有社交关系的用户对
        sim_over = deepcopy(similarity[(similarity.sim >= delta3) & (similarity.fri_rate >= 0)])
        # 获得好友的相似度
        n_states = len(locids)
        user_checkins = checkins.groupby(["uid"])  # 按照用户id对数据进行分组,从小到大排序
        data = []
        for group in user_checkins:
            print("用户"+str(group[0])+"模型参数更新中...")
            u_locids = list(group[1].locid.values)
            u_locids_len = len(u_locids)
            start_pro = [u_locids.count(x) / u_locids_len for x in locids]  # 地点的初始概率
            # print("初始状态矩阵A参数获取完成")
            tras_pro = np.zeros((n_states, n_states))  # 转移矩阵
            for index in range(u_locids_len):
                if (index+1) != u_locids_len:
                    next = index + 1
                    cur_locid = u_locids[index]
                    next_locid = u_locids[next]
                    tras_pro[locids.index(cur_locid)][locids.index(next_locid)] += 1  # 更新转移矩阵
            # 将转移矩阵每一行的概率和转换成1
            col_len = tras_pro.shape[1]
            # print(col_len)  # 2729个位置
            for k, line in enumerate(tras_pro):
                sum1 = np.sum(line)
                if sum1 != 0:  # 一行的和不为0
                    for i in range(col_len):
                        if tras_pro[k][i] != 0:
                            tras_pro[k][i] = tras_pro[k][i] / sum1
            # print("初始转移矩阵B参数获取完成")
            # 得到发射矩阵
            emi_pro = np.zeros((n_states, 8))  # 发射矩阵
            u_locid_times = group[1].groupby(by=['locid', 'time']).size().reset_index(name="u_times")
            for row in u_locid_times.itertuples(index=False, name=False):
                emi_pro[locids.index(row[0])][int(row[1])] = row[2]
            col_len = emi_pro.shape[1]
            for k, line in enumerate(emi_pro):
                sum1 = np.sum(line)
                if np.sum(line) != 0:
                    for i in range(col_len):
                        if emi_pro[k][i] != 0:
                            emi_pro[k][i] = emi_pro[k][i] / sum1
            # print("初始发射矩阵π参数获取完成")
            times_ = list(group[1].time.values)  # 每个时刻都作为一个观测序列
            list_new = [[t] for t in times_]
            observations = np.array(list_new)
            data.append([group[0], start_pro, tras_pro, emi_pro, observations])
        data = pd.DataFrame(data, columns=["uid", "start_pro", "tras_pro", "emi_pro", "observations"])
        data.loc[:, "start_pro_after"] = data.loc[:, "start_pro"]
        data.loc[:, "tras_pro_after"] = data.loc[:, "tras_pro"]
        data.loc[:, "emi_pro_after"] = data.loc[:, "emi_pro"]
        for row in data.itertuples(index=False, name=False):
            friends = sim_over[(sim_over.u1 == row[0]) | (sim_over.u2 == row[0])]
            friends = list(set(friends.u1.unique()).union(set(friends.u2.unique())))
            friends.sort()
            if len(friends) != 0:      # 得到用户的好友
                friends.remove(row[0])
            friends_vectors = list(data[data.uid.isin(friends)].start_pro.values)
            original_vector = row[1]
            friends_delta = []
            for fri in friends:
                if fri > row[0]:
                    friends_delta.append(similarity[(similarity.u1 == row[0])&(similarity.u2 == fri)].sim.values[0])
                else:
                    friends_delta.append(similarity[(similarity.u1 == fri) & (similarity.u2 == row[0])].sim.values[0])
            updated_vector, comloc_idx, uncomloc_indexs, stay_x = list(self.mutiobject_update(original_vector, friends_vectors, friends_delta, [0.5, 0.5]))
            if len(updated_vector) != 0:
                for idx in range(len(uncomloc_indexs)):
                    updated_vector = np.insert(updated_vector, uncomloc_indexs[idx], stay_x[idx])  # 将保留值插入向量中
                # (self, original_vector, updated_vector, transmat_,emi_, lat_lon, freq_vector, comloc_idx, city):
                update_feature = update_features(original_vector, updated_vector, row[2], row[3], self.lat_lon, self.freq_vector, comloc_idx, self.city)
                updated_tras = update_feature.update_transmat(delta4)
                updated_emi =update_feature.update_emi()
                # 更新参数
                updated_tras = np.array(updated_tras)
                # 归一化
                col_len = updated_tras.shape[1]
                for k, line in enumerate(updated_tras):
                    sum1 = np.sum(line)
                    if sum1 != 0:  # 一行的和不为0
                        for i in range(col_len):
                            if updated_tras[k][i] != 0:
                                updated_tras[k][i] = updated_tras[k][i] / sum1
                    else:  # 一行的和为0,则给它一个均匀分布
                        for i in range(col_len):
                            updated_tras[k][i] = 1/col_len
                print("转移矩阵B参数更新完成")
                # 归一化
                col_len = updated_emi.shape[1]
                for k, line in enumerate(updated_emi):
                    sum1 = np.sum(line)
                    if np.sum(line) != 0:
                        for i in range(col_len):
                            if updated_emi[k][i] != 0:
                                updated_emi[k][i] = updated_emi[k][i] / sum1
                    else:
                        for i in range(col_len):
                            updated_emi[k][i] = 1 / col_len
                print("发射矩阵π参数更新完成")
                data.loc[data.uid == row[0], "start_pro_after"] = updated_vector
                data.loc[data.uid == row[0], "tras_pro_after"] = updated_tras
                data.loc[data.uid == row[0], "emi_pro_after"] = updated_emi
        disturb_checkins = pd.DataFrame()
        for group in user_checkins:
            update_feature = data[data.uid == group[0]].values[0]
            print(update_feature)
            results = self.predict(update_feature[5], update_feature[6], update_feature[7], update_feature[4])
            u_checkins = deepcopy(group[1])  # 复制原始的数据
            print(u_checkins)
            disturb_locids = [locids[index] for index in results]
            u_checkins.loc[:, 'locid_after'] = disturb_locids
            disturb_checkins = pd.concat([disturb_checkins, u_checkins], ignore_index=True)
            disturb_checkins.to_csv(abspath + "\\data\\result_data_dp_divide_lsc_12_27\\test.txt", index=False, header=False, mode='a')

    def predict(self, A, B, PI, observations):
        hidden_states = self.__build_model(A, B, PI, len(A)).predict(observations)
        return hidden_states


if __name__ == "__main__":

    hmm_test = hmm_test("SNAP_SF", 0.1, 11)
    # train_ABPI(self, delta1, delta2, delta3, delta4):# 地理，社交、亲密度阈值、
    hmm_test.train_ABPI(0.6, 0.4, 0.12, 0.5)
