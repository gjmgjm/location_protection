#!/usr/bin/env python  
# encoding: utf-8  

""" 
@version: v1.0 
@author: jaculamata 
@license: Apache Licence  
@contact: 819436557@qq.com 
@site: http://blog.csdn.net/hqzxsc2006 
@software: PyCharm 
@file: 5_security.py 
@time: 2019/1/20 15:44 
"""
import pandas as pd
from numpy.linalg import norm
from scipy.stats import entropy
import numpy as np
import math
import os
from cal_close_relation import cal_close_relation
import matplotlib.pylab as plt
import time
abspath = os.path.abspath('..')


def JSD(P, Q):
    _P = P / norm(P, ord=1)
    _Q = Q / norm(Q, ord=1)
    _M = 0.5 * (_P + _Q)
    return 0.5 * (entropy(_P, _M, base=2) + entropy(_Q, _M, base=2))


class security_unility():
    #
    # def __init__(self, city, delta1, delta2, delta3, delta4, pri_detla, rate):
    def __init__(self, city, delta1, delta2, delta3, delta4, rate, times, m):
        # self.checkins = pd.read_csv(abspath + "\\data\\result_data_dp_divide_lsc_12_15\\" + city + str(delta1)+str(delta2)+str(delta3)+str(delta4)+str(pri_detla)+str(rate)+"19090100.csv", delimiter="\t", index_col=None)

        # self.checkins = pd.read_csv(abspath + "\\data\\result_data_dp_divide_lsc_\\" + city + str(delta1) + str(delta2) + str(delta3) + str(delta4) + str(pri_detla) + str(rate) + "1909010.csv", delimiter="\t", index_col=None)

        self.checkins = pd.read_csv(abspath + "\\data\\result_data_random_divide_lsc_01_09\\" + city + str(delta1) + str(delta2) + str(delta3) + str(delta4) +str(rate)+ str(times)+str(m)+str(m)+"100.csv", delimiter="\t", index_col=None)
        # self.checkins_obf = pd.read_csv(abspath + "\\data\\city_data\\" + city + "_1.csv", delimiter="\t", index_col=None)
        # 有网格
        # self.checkins_obf = pd.read_csv(abspath + "\\data\\city_data\\" + city + "_90_90.csv", delimiter=",", index_col=None,header=None)
        # self.checkins_obf.columns = ['uid', 'time', 'latitude', 'longitude', 'locid', 'gridlat', 'gridlon', 'grid_id']
        # self.checkins_obf = self.checkins_obf.ix[:, [0, 1, 5, 6, 7]]
        # self.checkins_obf.rename(columns={"grid_id": "locid", "gridlat": "latitude", "gridlon": "longitude"}, inplace=True)  # 在原表上修改
        self.m = m
        self.checkins_obf = pd.read_csv(abspath + "\\data\\city_data_adaptive_grid" + "\\" + city + "_"+str(m)+"_"+str(m) +".csv", delimiter=",",index_col=None, header=None)
        self.checkins_obf.columns = ['uid', 'time', 'latitude', 'longitude', 'locid', 'gridlat', 'gridlon', 'grid_id','gridlat_second', 'gridlon_second', 'grid_id_second', 'n', 'm', 'start_grid']
        self.checkins_obf = self.checkins_obf.ix[:, [0, 1, 8, 9, 10]]
        self.checkins_obf.rename(columns={"grid_id_second": "locid", "gridlat_second": "latitude", "gridlon_second": "longitude"}, inplace=True)
        self.checkins.columns = ["uid", "time", "lat_after", "lng_after", "locid_after", "locid", "latitude", "longitude"]
        # self.checkins_obf = self.checkins_obf[self.checkins_obf.uid.isin(list(self.checkins.uid.unique()))]
        if city == "GW_NY":
            self.lons_per_km = 0.0059352 * 2  # NY
            self.lats_per_km = 0.0044966 * 2  # delta latitudes per kilo meter
        elif city == "GW_SF" or city == "SNAP_SF":
            self.lons_per_km = 0.005681 * 2  # SF
            self.lats_per_km = 0.004492 * 2  # delta latitudes per kilo meter
        elif city == "GW_AS":
            self.lons_per_km = 0.005681 * 2  # AS
            self.lats_per_km = 0.004492 * 2  # delta latitudes per kilo meter
        self.delta1 = delta1
        self.delta2 = delta2
        self.delta3 = delta3
        self.delta4 = delta4
        # self.pri_delta = pri_detla
        self.city = city

    # 两点之间的欧氏距离计算
    def euclidean_distance(self, loc1, loc2):
        return math.sqrt(((loc1[1] - loc2[1]) / self.lons_per_km) ** 2 + ((loc1[0] - loc2[0]) / self.lats_per_km) ** 2)

    def d_security(self):
        print()
        print("全局位置访问频率分布改变情况")   # 全局位置访问频率分布改变情况，保护前后访问频率分布分别为Ta,Tb
        # start = time.time()
        checkin = self.checkins
        checkin_obf = self.checkins_obf
        checkin_len = len(checkin)
        checkin_obf_len = len(checkin_obf)
        union_grid_id = list(set(checkin.locid_after.unique()).union(set(checkin_obf.locid.unique())))
        checkin_vec = list(map((lambda x: len(checkin[checkin.locid_after == x]) * 1.0 / checkin_len), union_grid_id))
        checkin_obf_vec = list(map((lambda x: len(checkin_obf[checkin_obf.locid == x]) * 1.0 / checkin_obf_len), union_grid_id))
        checkin_vec = np.array(list(checkin_vec))
        checkin_obf_vec = np.array(list(checkin_obf_vec))
        globle_security = JSD(checkin_vec, checkin_obf_vec)
        print("d:", globle_security)
        return globle_security

    def e_security(self):
        print()
        print("用户位置访问频率分布改变情况")
        checkin = self.checkins
        checkin_obf = self.checkins_obf
        single_security = 0
        for u in checkin_obf.uid.unique():
            u_checkin = checkin.loc[checkin.uid == u]
            u_checkin_obf = checkin_obf.loc[checkin_obf.uid == u]
            u_checkin_len = len(u_checkin)
            u_checkin_obf_len = len(u_checkin_obf)
            union_grid_id = list(set(u_checkin.locid_after.unique()).union(set(u_checkin_obf.locid.unique())))
            checkin_vec = list(map((lambda x: len(u_checkin[u_checkin.locid_after == x]) * 1.0 / u_checkin_len), union_grid_id))
            checkin_obf_vec = list(map((lambda x: len(u_checkin_obf[u_checkin_obf.locid == x]) * 1.0 / u_checkin_obf_len), union_grid_id))
            single_security += JSD(np.array(checkin_vec), np.array(checkin_obf_vec))
        print("e:", single_security/len(checkin_obf.uid.unique()))
        return single_security/len(checkin_obf.uid.unique())

    def f_security(self):
        print()
        print("位置改变个数统计")
        nums = 0
        for row in self.checkins.itertuples(index=False, name=False):
            if row[5] != row[4]:
                nums += 1
        print("f:", nums)
        return nums

    def g_security(self):
        print()
        print("位置距离改变")
        distance = 0
        count = 0
        for row in self.checkins.itertuples(index=False, name=False):
            if row[4] != row[5]:
                distance += self.euclidean_distance([row[6], row[7]], [row[2], row[3]])
                count = count+1
        print("g:", distance/count)
        return distance/count

    def cellBasedKendallCoefficientOfVisitProb(self):
        # 位置访问频率的肯德尔系数K
        # 保序的定义为：对于两个位置a和b，若隐私保护前后a、b的访问频率相对大小不发生变化，则称位置a和b的访问频率是保序的。
        # 该指标数值越大说明地理位置可用性保持得越好
        orderedPairs = 0
        unorderedPairs = 0
        locids = self.checkins.locid_after.unique()
        locids_obf = self.checkins.locid.unique()
        union_grid_id = set(locids).union(set(locids_obf))
        checkin_vec = list(map((lambda x: len(self.checkins[self.checkins.locid_after == x])), union_grid_id))
        checkin_obf_vec = list(map((lambda x: len(self.checkins[self.checkins.locid == x])), union_grid_id))  # 真实位置访问频率分布
        for i in range(len(checkin_vec)-1):
            for j in range(i+1, len(checkin_vec)):
                real_ = checkin_obf_vec[i] - checkin_obf_vec[j]
                false_ = checkin_vec[i] - checkin_vec[j]
                if real_*false_ > 0:
                    orderedPairs = orderedPairs+1
                elif real_*false_ < 0:
                    unorderedPairs = unorderedPairs+1
                else:
                    if real_ == 0 and false_ == 0:
                        orderedPairs =orderedPairs+1
                    else:
                        unorderedPairs = unorderedPairs + 1
        kendall = (orderedPairs - unorderedPairs) / (len(union_grid_id) * (len(union_grid_id) - 1) * 0.5)
        return kendall

    def cal_security(self):
        d = self.d_security()
        f = self.f_security()
        g = self.g_security()
        kendall = self.cellBasedKendallCoefficientOfVisitProb()
        file = open(abspath + "\\data\\result_data\\" + self.city + "_random_result.txt",  'a', encoding='UTF-8')
        file.write('扰动比例参数:' + str(self.delta1) + ' ' + str(self.delta2) + ' ' + str(self.delta3)
                   + ' ' + str(self.delta4) + ' ' + str(self.m)+'\n')
        # file.write('扰动比例参数:' + str(self.delta1) + ' ' + str(self.delta2) + ' ' + str(self.delta3)
        #            + ' ' + str(self.delta4) + ' ' + str(self.pri_delta) + '\n')
        file.write('d:' + str(d) + ' ' + 'f:' + str(f) + ' ' + 'g:' + str(g) + ' kendall:' + str(kendall)+'\n')
        # file.write('f:' + str(f) + ' ' + 'g:' + str(g) + '\n')
        file.close()

    def draw_results(self, delta1, delta2, delta3):
        friends = pd.read_csv(abspath + "\\data\\city_data\\GW_NY_edges_fri_rate.csv", delimiter="\t",
                                  index_col=None)
        friends.columns = ['u1', 'u2', 'fri_rate']
        rates = list(friends.fri_rate.values)
        comlocs = pd.read_csv(abspath + "\\data\\city_data\\GW_NY_edges_loc_rate.csv", delimiter="\t",
                                  index_col=None)
        comlocs.columns = ['u1', 'u2', 'loc_rate', 'comlocs']
        comlocs.loc[:, "fri_rate"] = friends['fri_rate']
        comlocs.loc[:, 'similarity'] = 0
        comlocs.loc[comlocs.fri_rate > 0, 'similarity'] = comlocs[comlocs.fri_rate > 0].apply(lambda x: x['loc_rate'] * delta1 + x['fri_rate'] * delta2, axis=1)  # 具有社交关系的用户对
        sim_over = comlocs[(comlocs.similarity >= delta3)]# 需要进行扰动的用户对
        print(len(sim_over))
        # comlocs = comlocs[comlocs.loc_rate < 1]
        # loc_rates = list(comlocs.loc_rate.values)
        # plt.hist(rates, 20)
        # plt.show()
        # plt.hist(loc_rates, 20)
        # plt.show()

    def draw_results1(self, delta1, delta2, delta3):
        friends = pd.read_csv(abspath + "\\data\\city_data\\GW_NY_pairs_fri_rate_new1.csv", delimiter="\t", index_col=None)
        friends.columns = ['u1', 'u2', 'fri_rate']
        comlocs = pd.read_csv(abspath + "\\data\\city_data\\GW_NY_pairs_loc_rate.txt", delimiter="\t", index_col=None)
        comlocs.columns = ['u1', 'u2', 'loc_rate', 'comlocs', "comloc"]
        comlocs.loc[:, "fri_rate"] = friends['fri_rate']
        comlocs.loc[:, 'similarity'] = 0
        comlocs.loc[comlocs.fri_rate >= 0, 'similarity'] = comlocs[comlocs.fri_rate >= 0].apply(lambda x: x['loc_rate'] * delta1 + x['fri_rate'] * delta2, axis=1)  # 具有社交关系的用户对
        # sim_over = comlocs[(comlocs.similarity >= delta3) & ()]# 需要进行扰动的用户对
        # print(len(sim_over))
        comlocs = comlocs[(comlocs.similarity > 0)]
        loc_rates = list(comlocs.similarity.values)
        plt.xlim(0, 0.7)
        plt.xlabel("loc_rate="+str(delta1)+"  fri_rate="+str(delta2))
        # friends = friends[friends.fri_rate >= 0]
        # rates = list(friends.fri_rate.values)
        # plt.hist(rates, 20)
        # plt.show()
        plt.hist(loc_rates, 15)
        plt.show()

    def cal_unility(self):
        sim = pd.read_csv(abspath + "\\data\\city_data\\" + self.city + str(self.delta1) + str(self.delta2) + str(self.delta3) + str(self.delta4) + "_pairs_rate_after5.txt", delimiter=",", index_col=None)
        sim.columns = ["u1", "u2", "loc_rate", "comlocs1", "comlocs2", "fri_rate", "similarity"]
        sim = sim[sim.similarity >= 0.2]
        file = open(abspath + "\\data\\result_data\\" + self.city + "result.txt", 'a', encoding='UTF-8')
        file.write('扰动比例参数:' + str(self.delta1) + ' ' + str(self.delta2) + ' ' + str(self.delta3)
                   + ' ' + str(self.delta4) + '\n')
        file.write('e:' + str(len(sim)) + '\n')
        file.close()


if __name__ == "__main__":
    # print(1.5**(-2))
    # for i in [0.1, 1, 3, 10]:
    #    print(i)
    #    cal = security_unility("GW_NY", 0.6, 0.4, 0.05, 0.5, i, 1)
       # cal = security_unility("SNAP_SF", 0.6, 0.4, 0.1, 0.5, i, 1)
    for i in [1, 2]:
        for j in [7, 16, 24, 29, 39]:
           print(i)
           cal = security_unility("SNAP_SF", 0.6, 0.4, 0.05, 0.4, 1, i, j)
           # cal = security_unility("SNAP_SF", 0.6, 0.4, 0.1, 0.5, 1, i)
           cal.cal_security()
       # cal.d_security()
       # cal.f_security()
       # cal.g_security()
    # for i in [0.1, 1, 3, 5, 10]:
    #    cal = security_unility("GW_NY", 0.6, 0.4, 0.1, 0.5, i)
    #    cal.cal_security()
    # for i in [0.3, 0.8]:
    #     # 4
    #     start = time.time()
    #     cal = cal_close_relation("GW_NY", 0.2)
    #     cal.cal_similarity1(0.6, 0.4, 0.1, 0.5, 5, 0.8)
    #     print("时间：", (time.time() - start) / 60)
