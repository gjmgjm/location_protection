# -*- encoding: utf-8 -*-
import pyproj
import pandas as pd
import time
import decimal, math, multiprocessing
from joblib import Parallel,delayed
import os
import gc
abspath = os.path.abspath('..')

class transfer():

    # def __init__(self, N, M, ranges):
    #     self.ranges = ranges    # 城市经纬度范围
    #     self.n = N              # 划分网格数
    #     self.m = M              #
    #     self.latInterval = decimal.Decimal.from_float(math.fabs(self.ranges[0] - self.ranges[2]) / self.n)
    #     self.lngIntetval = decimal.Decimal.from_float(math.fabs(self.ranges[3] - self.ranges[1]) / self.m)
    #     self.maxlat = decimal.Decimal(self.ranges[0])
    #     self.minlng = decimal.Decimal(self.ranges[1])
    #     print("初始化完成")

    def __init__(self, city, N, M, ranges, delta_lat, delta_lon):
        self.checkins = pd.read_csv(abspath + "\\data\\city_data\\" + city + "_1.csv", delimiter="\t", index_col=None)
        self.ranges = ranges  # 城市经纬度范围
        self.lat_len = len(self.checkins.latitude.unique())
        self.lon_len = len(self.checkins.longitude.unique())
        self.density_lat = delta_lat * self.lat_len / N
        self.density_lon = delta_lon * self.lon_len / M
        self.n = N
        self.m = M
        self.city = city
        self.latInterval = decimal.Decimal.from_float(math.fabs(self.ranges[0] - self.ranges[2]) / self.n)  # 纬度为n，经度为m
        self.lngIntetval = decimal.Decimal.from_float(math.fabs(self.ranges[3] - self.ranges[1]) / self.m)
        self.maxlat = decimal.Decimal(self.ranges[0])
        self.minlng = decimal.Decimal(self.ranges[1])
        self.first_gridnums = N * M - 1

    def cal_gridid(self, checkin):
        latitude = decimal.Decimal(checkin[2])
        longitude = decimal.Decimal(checkin[3])
        i = math.floor((self.maxlat - latitude) / self.latInterval)
        j = math.floor((longitude - self.minlng) / self.lngIntetval)
        gridlat = float(self.maxlat - i * self.latInterval - self.latInterval / 2)
        gridlon = float(self.minlng + j * self.lngIntetval + self.lngIntetval / 2)
        checkin.append(gridlat)
        checkin.append(gridlon)
        checkin.append(int(i * self.m + j))
        return checkin

        # 按照N*N网格进行划分

    def divide_area_by_NN(self):  # 顶层网格划分
        checkin_new = []
        index = 0
        for row in self.checkins.itertuples(index=False, name=False):
            checkin = self.cal_gridid(list(row))
            checkin_new.append(checkin)
            print(index)
            index = index + 1
        checkins = pd.DataFrame(checkin_new,
                                columns=['uid', 'time', 'latitude', 'longitude', 'locid', 'gridlat', 'gridlon',
                                         'grid_id'])
        checkins.to_csv(abspath + "\\data\\city_data_adaptive_grid" + "\\" + self.city + "_" + str(self.n) + "_" + str(
            self.m) + "15.csv", index=False, header=False)
        print("该城市网格划分完成")

    def cal_second_gridid(self, checkin, ranges, n, m, start_grid):
        latInterval = decimal.Decimal.from_float(math.fabs(ranges[0] - ranges[2]) / n)  # 纬度为n，经度为m
        lngIntetval = decimal.Decimal.from_float(math.fabs(ranges[3] - ranges[1]) / m)
        maxlat = decimal.Decimal(ranges[0])
        minlng = decimal.Decimal(ranges[1])
        latitude = decimal.Decimal(checkin[2])
        longitude = decimal.Decimal(checkin[3])
        i = math.floor((maxlat - latitude) / latInterval)
        j = math.floor((longitude - minlng) / lngIntetval)
        gridlat = float(maxlat - i * latInterval - latInterval / 2)
        gridlon = float(minlng + j * lngIntetval + lngIntetval / 2)  # 计算的经纬度不一样，但是在同一个网格里面
        checkin.append(gridlat)
        checkin.append(gridlon)
        checkin.append(int(i * m + j + start_grid))
        return checkin

    def second_divide(self, deltac):
        checkins = pd.read_csv(abspath + "\\data\\city_data_adaptive_grid" + "\\" + self.city + "_" + str(self.n) + "_" + str(self.m) + "15.csv", delimiter=",", index_col=None, header=None)
        checkins.columns = ['uid', 'time', 'latitude', 'longitude', 'locid', 'gridlat', 'gridlon', 'grid_id']
        print(len(checkins.grid_id.unique()))
        checkin_new = []
        checkins_lat_len = checkins.groupby(by=['grid_id', 'latitude']).size().reset_index(name="grid_lat_times")
        checkins_lon_len = checkins.groupby(by=['grid_id', 'longitude']).size().reset_index(name="grid_lon_times")
        checkins_lat_lon_len = checkins_lat_len.groupby(by=['grid_id']).size().reset_index(name="grid_lat_times")
        checkins_lon_len1 = checkins_lon_len.groupby(by=['grid_id']).size().reset_index(name="grid_lon_times")
        checkins_lat_lon_len.loc[:, 'grid_lon_times'] = checkins_lon_len1['grid_lon_times']
        checkins_lat_lon_len.loc[:, 'is_dense'] = 0
        checkins_lat_lon_len.loc[(checkins_lat_lon_len.grid_lat_times >= self.density_lat) & (
                    checkins_lat_lon_len.grid_lon_times >= self.density_lon), 'is_dense'] = 1
        del checkins_lat_len, checkins_lon_len, checkins_lon_len1
        gc.collect()
        grid_checkins_len = checkins.groupby(by=['grid_id']).size().reset_index(name="grid_times")
        # print(len(checkins_lat_lon_len[checkins_lat_lon_len.is_dense == 1]))
        # print(grid_checkins_len.grid_times.sum())
        index = 0
        second_divide_grid = checkins_lat_lon_len[checkins_lat_lon_len.is_dense == 1].grid_id.unique()
        second_divide_grid.sort()
        second_grid_range = []
        first_gridnums = self.first_gridnums
        for gridid in second_divide_grid:
            j = gridid % self.m
            # j1 = checkins[checkins.grid_id==gridid].j.values[0]
            i = int((gridid - j) / self.m)
            # i1 = checkins[checkins.grid_id == gridid].i.values[0]
            range = [float(self.maxlat - i * self.latInterval), float(self.minlng + j * self.lngIntetval),
                     float(self.maxlat - (i + 1) * self.latInterval), float(self.minlng + (j + 1) * self.lngIntetval)]
            n = int(math.ceil(
                math.sqrt(grid_checkins_len[grid_checkins_len.grid_id == gridid].grid_times.values[0] / deltac)))
            m = int(math.ceil(
                math.sqrt(grid_checkins_len[grid_checkins_len.grid_id == gridid].grid_times.values[0] / deltac)))
            second_grid_range.append([gridid, m, n, range, first_gridnums + 1])
            first_gridnums = first_gridnums + n * m  # 单次网格划分的中点
        second_grid_range = pd.DataFrame(second_grid_range, columns=['grid_id', 'm', 'n', 'range', 'start_grid'])
        for row in checkins.itertuples(index=False, name=False):
            print(index)
            if checkins_lat_lon_len[checkins_lat_lon_len.grid_id == row[7]].is_dense.values[0] == 1:
                grid_range = second_grid_range[second_grid_range.grid_id == row[7]]
                range = grid_range.range.values[0]
                n = grid_range.n.values[0]
                m = grid_range.m.values[0]
                start_grid = grid_range.start_grid.values[0]
                checkin = self.cal_second_gridid(list(row), range, n, m, start_grid)
                checkin.append(n)
                checkin.append(m)
                checkin.append(start_grid)
            else:
                checkin = list(row)
                checkin.append(row[5])
                checkin.append(row[6])
                checkin.append(row[7])
                checkin.append(1)
                checkin.append(1)
                checkin.append(0)
            checkin_new.append(checkin)
            index = index + 1
        checkins = pd.DataFrame(checkin_new,
                                columns=['uid', 'time', 'latitude', 'longitude', 'locid', 'gridlat', 'gridlon',
                                         'grid_id', 'gridlat_second', 'gridlon_second', 'grid_id_second', 'n', 'm',
                                         'start_grid'])
        checkins.to_csv(abspath + "\\data\\city_data_adaptive_grid" + "\\" + self.city + "_" + str(self.n) + "_" + str(
            self.m) + "15.csv", index=False, header=False)
        print("该城市网格划分完成")

    # def proj_trans(self):
    #     checkins = pd.read_csv(abspath + "\\data\\city_data\\" + str(self.city) + "_1.csv", delimiter="\t", index_col=None, header=None)
    #     checkins.loc[:, 'timestamp'] = checkins['time'].apply(lambda x: time.mktime(time.strptime(x, '%Y-%m-%d %H:%M:%S')))  # 将签到记录中的日期时间转换成时间戳
    #     checkins = checkins.sort_values(by=['timestamp'], ascending=False).reset_index(drop=True)
    #     lon = checkins.longitude.values
    #     lat = checkins.latitude.values
    #     p1 = pyproj.Proj(init="epsg:4326")  # 定义数据地理坐标系
    #     p2 = pyproj.Proj(init="epsg:3857")  # 定义转换投影坐标系
    #     x1, y1 = p1(lon, lat)
    #     x2, y2 = pyproj.transform(p1, p2, x1, y1, radians=True)
    #     checkins['lon'] = x2
    #     checkins['lat'] = y2
    #     i = 0
    #     file = open(abspath + "\\data\\city_data_adaptive_grid" + "\\" + city + "_" + str(self.n) + "_" + str(self.m) + "15.dat", 'a', encoding='UTF-8')
    #     for user in checkins.uid.unique():
    #         file.write('#' + str(i) + ':' + '\n')
    #         file.write('>0:')
    #         u_lat_lon = checkins[checkins.uid == user].loc[:, ['lon', 'lat']]
    #         for row in u_lat_lon.itertuples(index=False, name=False):
    #             file.write(str(row[0]) + ',' + str(row[1]) + ';')
    #         file.write('\n')
    #         i += 1
    #     file.close()

    # def read_checkins(self, path, city):
    #     # print(city)
    #     checkins = pd.read_csv(path + "city_data/" + city + ".csv", delimiter="\t", index_col=None)
    #     self.checkins_obf = checkins.ix[:, [3, 2]].reset_index(drop=True)
    #     # print(self.checkins_obf)
    #     self.checkins_obf = self.divide_area_by_NN(self.checkins_obf)
    #     print("原始数据读取完成")

    def proj_trans(self):
        checkins = pd.read_csv(abspath + "\\data\\city_data\\" + str(self.city) + "_1.csv", delimiter="\t", index_col=None)
        checkins.loc[:, 'timestamp'] = checkins['time'].apply(lambda x: time.mktime(time.strptime(x, '%Y-%m-%d %H:%M:%S')))  # 将签到记录中的日期时间转换成时间戳
        checkins = checkins.sort_values(by=['timestamp'], ascending=False).reset_index(drop=True)
        lon = checkins.longitude.values
        lat = checkins.latitude.values
        p1 = pyproj.Proj(init="epsg:4326")  # 定义数据地理坐标系
        p2 = pyproj.Proj(init="epsg:3857")  # 定义转换投影坐标系
        x1, y1 = p1(lon, lat)
        x2, y2 = pyproj.transform(p1, p2, x1, y1, radians=True)
        checkins['lon'] = x2
        checkins['lat'] = y2
        i = 0
        file = open(abspath + "\\data\\city_data_adaptive_grid" + "\\" + self.city + ".dat", 'a', encoding='UTF-8')
        for user in checkins.uid.unique():
            file.write('#'+str(i)+':'+'\n')
            file.write('>0:')
            u_lat_lon = checkins[checkins.uid == user].loc[:, ['lon', 'lat']]
            for row in u_lat_lon.itertuples(index=False, name=False):
                file.write(str(row[0])+','+str(row[1])+';')
            file.write('\n')
            i += 1
        file.close()

    # def proj_trans_reverse(self, city, esp, times):
    #     from ccs_unility import ccs_unility
    #     file = open("C:/AdaTrace-master/result/" + city + ".dat-eps" + str(esp) + "-iteration" + str(times) + ".dat", "r", encoding='UTF-8')
    #     a = file.readline()
    #     i = 0
    #     list = []
    #     while a:
    #         if i % 2 != 0:
    #             a = a.replace(">0:", "")
    #             temp = a.strip().split(";")
    #             temp = temp[0:len(temp)-1]
    #             for line in temp:
    #                 lon_lat = line.split(",")
    #                 lon_lat = map(float, lon_lat)
    #                 list.append(lon_lat)
    #         i += 1
    #         a = file.readline()
    #     data = pd.DataFrame(list, columns=['longitude', 'latitude'])
    #     lon = data.longitude.values
    #     lat = data.latitude.values
    #     p1 = pyproj.Proj(init="epsg:3857")  # 定义转换投影坐标系
    #     p2 = pyproj.Proj(init="epsg:4326")  # 定义数据地理坐标系
    #     x1, y1 = lon, lat
    #     x2, y2 = pyproj.transform(p1, p2, x1, y1, radians=True)
    #     data['longitude'], data['latitude'] = p2(x2, y2, inverse=True)
    #     data.to_csv("G:/pyfile/relation_protect/src/data/" + "result_data/ccs/"+city+".dat-eps"+str(esp)+"-iteration"+ str(times)+".csv", index=False, header=None)
    #     result = self.divide_area_by_NN(data)
    #     unility = ccs_unility()
    #     unility.set_checkins(self.checkins_obf, result)
    #     unility_result = unility.d_security()
    #     file = open("G:/pyfile/relation_protect/src/data/" + "result_data/ccs.txt", 'a', encoding='UTF-8')
    #     file.write(city + ' ' + str(esp) + ' ' + str(unility_result) + '\n')
    #     file.close()


if __name__ == "__main__":
    # proj_trans_reverse("", "", -97.7493953705, 30.2691029532)
    # proj_trans_reverse("", "", -10881412.917994434, 3538187.630644491)  #-1.7060487910489277 0.5282955081584793
    # for city in ["1", "SF", "FS_NY_1"]:
    #     for esp in [0.1, 1.0, 3.0, 5.0, 10.0]:
    #         for i in [0, 1, 2, 3, 4]:
    #             if city == "1":
    #                 trans = transfer(30, 40, [30.387953, -97.843911, 30.249935, -97.635460])
    #             elif city == "SF":
    #                 trans = transfer(30, 40, [37.809524, -122.520352, 37.708991, -122.358712])
    #             else:
    #                 trans = transfer(40, 40, [40.836357, -74.052914, 40.656702, -73.875168])
    #             trans.read_checkins("G:/pyfile/relation_protect/src/data/", city)
    #             trans.proj_trans_reverse(city, esp, i)
    for city in ["GW_NY", "SNAP_SF"]:
        # for esp in [0.1, 1.0, 3.0, 5.0, 10.0]:
            # for i in [0, 1, 2, 3, 4]:
                if city == "GW_NY":
                    trans = transfer(city, 90, 90, [40.836357, -74.052914, 40.656702, -73.875168], 0.2, 0.2)
                elif city == "SNAP_SF":
                    trans = transfer(city, 65, 85, [37.809524, -122.520352, 37.708991, -122.358712], 0.2, 0.2)
                else:
                    trans = transfer(city, 40, 40, [40.836357, -74.052914, 40.656702, -73.875168], 0.2, 0.2)
                trans.proj_trans()
                # trans.read_checkins("G:/pyfile/relation_protect/src/data/", city)
                # trans.proj_trans_reverse(city, esp, i)