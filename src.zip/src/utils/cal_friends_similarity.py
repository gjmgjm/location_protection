#!/usr/bin/env python
# encoding: utf-8

from itertools import combinations
from joblib import Parallel, delayed
import multiprocessing as mp
import cmath
import os
import pandas as pd
abspath = os.path.abspath('..')


class cal_friends_similarity():

    def __init__(self, checkins, city, privacy):
        self.edges = pd.read_csv(abspath + "\\data\\city_data\\" + city + "_edgs.csv", delimiter="\t", index_col=None)
        self.edges.columns = ["u1", "u2"]
        self.city = city
        self.checkins = checkins
        self.users = list(checkins.uid.unique())
        self.privacy = privacy
        if city == "GW_NY":
            self.lons_per_km = 0.0059352 * 2  # NY
            self.lats_per_km = 0.0044966 * 2  # delta latitudes per kilo meter
        elif city == "GW_SF" or city == "SNAP_SF":
            self.lons_per_km = 0.005681 * 2  # SF
            self.lats_per_km = 0.004492 * 2  # delta latitudes per kilo meter
        elif city == "GW_AS":
            self.lons_per_km = 0.005681 * 2  # AS
            self.lats_per_km = 0.004492 * 2  # delta latitudes per kilo meter

    def run(self, u, edges):
        u_friends = set(edges.u1.unique()).union(set(edges.u2.unique()))
        if len(u_friends) != 0:
            u_friends.remove(u)
        return [u, list(u_friends)]  # 用户u的好友

    def cal_relation(self, pairs):
        core_num = mp.cpu_count()
        u_friends = Parallel(n_jobs=core_num)(delayed(self.run)(u, self.edges[(self.edges.u1 == u) | (self.edges.u2 == u)]) for u in self.users)
        u_friends = pd.DataFrame(u_friends, columns=['uid', 'friends'])
        print("好友计算完毕")
        fri_relation = []
        for row in pairs:  # 这里错了
            row1_friends = set(u_friends[u_friends.uid == row[0]].friends.values[0])
            if row[1] in row1_friends:  # 这才是真实存在的用户对
                row2_friends = set(u_friends[u_friends.uid == row[1]].friends.values[0])
                com_friends = row1_friends.intersection(row2_friends)
                union_friends = row1_friends.union(row2_friends)
                if len(union_friends) == 0:
                    fri_relation.append([row[0], row[1], 0])
                else:
                    fri_relation.append([row[0], row[1], len(com_friends) / len(union_friends)])
            else:
                fri_relation.append([row[0], row[1], -1])
        fri_relation = pd.DataFrame(fri_relation, columns=['u1', 'u2', 'fri_rate'])
        fri_relation.to_csv(abspath + "\\data\\city_data_adaptive_grid_dp_2\\" + self.city + "_pairs_fri_rate_new"+str(self.privacy)+".csv", sep='\t', index=False, header=False)

    # 两点之间的欧氏距离计算
    def euclidean_distance(self, loc1, loc2):
        return cmath.sqrt(((loc1[1] - loc2[1]) / float(self.lons_per_km)) ** 2 + ((loc1[0] - loc2[0]) / float(self.lats_per_km)) ** 2)

    def run1(self, u1, u2, u1_locs, u2_locs):
        comlocs = list(u1_locs.intersection(u2_locs))
        return [u1, u2, len(comlocs) / len(set(u1_locs.union(u2_locs))), comlocs]  # 用户u的好友

    def space_efficient_lcs(self, list_a, list_b):
        """
        longest common subsequence of str_a and str_b, with O(n) space complexity
        """
        if len(list_a) == 0 or len(list_b) == 0:
            return 0
        dp = [0 for _ in range(len(list_b) + 1)]
        for i in range(1, len(list_a) + 1):
            left_up = 0
            dp[0] = 0
            for j in range(1, len(list_b) + 1):
                left = dp[j - 1]
                up = dp[j]
                if list_a[i - 1] == list_b[j - 1]:
                    dp[j] = left_up + 1
                else:
                    dp[j] = max([left, up])
                left_up = up
        return dp[len(list_b)]

    # 计算好友之间共同访问位置个数
    def cal_comlocs(self, pairs, delta1):
        for row in pairs:
            u1_checkins = self.checkins[self.checkins.uid == row[0]]
            u2_checkins = self.checkins[self.checkins.uid == row[1]]
            u1_locs = set(u1_checkins.locid.unique())
            u2_locs = set(u2_checkins.locid.unique())
            comlocs = list(u1_locs.intersection(u2_locs))
            Isim = 0
            for loc in comlocs:
                Isim = Isim + (len(u1_checkins[u1_checkins.locid == loc]) / len(u1_checkins) + len(u2_checkins[u2_checkins.locid == loc]) / len(u2_checkins)) / 2
            lsc_len = self.space_efficient_lcs(list(u1_checkins.locid.values), list(u2_checkins.locid.values))
            u1_ratio = lsc_len / (len(u1_checkins) - lsc_len + 1)
            u2_ratio = lsc_len / (len(u2_checkins) - lsc_len + 1)
            Tsim = (u1_ratio * len(u1_checkins) + u2_ratio * len(u2_checkins)) / (len(u1_checkins) + len(u2_checkins))
            Lsim = delta1 * Isim + (1 - delta1) * Tsim
            result = pd.DataFrame([[row[0], row[1], Lsim, comlocs]], columns=['u1', 'u2', 'loc_rate', 'comlocs'])
            result.to_csv(abspath + "\\data\\city_data_adaptive_grid_dp_2\\" + self.city + "_pairs_loc_rate_new_lsc"+str(self.privacy)+".txt", sep='\t', index=False, header=False, mode='a')

    # 计算好友以及位置亲密度
    def cal_pairs_relation(self):
        pairs = list(combinations(self.users, 2))
        print("正在计算好友以及位置亲密度......")
        self.cal_relation(pairs)
        print("好友亲密度计算完成")
        self.cal_comlocs(pairs, 0.5)
        print("位置亲密度计算完成")

    @staticmethod
    def read_rate(filename, city, privacy):  # 读取similarity的文件
        dict = []
        file = open(filename, "r")
        a = file.readline()
        while a:
            temp = a.strip().split("\t")
            temp[3] = temp[3].replace("[", "")
            temp[3] = temp[3].replace("]", "")
            u1_comlocs = temp[3].strip().split(",")
            if u1_comlocs[0] != '':
                u1_comlocs = list(map(lambda x: x.replace("'", ""), u1_comlocs))
            else:
                u1_comlocs = []
            dict.append([int(temp[0]), int(temp[1]), float(temp[2]), u1_comlocs])
            a = file.readline()
        file.close()
        friends = pd.read_csv(abspath + "\\data\\city_data_adaptive_grid_dp_2\\" + city + "_pairs_fri_rate_new"+ str(privacy)+".csv", delimiter="\t", index_col=None, header=None)
        friends.columns = ['u1', 'u2', 'fri_rate']
        checkins = pd.DataFrame(dict, columns=['u1', 'u2', 'loc_rate', 'comlocs'])
        checkins.loc[:, "fri_rate"] = friends['fri_rate']
        return checkins

    def cal_friends_sim(self):
        self.cal_pairs_relation()
        # similarity = self.read_rate(filename="")
        # return similarity


if __name__ == "__main__":
    grid = [7, 16, 24, 29, 39]
    index = 0
    for i in [0.1, 1, 3, 5, 10]:
        checkins = pd.read_csv(abspath + "\\data\\city_data_adaptive_grid_dp_2" + "\\" + "SNAP_SF" + "_" + str(grid[index]) + "_" + str(grid[index]) + "_"+str(i)+".csv", delimiter=",", index_col=None, header=None)
        checkins.columns = ['uid', 'date', 'time', 'latitude', 'longitude', 'locid',  'grid_id', 'grid_id_second', 'n', 'm', 'start_grid']
        checkins = checkins.ix[:, [0, 1, 2, 7]]
        checkins.rename(columns={"grid_id_second": "locid"}, inplace=True)
        index += 1
        friends_similarity = cal_friends_similarity(checkins, "SNAP_SF", i)
        friends_similarity.cal_friends_sim()