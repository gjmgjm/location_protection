# -*- coding: utf-8 -*-
import numpy as np
import geatpy as ea
import cmath
from sklearn.metrics.pairwise import cosine_similarity

"""
该案例展示了一个离散决策变量的最小化目标的双目标优化问题。
min f1 = -25 * (x1 - 2)**2 - (x2 - 2)**2 - (x3 - 1)**2 - (x4 - 4)**2 - (x5 - 1)**2
min f2 = (x1 - 1)**2 + (x2 - 1)**2 + (x3 - 1)**2 + (x4 - 1)**2 + (x5 - 1)**2
s.t.
x1 + x2 >= 2
x1 + x2 <= 6
x1 - x2 >= -2
x1 - 3*x2 <= 2
4 - (x3 - 3)**2 - x4 >= 0
(x5 - 3)**2 + x4 - 4 >= 0
x1,x2,x3,x4,x5 ∈ {0,1,2,3,4,5,6,7,8,9,10}
"""


class MyProblem2(ea.Problem):  # 继承Problem父类

    def __init__(self, original_vector, friends_vectors, friends_delta, weight_delta):
        self.original_vector = original_vector  # 用户原始的访问频率向量
        self.friends_vectors = friends_vectors  # 用户好友的访问向量
        self.friends_delta = friends_delta
        self.weight_delta = weight_delta
        name = 'MyProblem'    # 初始化name（函数名称，可以随意设置）
        Dim = len(original_vector)
        M = 1
        maxormins = [1] * M   # 初始化maxormins（目标最小最大化标记列表，1：最小化该目标；-1：最大化该目标）
        varTypes = [0] * Dim  # 初始化varTypes（决策变量的类型，0：实数；1：整数）
        lb = [0] * Dim        # 决策变量下界
        ub = [1] * Dim       # 决策变量上界
        lbin = [1] * Dim      # 决策变量下边界
        ubin = [1] * Dim      # 决策变量上边界  “上下边界”是俗称的决策变量范围的“开闭区间”。例如如果上边界设为1，表示变量区间范围是“右闭”的，如果上边界设为0，表示变量区间范围是“右开”的。
        # 调用父类构造方法完成实例化
        ea.Problem.__init__(self, name, M, maxormins, Dim, varTypes, lb, ub, lbin, ubin)

    def aimFunc(self, pop):   # 目标函数
        Vars = pop.Phen       # 得到决策变量矩阵
        stay_x_values = [0] * self.Dim  # 剩余的值
        f = []
        for index in range(len(Vars)):
            x = Vars[index]                                                    # 一个解
            sim_orignal = cosine_similarity([x.tolist()], [self.original_vector])[0][0]
            sim_orignal = 1-sim_orignal                                        # 与用户原始向量的相似度的倒数，越小越好
            if len(self.friends_vectors) != 0:
                sim_friends = []                                               # 与好友的相似度
                for friend_index in range(len(self.friends_vectors)):
                    fri_sim = cosine_similarity([x.tolist()], [self.friends_vectors[friend_index]])[0][0]
                    sim_friends.append(self.friends_delta[friend_index] * fri_sim)  # 好友亲密度权重以及皮尔森相似度
                sim_friends = np.sum(np.array(sim_friends))
                sim_weight = np.sum(np.multiply(np.array(self.weight_delta), np.array([sim_orignal, sim_friends])))
            else:
                sim_weight = sim_orignal*self.weight_delta[0]
            f.append([sim_weight])
        for i in range(len(Vars[0])):
            stay_x_values += Vars[:, [i]]
        pop.CV = np.hstack([np.abs(stay_x_values-1)])  # 利用可行性法则处理约束条件
        pop.ObjV = np.array(f)                       # 把求得的目标函数值赋值给种群pop的ObjV
