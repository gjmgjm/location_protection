#!/usr/bin/env python
# encoding: utf-8
"""
@version: v1.0
@author: jimi
@license: Apache Licence
@contact: 977510628@qq.com
@software: PyCharm
@file: hmm.py
@time: 2019/12/27
"""
from hmmlearn import hmm
from copy import deepcopy
import numpy as np
import pandas as pd
import os
import re
import math
import gc
import time
from itertools import repeat
from adaptive_grid_divide_by_dp import adaptive_grid_divide_by_dp
from cal_friends_similarity import cal_friends_similarity
import geatpy as ea                # import geatpy
from update_features import update_features
from sklearn.metrics.pairwise import cosine_similarity
from MyProblem3 import MyProblem3
from util import util_s


abspath = os.path.abspath('..')
# time_piecies = [['00:00:00', '01:00:00'], ['01:00:00', '02:00:00'], ['02:00:00', '03:00:00'], ['03:00:00', '04:00:00'],
#                 ['04:00:00', '05:00:00'], ['05:00:00', '06:00:00'], ['06:00:00', '07:00:00'], ['07:00:00', '08:00:00'],
#                 ['08:00:00', '09:00:00'], ['09:00:00', '10:00:00'], ['10:00:00', '11:00:00'], ['11:00:00', '12:00:00'],
#                 ['12:00:00', '13:00:00'], ['13:00:00', '14:00:00'], ['14:00:00', '15:00:00'], ['15:00:00', '16:00:00'],
#                 ['16:00:00', '17:00:00'], ['17:00:00', '18:00:00'], ['18:00:00', '19:00:00'], ['19:00:00', '20:00:00'],
#                 ['20:00:00', '21:00:00'], ['21:00:00', '22:00:00'], ['22:00:00', '23:00:00'], ['23:00:00', '23:59:59']]  # 时间片段还可以设置得小一点


time_piecies = [['00:00:00', '03:00:00'], ['03:00:00', '06:00:00'], ['06:00:00', '09:00:00'], ['09:00:00', '12:00:00'],
                ['12:00:00', '15:00:00'], ['15:00:00', '18:00:00'], ['18:00:00', '21:00:00'], ['21:00:00', '23:59:59']]  # 时间片段还可以设置得小一点


class hmm_test1():

    def __init__(self, city, privacy, n, times, path, result_path):
        self.city = city
        self.privacy = privacy
        self.n = n
        self.times__ = times
        self.path = path
        self.result_path = result_path
        self.util = util_s(self.city)

    def read_data_by_day(self):   # 以天划分轨迹
        checkins = pd.read_csv(abspath + "\\data\\"+self.path + "\\" + self.city + "_" + str(self.n) + "_" + str(self.n) + "_" + str(self.privacy) + ".csv", delimiter=",", index_col=None, header=None)
        checkins.columns = ['uid', 'date', 'time', 'latitude', 'longitude', 'locid', 'grid_id', 'grid_id_second', 'n', 'm', 'start_grid']
        checkins = checkins.ix[:, [0, 1, 2, 7]]
        checkins.rename(columns={"grid_id_second": "locid"}, inplace=True)
        # checkins.sort_values(by=['uid', "time"], ascending=True, inplace=True)  # 按照时间先后进行排序,在数据处理部分已经做了
        checkins.loc[:, "time"] = checkins['time'].apply(lambda x: re.search(r'\d+:\d+:\d+', x).group())  # 时间不看日期，只看时分秒
        checkins = self.__changetime_topeices(checkins)   # 将时间转换成时间段
        checkins.drop(['time'], axis=1, inplace=True)     # 将原来的时间删除
        checkins.rename(columns={"new_time": "time"}, inplace=True)
        # locid需要所有的位置以及对应的经纬度
        locids_latlon = adaptive_grid_divide_by_dp.read_grid_latlon(abspath + "\\data\\" + self.path + "\\" + str(self.privacy) + "locids.txt")
        locids = [row[0] for row in locids_latlon]
        self.lat_lon = [row[1] for row in locids_latlon]
        self.freq_vector = [len(checkins[checkins.locid == locid])/len(checkins) for locid in locids]
        similarity = cal_friends_similarity.read_rate(abspath + "\\data\\"+self.path+"\\" + self.city + "_pairs_loc_rate_new_lsc" +str(self.privacy)+".txt", self.city, self.privacy)
        return checkins, locids, similarity

        # 两点之间的欧氏距离计算

    def euclidean_distance(self, loc1, loc2):
        return math.sqrt(((loc1[1] - loc2[1]) / float(self.util.get_lons_per_km())) ** 2 + ((loc1[0] - loc2[0]) / float(self.util.get_lats_per_km())) ** 2)

    def __changetime_topeices(self, checkins):
        checkins.insert(2, "new_time", -1, allow_duplicates=True)
        # checkins.loc[:, "new_time"] = -1
        for i in range(len(time_piecies)):
            checkins.loc[(pd.to_datetime(checkins.time, format='%H:%M:%S') >= pd.to_datetime(time_piecies[i][0], format='%H:%M:%S'))& (pd.to_datetime(checkins.time, format='%H:%M:%S') < pd.to_datetime(time_piecies[i][1], format='%H:%M:%S')), "new_time"] = i
        checkins.loc[checkins.new_time == -1, "new_time"] = len(time_piecies)-1
        return checkins

    def __build_model(self, start_pro, trans_pro, emi_pro, n_states):
        model = hmm.MultinomialHMM(n_components=n_states)
        model.startprob_ = start_pro
        model.transmat_ = trans_pro
        model.emissionprob_ = emi_pro
        return model

    def aimFunc(self, Phen, original_vector, friends_vectors, friends_delta, weight_delta, stay_indexs, stay_x):   # 目标函数
        Vars = Phen  # 得到决策变量矩阵
        # 首先要将求出的解进行标准化
        # for idx in range(len(uncomloc_indexs)):  # 将保留值插入向量中,是不可能为0的  # 当保留的位置个数太多时，速度太慢
        #     Vars = np.array([np.insert(i, stay_indexs[idx], stay_x[idx]) for i in Vars])
        seek_index = list(set(list(range(len(original_vector[0])))) - set(stay_indexs))
        seek_index.sort()
        matrix = [[0] * (len(original_vector[0]))] * (len(Vars))
        df = pd.DataFrame(matrix)  # 转换成矩阵，然后更新一列的值
        i = 0
        for j in range(len(Vars[0])):  # 将需要求解的值，插入原始矩阵中
            loc_idx = seek_index[i]
            df.loc[:, loc_idx] = Vars[:, [j]]
            i += 1
        Vars = df.values
        sim_orignal = 1 - cosine_similarity(Vars, original_vector)  # 格式[[sim],[],...,[]]
        if len(friends_vectors) != 0:
            sim_friends = cosine_similarity(Vars, friends_vectors) * friends_delta  # 格式[[sim1 sim2],[],[]]
            sim_friends = sim_friends.sum(axis=1).reshape(len(Vars), 1)  # 矩阵每行求和之后变成二维数组  [[sim],[sim]]
            sim_weight = weight_delta[0] * sim_orignal + weight_delta[1] * sim_friends  # 格式 [[sim],[]]
        else:
            sim_weight = weight_delta[0] * sim_orignal
        sim_weight_list = []
        for k, line in enumerate(sim_weight):
            sim_weight_list.append(sim_weight[k][0])
        best_result = Vars[sim_weight_list.index(min(sim_weight_list))]
        # print(best_result)
        sum1 = np.sum(best_result)
        for i in range(len(best_result)):
            best_result[i] = best_result[i]/sum1
        # print(best_result)
        return best_result

    def mutiobject_update(self, original_vector, friends_vectors, friends_delta, weight_delta, stay_indexs, stay_x):

        """================================实例化问题对象==========================="""
        problem = MyProblem3(original_vector, friends_vectors, friends_delta, weight_delta, stay_indexs, stay_x)  # 生成问题对象
        """==================================种群设置==============================="""
        Encoding = 'RI'  # 编码方式,这种编码方式上界和下界不能相等，可以改为RI
        NIND = 30  # 种群规模
        Field = ea.crtfld(Encoding, problem.varTypes, problem.ranges, problem.borders)  # 创建区域描述器
        population = ea.Population(Encoding, Field, NIND)  # 实例化种群对象（此时种群还没被初始化，完成种群对象的实例化）
        """================================算法参数设置============================="""
        myAlgorithm = ea.moea_NSGA3_templet(problem, population)  # 实例化一个算法模板对象
        myAlgorithm.MAXGEN = 100   # 最大进化代数
        """==========================调用算法模板进行种群进化========================"""
        NDSet = myAlgorithm.run()  # 执行算法模板，得到帕累托最优解集NDSet
        Phen = NDSet.Phen
        if len(Phen) != 0:   # 有解
            result = self.aimFunc(Phen, np.array([original_vector]), np.array(friends_vectors), np.array([friends_delta]), [0.5, 0.5], stay_indexs, stay_x)
            return result
        return Phen

    def mutiobject_update1(self, original_vector, friends_vectors, friends_delta, weight_delta, stay_indexs, stay_index_values):
        """================================实例化问题对象==========================="""
        # 生成问题对象
        problem = MyProblem3(original_vector, friends_vectors, friends_delta, weight_delta, stay_indexs, stay_index_values)
        """==================================种群设置==============================="""
        Encoding = 'RI'  # 编码方式
        NIND = 50  # 种群规模
        Field = ea.crtfld(Encoding, problem.varTypes, problem.ranges, problem.borders)  # 创建区域描述器
        population = ea.Population(Encoding, Field, NIND)  # 实例化种群对象（此时种群还没被初始化，仅仅是完成种群对象的实例化）
        """================================算法参数设置============================="""
        myAlgorithm = ea.soea_DE_rand_1_L_templet(problem, population)  # 实例化一个算法模板对象
        myAlgorithm.MAXGEN = 200  # 最大进化代数
        myAlgorithm.mutOper.F = 0.5  # 差分进化中的参数F
        myAlgorithm.recOper.XOVR = 0.7  # 重组概率
        """===========================调用算法模板进行种群进化======================="""
        [population, obj_trace, var_trace] = myAlgorithm.run()  # 执行算法模板
        # population.save()  # 把最后一代种群的信息保存到文件中
        # 输出结果
        best_gen = np.argmin(problem.maxormins * obj_trace[:, 1])  # 记录最优种群个体是在哪一代
        best_ObjV = obj_trace[best_gen, 1]
        print('最优的目标函数值为：%s' % best_ObjV)
        print('最优的决策变量值为：')
        for i in range(var_trace.shape[1]):
            print(var_trace[best_gen, i])
        print('有效进化代数：%s' % obj_trace.shape[0])
        print('最优的一代是第 %s 代' % (best_gen + 1))
        print('评价次数：%s' % myAlgorithm.evalsNum)
        print('时间已过 %s 秒' % myAlgorithm.passTime)
        # best_result = var_trace[best_gen]
        # stay_index_values_sum = np.sum(best_result)
        # original_stay_index_values_sum = np.sum(np.array(stay_index_values))
        # best_result = best_result*original_stay_index_values_sum/stay_index_values_sum
        # for idx in range(len(stay_indexs)):  # 将保留值插入向量中,是不可能为0的
        #     np.insert(best_result, stay_indexs[idx], stay_index_values[idx])
        return var_trace[best_gen]

    def normalize(self, pro):
        """
        :param pro: 输入的矩阵
        :return:
        """
        col_len = pro.shape[1]
        for k, line in enumerate(pro):
            sum1 = np.sum(line)
            if sum1 != 0:  # 一行的和不为0
                for i in range(col_len):
                    if pro[k][i] != 0:
                        pro[k][i] = pro[k][i] / sum1
            else:  # 一行的和为0,则给它一个均匀分布
                for i in range(col_len):
                    pro[k][i] = 1 / col_len
        return pro

    def normalize_unzero(self, pro):
        col_len = pro.shape[1]
        for k, line in enumerate(pro):
            sum1 = np.sum(line)
            if sum1 != 0:  # 一行的和不为0
                for i in range(col_len):
                    if pro[k][i] != 0:
                        pro[k][i] = pro[k][i] / sum1
        return pro

    def train_abpi(self, delta1, delta2, delta3, delta4, top):
        checkins, locids, similarity = self.read_data_by_day()
        similarity.loc[:, 'sim'] = 0
        similarity.loc[similarity.fri_rate >= 0, 'sim'] = similarity[similarity.sim >= 0]\
                    .apply(lambda x: x['loc_rate'] * delta1 + x['fri_rate'] * delta2, axis=1)  # 具有社交关系的用户对
        similarity.drop(['comlocs'], axis=1, inplace=True)
        sim_over = deepcopy(similarity[(similarity.sim >= delta3) & (similarity.fri_rate >= 0)])  # 获得好友的相似度
        n_states = len(locids)
        user_checkins = checkins.groupby(["uid", "date"])  # 按照用户轨迹按照id、date对数据进行分组,从小到大排序
        all_locid_indexs = list(range(n_states))
        data = []
        for group in user_checkins:         # 首先获取所有用户的位置访问频率分部向量
            # print("用户"+str(group[0])+"模型参数更新中...")
            # u_locids = list(group[1].locid.values)
            # u_locids_len = len(u_locids)
            # start_pro = [u_locids.count(x) / u_locids_len for x in locids]  # 地点的初始概率
            # print("初始状态矩阵A参数获取完成")
            # data.append([group[0], start_pro])
            data.append([group[0][0], group[0][1]])
            # data.append([group[0][0], group[0][1], start_pro])
        data = pd.DataFrame(data, columns=["uid", "date"])   # 增加日期

        del user_checkins
        gc.collect()

        # data = data[~data.uid.isin([3, 4, 5, 6, 7, 11, 16, 17])]

        # disturb_checkins = pd.DataFrame()
        for row in data.itertuples(index=False, name=False):
            start_time = time.time()
            print("用户"+str(row[0])+"日期"+str(row[1])+"模型参数更新中...")
            friends = sim_over[(sim_over.u1 == row[0]) | (sim_over.u2 == row[0])]
            friends = list(set(friends.u1.unique()).union(set(friends.u2.unique())))
            friends.sort()
            if len(friends) != 0:      # 得到用户的好友
                friends.remove(row[0])

            # original_vector = row[1]
            u_checkins = deepcopy(checkins[(checkins.uid == row[0]) & (checkins.date == row[1])])  # 复制原始的数据
            u_locids = list(u_checkins.locid.values)
            u_locids_len = len(u_locids)
            original_vector = [u_locids.count(x) / u_locids_len for x in locids]    # 增加日期
            # original_vector = row[2]  # 增加日期
            friends_delta = []
            friends_vectors = []                                                       # 好友总轨迹，不分天
            # friends_vectors = list(data[data.uid.isin(friends)].start_pro.values)    # 好友的每一天的轨迹
            for fri in friends:
                f_locids = list(checkins[(checkins.uid == fri)].locid.values)
                f_locids_len = len(f_locids)
                f_vector = [f_locids.count(x) / f_locids_len for x in locids]
                friends_vectors.append(f_vector)
                if fri > row[0]:
                    friends_delta.append(similarity[(similarity.u1 == row[0]) & (similarity.u2 == fri)].sim.values[0])
                else:
                    friends_delta.append(similarity[(similarity.u1 == fri) & (similarity.u2 == row[0])].sim.values[0])
            comloc_indexs = []  # 共同访问位置，这里了可能需要用户的整个向量中的共同访问位置
            u_all_checkins = checkins[checkins.uid == row[0]]
            u_all_checkins_len = len(u_all_checkins)
            u_all_locids = list(u_all_checkins.locid.values)
            original_tra_vector = [u_all_locids.count(x) / u_all_checkins_len for x in locids]  # 原始轨迹中的所有签到
            for f_vector in friends_vectors:  # 好友的位置访问频率向量
                new_list = np.multiply(np.array(original_tra_vector), np.array(f_vector))  # 两个向量对应相乘
                common_loc_index = np.flatnonzero(new_list).tolist()  # 不为0的地方就是共同访问位置的索引
                comloc_indexs.extend(common_loc_index)
                comloc_indexs = list(set(comloc_indexs))  # 去重

            # 增加用户不可能去的地方，减少要求的变量的个数，可以加入距离
            # 首先为用户当天的访问的所有位置与所有位置进行一个距离的计算，设定一个topk的值，表示用户可能去的地方，只对这些位置进行x的求解
            user_visited_locidx = np.flatnonzero(original_vector).tolist()  # 用户当天访问的位置
            dis_lists = [list(map(self.euclidean_distance, self.lat_lon, repeat(self.lat_lon[loc_index]))) for loc_index in user_visited_locidx]  # 用户访问过的位置与其他位置的距离
            seek_indexs = []
            avg_len = 0
            if len(dis_lists) > top:  # 访问的位置多于top
                top = len(dis_lists)
                avg_len += int(math.ceil(3 * top / len(dis_lists)))   # 取前3个
            else:
                avg_len += int(math.ceil(2 * top / len(dis_lists)))      # 前
            for dis_list in dis_lists:
                loc_dis = list(map(list, zip(*[all_locid_indexs, dis_list])))  # 位置索引和距离
                loc_dis = sorted(loc_dis, key=(lambda x: x[1]))       # 按照距离进行排序
                loc_dis = loc_dis[0:top]                              # 每个位置选取前top个作为可能访问的位置
                seek_indexs.append([_[0] for _ in loc_dis])
            if avg_len > top:
                avg_len = top
            seek_index = set(seek_indexs[0][0:avg_len])
            for idx in seek_indexs:
                seek_index = seek_index.union(set(idx[0:avg_len]))
            seek_index = seek_index - (set(comloc_indexs))                    # 去掉所有的共同访问位置
            stay_index = list(set(all_locid_indexs) - seek_index)             # 取值固定的位置索引
            stay_index.sort()
            stay_index_values = [0]*len(stay_index)                            # 取值固定的位置的值，初始化为0
            print("time1:", len(seek_index), len(set(comloc_indexs)), (time.time() - start_time)/60)


            start_time = time.time()
            if len(stay_index) != len(locids):  # 即没有需要更新的位置
                updated_vector = list(self.mutiobject_update(original_vector, friends_vectors, friends_delta, [0.5, 0.5], stay_index, stay_index_values))
            else:
                updated_vector = []
            print("time2:", (time.time() - start_time)/60)
            start_time = time.time()
            print("     状态矩阵A参数更新完成")


            # 获取当前用户的转移矩阵
            tras_pro = np.zeros((n_states, n_states))  # 转移矩阵
            # u_locids = list(checkins[checkins.uid == row[0]].locid.values)
            # 每一天的轨迹
            u_locids = list(checkins[(checkins.uid == row[0]) & (checkins.date == row[1])].locid.values)
            u_locids_len = len(u_locids)
            for index in range(u_locids_len):
                if (index + 1) != u_locids_len:
                    next = index + 1
                    cur_locid = u_locids[index]
                    next_locid = u_locids[next]
                    tras_pro[locids.index(cur_locid)][locids.index(next_locid)] += 1  # 更新转移矩阵
            # 将转移矩阵每一行的概率和转换成1
            tras_pro = self.normalize_unzero(tras_pro)

            # 得到发射矩阵
            emi_pro = np.zeros((n_states, len(time_piecies)))  # 发射矩阵
            u_locid_times = checkins[(checkins.uid == row[0]) & (checkins.date == row[1])]\
                            .groupby(by=['locid', 'time']).size().reset_index(name="u_times")
            for _ in u_locid_times.itertuples(index=False, name=False):
                emi_pro[locids.index(_[0])][int(_[1])] = _[2]
            emi_pro = self.normalize_unzero(emi_pro)

            # 如果访问向量没有更新，则不用更新转移矩阵和发射矩阵
            if len(updated_vector) != 0:
                update_feature = update_features(original_vector, updated_vector, tras_pro, emi_pro, self.lat_lon, self.freq_vector, comloc_indexs, self.city)
                updated_tras = update_feature.update_transmat(delta4)
                updated_emi = update_feature.update_emi()
                updated_vector = np.array(updated_vector)
                tras_pro = np.array(updated_tras)
                emi_pro = np.array(updated_emi)
            else:
                updated_vector = np.array(original_vector)

            # 归一化,可以写成一个函数进行调用
            tras_pro = self.normalize(tras_pro)
            print("     转移矩阵B参数更新完成")
            emi_pro = self.normalize(emi_pro)
            print("     发射矩阵π参数更新完成")

            times_ = list(checkins[(checkins.uid == row[0]) & (checkins.date == row[1])].time.values)  # 每个时刻都作为一个观测序列
            list_new = [[t] for t in times_]
            observations = np.array(list_new)
            results = self.predict(updated_vector, tras_pro, emi_pro, observations)

            disturb_locids = [locids[index] for index in results]
            u_checkins.loc[:, 'locid_after'] = disturb_locids
            # disturb_checkins = pd.concat([disturb_checkins, u_checkins], ignore_index=True)
            u_checkins.to_csv(abspath + "\\data\\"+self.result_path+"\\"+str(self.privacy)+ "_" + str(self.times__) + ".csv", index=False, header=False, mode='a')
            print("time3：", (time.time()- start_time)/60)

    def predict(self, A, B, PI, observations):
        hidden_states = self.__build_model(A, B, PI, len(A)).predict(observations)
        return hidden_states


if __name__ == "__main__":
    for i in [1, 2, 3]:
        hmm_test = hmm_test1("SNAP_SF", 0.1, 7, i, "city_data_adaptive_grid_dp_2", "result_data_dp_divide_lsc_01_09")
        # train_ABPI(self, delta1, delta2, delta3, delta4):# 地理，社交、亲密度阈值、
        hmm_test.train_abpi(0.6, 0.4, 0.05, 0.5, 30)
