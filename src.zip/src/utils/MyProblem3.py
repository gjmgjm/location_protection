# -*- coding: utf-8 -*-
import numpy as np
import geatpy as ea
import pandas as pd
import cmath
import time
from sklearn.metrics.pairwise import cosine_similarity

"""
该案例展示了一个离散决策变量的最小化目标的双目标优化问题。
min f1 = -25 * (x1 - 2)**2 - (x2 - 2)**2 - (x3 - 1)**2 - (x4 - 4)**2 - (x5 - 1)**2
min f2 = (x1 - 1)**2 + (x2 - 1)**2 + (x3 - 1)**2 + (x4 - 1)**2 + (x5 - 1)**2
s.t.
x1 + x2 >= 2
x1 + x2 <= 6
x1 - x2 >= -2
x1 - 3*x2 <= 2
4 - (x3 - 3)**2 - x4 >= 0
(x5 - 3)**2 + x4 - 4 >= 0
x1,x2,x3,x4,x5 ∈ {0,1,2,3,4,5,6,7,8,9,10}
"""


class MyProblem3(ea.Problem):  # 继承Problem父类

    def __init__(self, original_vector, friends_vectors, friends_delta, weight_delta, stay_indexs, stay_x):
        self.stay_indexs = stay_indexs
        self.stay_x = stay_x
        self.original_flatnonzero = np.flatnonzero(original_vector).tolist()        # 用户访问过的位置索引
        self.weight_delta = weight_delta                                            # 相似度和距离的权重函数
        self.n_state = len(original_vector)
        self.seek_index = list(set(list(range(len(original_vector)))) - set(stay_indexs))
        self.seek_index.sort()  # 需要求解的位置索引
        self.original_vector = np.array([original_vector])  # 用户原始的访问频率向量
        self.friends_vectors = np.array(friends_vectors)  # 用户好友的访问向量
        self.friends_delta = np.array([friends_delta])  # 用户好友的亲密度权重
        matrix = [[0] * self.n_state] * 30
        self.df = pd.DataFrame(matrix)  # 转换成矩阵，然后更新一列的值
        name = 'MyProblem'                                                          # 初始化name（函数名称，可以随意设置）
        Dim = len(original_vector) - len(self.stay_indexs)                          # 初始化Dim（决策变量维数）
        M = 1
        maxormins = [1] * M   # 初始化maxormins（目标最小最大化标记列表，1：最小化该目标；-1：最大化该目标）
        varTypes = [0] * Dim  # 初始化varTypes（决策变量的类型，0：实数；1：整数）
        lb = [0] * Dim        # 决策变量下界
        ub = [1 - np.sum(np.array(self.stay_x))] * Dim       # 决策变量上界
        lbin = [1] * Dim      # 决策变量下边界
        ubin = [1] * Dim      # 决策变量上边界  “上下边界”是俗称的决策变量范围的“开闭区间”。例如如果上边界设为1，表示变量区间范围是“右闭”的，如果上边界设为0，表示变量区间范围是“右开”的。
        # 调用父类构造方法完成实例化
        ea.Problem.__init__(self, name, M, maxormins, Dim, varTypes, lb, ub, lbin, ubin)

    def aimFunc(self, pop):   # 目标函数
        Vars = pop.Phen       # 得到决策变量矩阵,
        stay_x_values = 1 - np.sum(np.array(self.stay_x))  # 剩余的值 这里比较费时，应该是的
        # start = time.time()
        i = 0
        for j in range(len(Vars[0])):                                 # 将需要求解的值，插入原始矩阵中
            loc_idx = self.seek_index[i]
            self.df.loc[:, loc_idx] = Vars[:, [j]]
            i += 1
        Vars = self.df.values
        # for idx in range(len(self.stay_indexs)):       # 将保留值插入向量中,是不可能为0的
        #     Vars = np.array([np.insert(i, self.stay_indexs[idx], self.stay_x[idx]) for i in Vars])
        # print("时间：", (time.time()-start))
        # start = time.time()
        sim_orignal = 1 - cosine_similarity(Vars, self.original_vector)   # 格式[[sim],[],...,[]]
        if len(self.friends_vectors) != 0:
            sim_friends = cosine_similarity(Vars, self.friends_vectors) * self.friends_delta  # 格式[[sim1 sim2],[],[]]
            sim_friends = sim_friends.sum(axis=1).reshape(len(Vars), 1)       # 矩阵每行求和之后变成二维数组  [[sim],[sim]]
            sim_weight = self.weight_delta[0] * sim_orignal + self.weight_delta[1] * sim_friends  # 格式 [[sim],[]]
        else:                                                             # 没有好友的约束
            sim_weight = self.weight_delta[0] * sim_orignal
        for i in range(len(pop.Phen[0])):
            stay_x_values = stay_x_values - pop.Phen[:, [i]]
        # print(stay_x_values)
        # print("time:", (time.time() - start))
        pop.CV = np.hstack([np.abs(stay_x_values)])  # 利用可行性法则处理约束条件
        pop.ObjV = sim_weight        # 把求得的目标函数值赋值给种群pop的ObjV
