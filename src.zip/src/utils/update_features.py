#!/usr/bin/env python
# encoding: utf-8
import math
import numpy as np
from itertools import repeat
import pandas as pd


class update_features():

    def __init__(self, original_vector, updated_vector, transmat_, emi_, lat_lon, freq_vector, comloc_idx, city):
        self.new_locs = []
        self.stay_locs = []
        for idx in range(len(original_vector)):
            if (original_vector[idx] == 0) & (updated_vector[idx] != 0):  # 出现的新位置
                self.new_locs.append(idx)
            if (original_vector[idx] != 0) & (updated_vector[idx] != 0):  # 保留的位置
                self.stay_locs.append(idx)
        self.transmat_ = transmat_
        self.updated_vector_nozero_index = np.flatnonzero(updated_vector).tolist()  # 更新位置访问矩阵之后不为0的所有位置索引
        self.updated_vector_locs = [lat_lon[idx] for idx in self.updated_vector_nozero_index]   # 更新位置访问矩阵之后不为0的所有位置
        self.lat_lon = lat_lon
        self.freq_vector = freq_vector
        self.comloc_idx = comloc_idx
        self.emi_ = emi_
        if city == "GW_NY":
            self.lons_per_km = 0.0059352 * 2  # NY
            self.lats_per_km = 0.0044966 * 2  # delta latitudes per kilo meter
        elif city == "GW_SF" or city == "SNAP_SF":
            self.lons_per_km = 0.005681 * 2  # SF
            self.lats_per_km = 0.004492 * 2  # delta latitudes per kilo meter
        elif city == "GW_AS":
            self.lons_per_km = 0.005681 * 2  # AS
            self.lats_per_km = 0.004492 * 2  # delta latitudes per kilo meter

    def update_newlocs_transmat_(self, delta):
        for idx in self.new_locs:
            pre_dis_list = list(map(self.euclidean_distance, self.updated_vector_locs, repeat(self.lat_lon[idx])))
            freq_list = [self.freq_vector[index] for index in self.updated_vector_nozero_index]   # 位置访问频率分布
            weight_list = [self.updated_vector_nozero_index, pre_dis_list, freq_list]
            weight_list = list(map(list, zip(*weight_list)))
            for i in range(len(weight_list)):
                weight_list[i][1] = math.exp(-weight_list[i][1])
            weight_list = pd.DataFrame(weight_list, columns=['locid_index', 'dis_pro', 'freq_pro'])
            weight_list.loc[:, 'dis_pro'] = weight_list.loc[:, 'dis_pro'] / weight_list.dis_pro.sum()
            weight_list.loc[:, 'freq_pro'] = weight_list.loc[:, 'freq_pro'] / weight_list.freq_pro.sum()
            weight_list.loc[:, 'weight_pro'] = weight_list.apply(lambda x: x['dis_pro'] * delta + x['freq_pro'] * (1-delta), axis=1)
            weight_list.loc[:, 'weight_pro'] = weight_list.loc[:, 'weight_pro'] / weight_list.weight_pro.sum()
            weight_pro = [row[3] for row in weight_list.itertuples(index=False, name=False)]
            locid_index = [row[0] for row in weight_list.itertuples(index=False, name=False)]
            for index1 in self.updated_vector_nozero_index:
                self.transmat_[idx][index1] = weight_pro[locid_index.index(index1)]

    def update_staylocs_transmat_(self):
        col_len = len(self.transmat_[0])
        for idx in self.stay_locs:
            for index in self.comloc_idx:
                self.transmat_[idx][index] = 0
            sum1 = np.sum(self.transmat_[idx])
            if sum1 != 0:  # 一行的和不为0
                for i in range(col_len):
                    if self.transmat_[idx][i] != 0:
                        self.transmat_[idx][i] = self.transmat_[idx][i] / sum1
            else:  # 一行的和为0,则给它一个均匀分布
                for i in range(col_len):
                    self.transmat_[idx][i] = 1 / col_len

    def update_newlocs_emi_(self):
        for idx in self.new_locs:
            pre_dis_list = list(map(self.euclidean_distance, self.updated_vector_locs, repeat(self.lat_lon[idx])))
            weight_list = [self.updated_vector_nozero_index, pre_dis_list]
            weight_list = list(map(list, zip(*weight_list)))
            for i in range(len(weight_list)):
                weight_list[i][1] = math.exp(-weight_list[i][1])
            weight_list = pd.DataFrame(weight_list, columns=['locid_index', 'dis_pro'])
            weight_list = weight_list.sort_values(by=['dis_pro'], ascending=False).reset_index(drop=True)  # 按照距离降序排列
            close_loc_indexs = list(weight_list.locid_index.values)
            close_loc_index = close_loc_indexs[0]   # 前10距离比较近的位置
            self.emi_[idx] = self.emi_[close_loc_index]

    def update_staylocs_emi_(self):   # 不会保留共同访问位置，只会保留非共同访问位置
        for idx in self.stay_locs:
            pre_dis_list = list(map(self.euclidean_distance, self.updated_vector_locs, repeat(self.lat_lon[idx])))
            weight_list = [self.updated_vector_nozero_index, pre_dis_list]
            weight_list = list(map(list, zip(*weight_list)))
            for i in range(len(weight_list)):
                weight_list[i][1] = math.exp(-weight_list[i][1])
            weight_list = pd.DataFrame(weight_list, columns=['locid_index', 'dis_pro'])
            weight_list = weight_list.sort_values(by=['dis_pro'], ascending=False).reset_index(drop=True)  # 按照距离降序排列
            close_loc_indexs = list(weight_list.locid_index.values)
            close_loc_index = close_loc_indexs[0]   # 前10距离比较近的位置
            self.emi_[idx] = self.emi_[close_loc_index]

    def update_transmat(self, delta):
        # print("位置转移矩阵正在更新中......")
        self.update_newlocs_transmat_(delta)
        self.update_staylocs_transmat_()
        # print("位置转移矩阵更新完成")
        return self.transmat_

    def update_emi(self):
        # print("发射矩阵正在更新中......")
        self.update_newlocs_emi_()
        # print("发射矩阵更新完成")
        return self.emi_

    # 两点之间的欧氏距离计算
    def euclidean_distance(self, loc1, loc2):
        return math.sqrt(((loc1[1] - loc2[1]) / float(self.lons_per_km)) ** 2 + ((loc1[0] - loc2[0]) / float(self.lats_per_km)) ** 2)


if __name__ == "__main__":
     # start = time.time()
     #  def __init__(self, original_vector, updated_vector, transmat_,emi_, lat_lon, freq_vector, comloc_idx, city):
     c = update_features([0.1, 0.2, 0.7], [0.2, 0.3, 0.5],
                        [[0.1, 0.2, 0.7], [0.2, 0.1, 0.7], [0, 0, 0]], [[0.1, 0.9], [0.2, 0.8], [0.3, 0.7]],
                        [[30.2691029532, -97.7493953705], [30.2557309927, -97.7633857727], [30.2634181234, -97.7575966669]],
                        [0.4, 0.1, 0.5], [0], "GW_AS")
     print(c.update_transmat(0.5))


