#!/usr/bin/env python
# encoding: utf-8
"""
@version: v1.0
@author: jimi
@license: Apache Licence
@contact: 977510628@qq.com
@software: PyCharm
@file: hmm.py
@time: 2019/12/27
"""

class util_s():

    def __init__(self, city):
        self.city = city
        if city == "GW_NY":
            self.lons_per_km = 0.0059352 * 2  # NY
            self.lats_per_km = 0.0044966 * 2  # delta latitudes per kilo meter
        elif city == "GW_SF" or city == "SNAP_SF":
            self.lons_per_km = 0.005681 * 2  # SF
            self.lats_per_km = 0.004492 * 2  # delta latitudes per kilo meter
        elif city == "GW_AS":
            self.lons_per_km = 0.005681 * 2  # AS
            self.lats_per_km = 0.004492 * 2  # delta latitudes per kilo meter

    def get_city(self):
        return self.city

    def get_lons_per_km(self):
        return self.lons_per_km

    def get_lats_per_km(self):
        return self.lats_per_km