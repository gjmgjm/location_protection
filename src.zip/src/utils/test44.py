#!/usr/bin/env python
# encoding: utf-8  \
from HMM3 import hmm_test1
from cal_close_relation_random_by_difsim_adaptive_ALL import cal_close_relation_random_by_difsim_adaptive_ALL
import time
class test11():

    def __init__(self):
        pass


if __name__ == "__main__":

    for i in [1, 2, 3]:
        #     start = time.time()
        #     cal = cal_close_relation_random_by_difsim_adaptive_ALL("SNAP_SF", 0.2, 39, 39)
        #     # cal.cal_pairs_relation()
        #     # cal.get_middle_num(0.6, 0.4, 0.005)
        #     cal.cal_similarity1(0.6, 0.4, 0.05, 0.4, 0.4, 0.8, i, 1, 100)
        hmm_test = hmm_test1("SNAP_SF", 3, 24, i, "city_data_adaptive_grid_dp_2", "result_data_dp_divide_lsc_01_10")
        # train_ABPI(self, delta1, delta2, delta3, delta4):# 地理，社交、亲密度阈值、
        hmm_test.train_abpi(0.6, 0.4, 0.05, 0.5, 20)
    # hmm_test = hmm_test1("SNAP_SF", 5, 29, 2, "city_data_adaptive_grid_dp_2", "result_data_dp_divide_lsc_01_09")
    # # train_ABPI(self, delta1, delta2, delta3, delta4):# 地理，社交、亲密度阈值、
    # hmm_test.train_abpi(0.6, 0.4, 0.05, 0.5, 20)

    # hmm_test = hmm_test1("SNAP_SF", 0.1, 7, 2, "city_data_adaptive_grid_dp_2", "result_data_dp_divide_lsc_01_09")
    # # train_ABPI(self, delta1, delta2, delta3, delta4):# 地理，社交、亲密度阈值、
    # hmm_test.train_abpi(0.6, 0.4, 0.05, 0.5, 30)

    # for i in [1, 2]:
    #     start = time.time()
    #     cal = cal_close_relation_random_by_difsim_adaptive_ALL("SNAP_SF", 0.2, 29, 29)
    #     # cal.cal_pairs_relation()
    #     # cal.get_middle_num(0.6, 0.4, 0.005)
    #     cal.cal_similarity1(0.6, 0.4, 0.05, 0.4, 0.4, 0.8, i, 1, 100)

    # for i in [1, 2, 3, 4, 5]:
    #     hmm_test = hmm_test1("SNAP_SF", 10, 52, i)
    #     # train_ABPI(self, delta1, delta2, delta3, delta4):# 地理，社交、亲密度阈值、
    #     hmm_test.train_ABPI(0.6, 0.4, 0.12, 0.5)