#!/usr/bin/env python
# encoding: utf-8
# 数据预处理
# 清洗

import time
import pandas as pd
import numpy as np
from copy import deepcopy
import os
import datetime

abspath = os.path.abspath('..')
dict = []
# city_list = [[30.387953, -97.843911, 30.249935, -97.635460], [40.836357, -74.052914, 40.656702, -73.875168], [37.809524, -122.520352, 37.708991, -122.358712]]  # AS
# city_list = [[40.836357, -74.052914, 40.656702, -73.875168]]   # NY
city_list = [[37.809524, -122.520352, 37.708991, -122.358712]]   # SF


class data_handle():

    def __init__(self, ranges=None):
        self.ranges = ranges
        # self.filename = abspath+"/data/origin_data/Gowalla_totalCheckins.txt"
        self.filename = "G:\\SNAP Brightkite\\checkins.txt"
        # 格式为(maxlat,minlng),(minlat,maxlng) 为左上角点和右下角点

    def divide_area_1(self):   # 重新选取SF的数据
        checkins = pd.read_csv("G:\\SNAP Brightkite\\checkins.txt", delimiter="\t", index_col=None)
        checkins.columns = ['uid', 'time', 'time1', 'latitude', 'longitude', 'locid']
        checkins['time'] = checkins['time'].str.cat(checkins['time1'], sep=" ")
        checkins.drop(columns=['time1'], inplace=True)
        df = checkins[(checkins.latitude >= city_list[0][2]) & (checkins.latitude <= city_list[0][0]) & (checkins.longitude >= city_list[0][1]) & (checkins.longitude <= city_list[0][3])]
        df.to_csv(abspath + "\\data\\city_data\\" + "SNAP_NY.csv", sep='\t', header=True, index=False)
        self.choose_data1(df, "SNAP_SF")

    def checkins_edges1(self, checkins, city):
        users = checkins.uid.unique().tolist()
        print(len(users))
        users.sort(reverse=False)
        self.users = np.array(deepcopy(users))  # 将用户的id进行从小到大的排序
        edges = pd.read_csv("G:\\SNAP Brightkite\\edges.txt", delimiter='\t', index_col=None)
        edges.columns = ["u1", "u2"]
        uids = checkins.uid.unique()
        pairs = []
        for row in edges.itertuples(index=False, name=False):
            if row[0] in uids and row[1] in uids:
                pairs.append(row)
        pairs = pd.DataFrame(pairs, columns=['u1', 'u2'])
        pairs = pairs[pairs.u1 < pairs.u2]
        print(len(pairs))
        pairs.to_csv(abspath+"\\data\\city_data\\"+city+"_edgs.csv", sep="\t", index=False, header=None)

    # 过滤错误数据
    def get_all_dict(self):
        file = open(self.filename, "r")
        a = file.readline()
        count = 0
        while a:
            temp = a.strip().split("\t")
            if temp[0] != "" and temp[1] != "" and temp[2] != "" and temp[3] != "" and temp[4] != "":
               if temp[2].find(".") >= 0 and temp[3].find(".") >= 0:
                   if len(temp[2].split('.')[1]) >= 6 and len(temp[3].split('.')[1]) >= 6:
                      date = temp[1].split("T")
                      temp[1] = date[0] + " " + date[1].strip("Z")
                      dict.append(temp)
            count += 1
            a = file.readline()
        file.close()
        checkins = pd.DataFrame(dict, columns=['uid', 'time', 'latitude', 'longitude', 'locid'])
        print("数据清洗前总条数为：", count)
        print("清洗后数据条数为：", len(checkins))
        checkins.to_csv(abspath+"\\data\\origin_data\\totalCheckins.txt", header=True, sep="\t",index=False)
        return checkins

    # 基本数据分析
    def get_avg_userchenkins(self, checkins):
        print("总得签到记录数：", len(checkins))
        print("总用户数：", len(checkins.uid.unique()))
        print("总位置数：", len(checkins.locid.unique()))

        # 统计每个用户的总共签到次数
        usersCheckinTimes_uid = checkins.groupby("uid").size().reset_index(name="uid_times")
        # 每个用户的签到数据统计  最大 最小 平均
        usersCheckinTimesMax = np.max(usersCheckinTimes_uid.uid_times)
        usersCheckinTimesMin = np.min(usersCheckinTimes_uid.uid_times)
        usersCheckinTimesAvg = np.average(usersCheckinTimes_uid.uid_times)

        # 统计每个用户在签到过的地方的签到次数
        usersCheckinTImes_uid_locid = checkins.groupby(["uid", "locid"]).size().reset_index(name="uid_locid_times")
        usersCheckinTImes_uid_locidMax = np.max(usersCheckinTImes_uid_locid.uid_locid_times)
        usersCheckinTImes_uid_locidMin = np.min(usersCheckinTImes_uid_locid.uid_locid_times)
        usersCheckinTImes_uid_locidAvg = np.average(usersCheckinTImes_uid_locid.uid_locid_times)

        # 统计用户签到的不同位置个数
        usersCheckinDiversity = usersCheckinTImes_uid_locid.groupby(["uid"]).size().reset_index(name="uid_locid_uid_times")
        print("用户签到的不同位置个数小于等于2", len(usersCheckinDiversity[usersCheckinDiversity.uid_locid_uid_times <= 2]))
        usersCheckinDiversityMax = np.max(usersCheckinDiversity.uid_locid_uid_times)
        usersCheckinDiversityMin = np.min(usersCheckinDiversity.uid_locid_uid_times)
        usersCheckinDiversityAvg = np.average(usersCheckinDiversity.uid_locid_uid_times)

        # 位置签到数
        locid_nums = checkins.groupby("locid").size().reset_index(name="locid_times")
        # print("位置签到个数小于等于1", len(locid_nums[locid_nums.locid_times <=1]))
        locCheckinTimesMax = np.max(locid_nums.locid_times)
        locCheckinTimesMin = np.min(locid_nums.locid_times)
        locCheckinTimesAvg = np.average(locid_nums.locid_times)

        print("位置签到数：", locCheckinTimesMax, locCheckinTimesMin, locCheckinTimesAvg)
        print("用户签到数：", usersCheckinTimesMax, usersCheckinTimesMin, usersCheckinTimesAvg)
        # print("用户位置签到数：", usersCheckinTImes_uid_locidMax, usersCheckinTImes_uid_locidMin, usersCheckinTImes_uid_locidAvg)
        print("用户签到的不同位置个数：", usersCheckinDiversityMax, usersCheckinDiversityMin, usersCheckinDiversityAvg)

    def choose_data(self,checkins, city):
        print("开始筛选数据")
        userCheckins = checkins.groupby(["locid", "uid"]).size().reset_index(name="locid_uid_times")
        ins2 = userCheckins.groupby(["locid"]).size().reset_index(name="locid_user_times")
        ins2 = ins2[ins2.locid_user_times == 1]
        reject_locids = list(ins2.locid.unique())  # 这些位置只有一个用户签到
        choose_checkins = checkins[~checkins.locid.isin(reject_locids)]
        usersCheckin = choose_checkins.groupby(["uid"]).size().reset_index(name="uid_locid_uid_times")
        ins1 = usersCheckin[usersCheckin.uid_locid_uid_times >= 30]
        uids = list(ins1.uid.unique())
        choose_checkins = choose_checkins[choose_checkins.uid.isin(uids)]
        print(len(choose_checkins.uid.unique()))
        choose_checkins.to_csv(abspath + "\\data\\city_data\\"+city+"_1.csv", sep='\t', header=True, index=False)
        self.get_avg_userchenkins(choose_checkins)
        return choose_checkins

    def choose_data1(self, checkins, city):
        print("开始筛选数据")
        usersCheckin = checkins.groupby(["uid"]).size().reset_index(name="uid_locid_uid_times")
        ins1 = usersCheckin[usersCheckin.uid_locid_uid_times >= 15]
        uids = list(ins1.uid.unique())
        choose_checkins = checkins[checkins.uid.isin(uids)]
        # print(len(choose_checkins.uid.unique()))
        choose_checkins.to_csv(abspath + "\\data\\city_data\\" + city + "_1.csv", sep='\t', header=True, index=False)
        self.get_avg_userchenkins(choose_checkins)
        return choose_checkins

    def divide_area(self):
        checkins = pd.read_csv(abspath+"\\data\\origin_data\\totalCheckins.txt", delimiter="\t", index_col=None)
        checkins.columns = ['uid', 'time', 'latitude', 'longitude', 'locid']
        path = abspath + "\\data\\city_data\\"
        df = checkins[(checkins.latitude >= city_list[0][2]) & (checkins.latitude <= city_list[0][0]) & (checkins.longitude >= city_list[0][1]) & (checkins.longitude <= city_list[0][3])]
        df.to_csv(path + "GW_AS.csv", sep='\t', header=True, index=False)
        data = self.choose_data(df, "GW_AS")
        self.checkins_edges(data, "GW_AS")

        df = checkins[(checkins.latitude >= city_list[1][2]) & (checkins.latitude <= city_list[1][0]) & (checkins.longitude >= city_list[1][1]) & (checkins.longitude <= city_list[1][3])]
        df.to_csv(path + "GW_NY.csv", sep='\t', header=True, index=False)
        data = self.choose_data(df, "GW_NY")
        self.checkins_edges(data, "GW_NY")

        df = checkins[(checkins.latitude >= city_list[2][2]) & (checkins.latitude <= city_list[2][0]) & (checkins.longitude >= city_list[2][1]) & (checkins.longitude <= city_list[2][3])]
        df.to_csv(path + "GW_SF.csv", sep='\t', header=True, index=False)
        data = self.choose_data(df, "GW_SF")
        self.checkins_edges(data, "GW_SF")

    def checkins_edges(self, checkins, city):
        users = checkins.uid.unique().tolist()
        users.sort(reverse=False)
        self.users = np.array(deepcopy(users))  # 将用户的id进行从小到大的排序
        edges = pd.read_csv(abspath+"\\data\\origin_data\\Gowalla_edges.txt", delimiter='\t', index_col=None)
        edges.columns = ["u1", "u2"]
        uids = checkins.uid.unique()
        pairs = []
        for row in edges.itertuples(index=False, name=False):
            if row[0] in uids and row[1] in uids:
                pairs.append(row)
        pairs = pd.DataFrame(pairs, columns=['u1', 'u2'])
        pairs = pairs[pairs.u1 < pairs.u2]
        print(len(pairs))
        pairs.to_csv(abspath+"\\data\\city_data\\"+city+"_edgs.csv", sep="\t", index=False, header=None)

    def select_data(self, city, day_visit_times):  # 用于过滤只访问过一个位置的用户,并按天划分轨迹后只保留一天中签到数量大于4的天数
        checkins = pd.read_csv(abspath + "\\data\\city_data\\" + city + "_1.csv", delimiter="\t", index_col=None)
        checkins.sort_values(by=['uid', "time"], ascending=True, inplace=True)  # 按照时间先后进行排序
        result = deepcopy(checkins)
        result.loc[:, "time"] = result["time"].apply(lambda x: datetime.datetime.strptime(x, '%Y-%m-%d %H:%M:%S'))
        result.insert(1, "date", result["time"].dt.date, allow_duplicates=True)
        result.insert(2, "hour", result["time"].dt.time, allow_duplicates=True)
        result.drop(["time"], axis=1, inplace=True)
        result.rename(columns={"hour": "time"}, inplace=True)
        result1 = result.groupby(by=['uid', 'date']).size().reset_index(name="uid_date_times")  # 按天划分轨迹
        result1 = result1[result1.uid_date_times >= day_visit_times]
        df = pd.DataFrame()
        result2 = result.groupby(by=["uid"])
        for group in result2:
            user_checkins = group[1]
            user_date = list(result1[result1.uid == group[0]].date.values)
            user_day_checkins = user_checkins[user_checkins.date.isin(user_date)]
            df = pd.concat([df, user_day_checkins], ignore_index=True)
        data = df.groupby(by=['uid', 'locid']).size().reset_index(name="uid_locid_uid_times")
        data = data.groupby(by=['uid']).size().reset_index(name="times")
        data = list(data[data.times >= 2].uid.unique())
        result = df[df.uid.isin(data)]
        result.to_csv(abspath + "\\data\\city_data\\" + city + "_2.csv", sep='\t', header=True, index=False)
        self.checkins_edges1(result, "SNAP_SF")
        self.get_avg_userchenkins(result)
        result.insert(1, "new_time", result["date"].map(str) + " " +result["time"].map(str), allow_duplicates=True)
        result.drop(["date", "time"], axis=1, inplace=True)
        result.rename(columns={"new_time": "time"}, inplace=True)
        result.to_csv(abspath + "\\data\\city_data\\" + city + "_3.csv", sep='\t', header=True, index=False)  # 用于随机扰动


if __name__ == "__main__":

    # start = time.time()
    # cal = cal_close_relation_by_difsim_adaptive_ALL("SNAP_SF", 0.2, 65, 85)
    # # cal.cal_similarity1(0.6, 0.4, 0.1, 0.5, 0.4, 0.8, 0.1, 1, 1, 100)
    # cal.get_temp_checkins(0.6, 0.4, 0.1, 0.5, 0.4, 0.8, 0.1, 1, 1, 100)
    # print("时间：", (time.time() - start) / 60)
    start = time.time()
    handler = data_handle()
    handler.divide_area_1()
    handler.select_data("SNAP_SF", 4)
    # cal = cal_close_relation_by_difsim_adaptive_ALL("GW_NY", 0.2, 90, 90)
    # cal.cal_pairs_relation()
    # cal.get_middle_num(0.6, 0.4, 0.005)
    # cal.get_temp_checkins(0.6, 0.4, 0.05, 0.5, 0.4, 0.8, 5, 1, 1, 100)
    # cal.cal_similarity1(0.6, 0.4, 0.05, 0.5, 0.4, 0.8, 5, 1, 1, 100)
    # print("时间：", (time.time() - start) / 60)